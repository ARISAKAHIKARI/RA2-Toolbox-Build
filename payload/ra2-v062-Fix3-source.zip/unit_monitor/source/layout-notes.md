# Data layout notes

Target: Yuri's Revenge 1.001 ABI. Reference headers:
https://github.com/Phobos-developers/YRpp/blob/master/HouseClass.h
https://github.com/Phobos-developers/YRpp/blob/master/TechnoTypeClass.h
https://github.com/Phobos-developers/YRpp/blob/master/FactoryClass.h
https://github.com/Phobos-developers/YRpp/blob/master/FileFormats/SHP.h
https://github.com/CnCNet/yr-patches/blob/main/inc/NodeNameType.h
https://github.com/CnCNet/yr-patches/blob/main/sym.asm

Fields were audited with 32-bit Clang record layouts. Annotated offset checkpoints in HouseClass match: unknown_1E4, unknown_54E0, unknown_55F0, unknown_16060, unknown_160B4. Factory Object 0x58 and queue 0x44 / 0x50 additionally match disassembly of supplied executable's FactoryClass::CountTotal (0x4CA670).

| Object | Field | Offset/address |
|---|---|---|
| Globals | Houses / current house / observer | A80228 / A83D4C / AC1198 |
| Globals | Lobby NodeNameVector / GameActive / Frame | A8DA74 / A8E9A0 / A8ED84 |
| Globals | Infantry / vehicle / aircraft / building types | A8E348 / A83CE0 / A8B218 / A83C68 |
| Globals | Factory array / cameo convert | A83E30 / 87F6B0 |
| House | CurrentPlayer / PlayerControl | 1EC / 1ED |
| House | Defeated / IsGameOver / IsLoser | 1F5 / 1F6 / 1F8 |
| House | Owned building / vehicle / infantry / aircraft counters | 5500 / 5514 / 5528 / 553C |
| House | On-map-present building / vehicle / infantry / aircraft counters | 5550 / 5564 / 5578 / 558C |
| House | Color / UIName | 56F9 / 1602A |
| HouseType | MultiplayPassive | 1A6 |
| TechnoType | TechLevel / OwnerFlags / CameoFile / Cameo | 634 / 6CC / 6D6 / 6F0 |
| TechnoType | Insignificant / Spawned | 232 / D54 |
| Techno object | CountedAsOwned | 3CC |
| Unit/Aircraft / Infantry / Building | Type pointer | 6C4 / 6C0 / 520 |
| Factory | Progress / Queue / Product / Owner | 24 / 40 / 58 / 6C |
| NodeName | Spectator (-1) / HouseIndex | 6B / 6F |
| Convert | Bytes-per-pixel / Midpoint | 4 / 174 |

Array vector: items +4, capacity +8, count +16. Counter: items +4, capacity +8. SHPReference: resolved data +12. SHP data resolver 0x69E580 requires the verified prologue 83 EC 70 55 57 8B F9 89. Palette midpoint is the unshaded 256-entry RGB565 map, as confirmed by ConvertClass constructor 0x48E740. No external asset payload is distributed.

## Owned-counter bug fix (2026-10-13)

The previous `Sampler::owned()` rejected an entire type category whenever the
`CounterClass::Capacity` was smaller than the maximum exposed type index + 1.
YRpp `CounterClass::GetItemCount(int) const` instead treats any unallocated index
as zero. Since Capacity grows lazily, all rows could erroneously display zero
when newer type indices had never been owned.

The patch reads only `min(Capacity, highest requested index+1)` items and
zero-fills the remainder. A fully unallocated counter (Capacity=0, Items=null)
is a valid all-zero result, not a read failure. If the read itself fails,
zeroes remain and `readErrors` increments. CountedAsOwned correction for a
factory's not-yet-delivered product remains unchanged because that byte at
TechnoClass+0x3CC is confirmed by the public YRpp layout.

Primary display continues to use HouseClass::Owned*Types (CountOwnedNow),
including passenger / garrison ownership, not `Owned*Types1` (on-map-present).
This is entirely read-only; no simulation-state writes were added.

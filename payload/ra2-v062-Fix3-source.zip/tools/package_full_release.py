#!/usr/bin/env python3
"""Package verified RA2 Toolbox 0.6.2 Win32 files + FULL resources.
Never packages legacy binaries or substitutes missing build artifacts.
"""
from pathlib import Path
import hashlib
import json
import sys
import zipfile

BASE = Path(__file__).resolve().parent.parent
EXE_DLL = ('RA2Toolbox.exe', 'AssistBridge.dll', 'UnitMonitorBridge.dll', 'CursorHideBridge.dll')
REQUIRED_FOLDERS = ('assets', 'profiles', 'runtime', 'engine', 'licenses')
OPTIONAL_TOP = ('Assist.ini', 'Assist.example.ini', 'Assist-HighLevel-Experimental.ini',
                'Toolbox.ini', 'Start-Message.cmd', 'Start-Frame.cmd',
                'TacticalAssist-README.txt', 'THIRD-PARTY-NOTICES.txt',
                'LICENSE', 'WINDOWS_BUILD_ARTIFACTS.json',
                'BUILD-VERIFIED-v062.tag', 'BUILD_STATUS_AND_USAGE.txt')


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for piece in iter(lambda: f.read(2 * 1024 * 1024), b''):
            h.update(piece)
    return h.hexdigest()


def run():
    manifest = BASE / 'WINDOWS_BUILD_ARTIFACTS.json'
    if not manifest.is_file() or not (BASE / 'BUILD-VERIFIED-v062.tag').is_file():
        raise RuntimeError('No verified PE32 build metadata. Run BUILD-0.6.2-ON-WINDOWS.cmd first.')
    meta = json.loads(manifest.read_text(encoding='utf-8'))
    recorded = meta.get('verified', {})
    missing = [name for name in EXE_DLL if not (BASE/name).is_file()]
    if missing:
        raise RuntimeError('Missing freshly built Win32 outputs: ' + ', '.join(missing))
    for name in EXE_DLL:
        actual = sha(BASE / name)
        if recorded.get(name, {}).get('sha256') != actual:
            raise RuntimeError('PE32 hash mismatch: ' + name)
        if recorded[name].get('machine') != 'PE32 x86':
            raise RuntimeError('Incorrect target: ' + name)
    for directory in REQUIRED_FOLDERS:
        if not (BASE / directory).is_dir():
            raise RuntimeError('Missing FULL resource directory: ' + directory)
    files = [BASE / x for x in EXE_DLL]
    files.extend(BASE / x for x in OPTIONAL_TOP if (BASE / x).is_file())
    for directory in REQUIRED_FOLDERS:
        for p in (BASE / directory).rglob('*'):
            if p.is_file() and '__pycache__' not in p.parts:
                files.append(p)
    release = BASE / 'RA2-Toolbox-v0.6.2-Full-Win32-Compiled.zip'
    header = 'RA2-Toolbox-v0.6.2-Full'
    # Do not include source or legacy v0.4.1 binaries in runnable distribution.
    with zipfile.ZipFile(release, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6,
                         allowZip64=True) as z:
        for p in sorted(set(files), key=lambda p: str(p).lower()):
            z.write(p, f'{header}/{p.relative_to(BASE).as_posix()}')
        z.writestr(f'{header}/COMPILED_BUILD_METADATA.json', json.dumps({
            'version': '0.6.2', 'type': 'Win32 x86 compiled candidate / Full assets',
            'runtime_tested': False, 'multiplayer_tested': False,
            'module_sha256': {name: sha(BASE / name) for name in EXE_DLL},
        }, ensure_ascii=False, indent=2))
    print('CREATED:', release)
    print('SIZE_MB:', round(release.stat().st_size / 1048576, 2))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(run())
    except Exception as exc:
        print('FULL PACKAGE BLOCKED:', exc, file=sys.stderr)
        sys.exit(1)

#!/usr/bin/env python3
"""Validate actual PE32 outputs; block mislabeling legacy binary files as v0.6.2."""
from pathlib import Path
import hashlib, json, struct, sys
r=Path(__file__).resolve().parent.parent
names=['RA2Toolbox.exe','AssistBridge.dll','UnitMonitorBridge.dll','CursorHideBridge.dll']
legacy=json.loads((r/'BUILD_SOURCE_MANIFEST.json').read_text('utf-8'))['legacy_binary_sha256']
recs={}; errors=[]
for name in names:
    p=r/name
    try:
        buf=p.read_bytes()
        if len(buf)<256 or buf[:2]!=b'MZ':raise ValueError('MZ header missing')
        pos=struct.unpack_from('<I',buf,0x3c)[0]
        if pos+24>=len(buf) or buf[pos:pos+4]!=b'PE\x00\x00':raise ValueError('PE signature missing')
        machine,nsections=struct.unpack_from('<HH',buf,pos+4)
        magic=struct.unpack_from('<H',buf,pos+24)[0]
        if machine!=0x14c or magic!=0x10b:raise ValueError(f'not x86 PE32 (machine=0x{machine:04x}, magic=0x{magic:04x})')
        characteristic=struct.unpack_from('<H',buf,pos+22)[0]
        want_dll=name.endswith('.dll')
        if bool(characteristic&0x2000)!=want_dll: raise ValueError('unexpected EXE/DLL type')
        digest=hashlib.sha256(buf).hexdigest()
        if digest==legacy.get(name):raise ValueError('unchanged v0.4.1 binary, not 0.6.2')
        # Both host and injected bridge must refer to the same protocol-30
        # mapping namespace. This is a *consistency* check, not proof of
        # executable behavior or full compiler provenance.
        if name in ('RA2Toolbox.exe','AssistBridge.dll'):
            marker='RA2Assist_v037_'.encode('utf-16le')
            if marker not in buf:raise ValueError('v0.6.2 protocol-30 mapping marker missing')
        recs[name]={'bytes':len(buf),'sha256':digest,'machine':'PE32 x86','sections':nsections}
    except Exception as ex: errors.append(f'{name}: {ex}')
if errors:
    print('BUILD NOT VERIFIED:')
    print('\n'.join(errors))
    sys.exit(1)
(r/'BUILD-VERIFIED-v062.tag').write_text('v0.6.2 candidate build\nNot runtime or multiplayer certified\n',encoding='utf-8')
(r/'WINDOWS_BUILD_ARTIFACTS.json').write_text(json.dumps({'label':'0.6.2 compiled candidate','verified':recs,'runtime_tested':False},ensure_ascii=False,indent=2),encoding='utf-8')
print('PASS: 4 PE32 x86 outputs; none is old v0.4.1 binary')
print('NOTE: does not verify game compatibility or runtime imports')

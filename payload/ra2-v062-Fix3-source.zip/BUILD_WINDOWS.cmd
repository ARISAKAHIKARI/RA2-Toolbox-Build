@echo off
setlocal
cd /d "%~dp0"
if defined RA2_LLVM_MINGW set "PATH=%RA2_LLVM_MINGW%;%RA2_LLVM_MINGW%\bin;%PATH%"
for %%D in ("%~dp0toolchain\bin" "%~dp0llvm-mingw\bin") do if exist "%%~D\i686-w64-mingw32-clang++.exe" set "PATH=%%~D;%PATH%"
where i686-w64-mingw32-clang++.exe >nul 2>&1
if errorlevel 1 (
  echo Cannot find i686-w64-mingw32-clang++.exe in PATH.
  echo Install LLVM-MinGW Win32 toolchain, then retry.
  pause
  exit /b 1
)
where i686-w64-mingw32-windres.exe >nul 2>&1
if errorlevel 1 (
  echo Cannot find i686-w64-mingw32-windres.exe in PATH.
  pause
  exit /b 1
)
echo [1/4] Compiling patched AssistBridge.dll ...
cd assist\source
call build.cmd
if errorlevel 1 goto fail
cd ..\..
echo [2/4] Compiling fixed UnitMonitorBridge.dll ...
cd unit_monitor\source
for /f "delims=" %%L in ('i686-w64-mingw32-clang++ -print-libgcc-file-name') do set "LIBGCC=%%L"
if not defined LIBGCC goto fail
i686-w64-mingw32-clang++ -std=c++17 -O2 -shared -fms-extensions -fasm-blocks -fno-stack-protector -fno-builtin -fno-exceptions -fno-rtti -nostdlib bridge.cpp -o ..\UnitMonitorBridge.dll -Wl,--entry,_DllMain@12,--kill-at -lkernel32 -luser32 "%LIBGCC%"
if errorlevel 1 goto fail
cd ..\..
echo [3/4] Compiling unified RA2Toolbox.exe ...
cd suite\source
i686-w64-mingw32-windres app.rc -O coff -o app.res.o
if errorlevel 1 goto fail
i686-w64-mingw32-clang++ -std=c++17 -O2 -DRA2_UNIFIED -DwWinMain=CursorEntry -I. -c ..\..\cursor\source\main.cpp -o cursor.o
if errorlevel 1 goto fail
i686-w64-mingw32-clang++ -std=c++17 -O2 -DRA2_UNIFIED -DwWinMain=MonitorEntry -I. -c ..\..\unit_monitor\source\main.cpp -o monitor.o
if errorlevel 1 goto fail
i686-w64-mingw32-clang++ -std=c++17 -O2 -DRA2_UNIFIED -DwWinMain=TacticalEntry -I. -c ..\..\assist\source\main.cpp -o tactical.o
if errorlevel 1 goto fail
i686-w64-mingw32-clang++ -std=c++17 -O2 -static -municode -mwindows main.cpp cursor.o monitor.o tactical.o app.res.o -o ..\RA2Toolbox.exe -lgdiplus -lcomctl32 -luser32 -lgdi32 -lwinmm -lshell32 -lole32 -lcomdlg32
if errorlevel 1 goto fail
cd ..\..
echo [4/4] Compiling CursorHideBridge.dll ...
cd cursor\source
i686-w64-mingw32-clang++ --target=i686-pc-windows-msvc -O2 -fms-extensions -fno-stack-protector -fno-autolink -c resource_guard.cpp -o resource_guard.o
if errorlevel 1 goto fail
i686-w64-mingw32-clang++ -std=c++17 -O2 -DUNICODE -D_UNICODE -fuse-ld=lld -shared -fms-extensions -fasm-blocks -fno-stack-protector -fno-builtin -fno-exceptions -fno-rtti -nostdlib hide.cpp resource_guard.o -o ..\CursorHideBridge.dll -Wl,--entry,_DllMain@12,--kill-at -lkernel32 -luser32 -lgdi32 -lmsvcrt "%LIBGCC%"
if errorlevel 1 goto fail
cd ..\..
copy /y suite\RA2Toolbox.exe RA2Toolbox.exe >nul
copy /y assist\AssistBridge.dll AssistBridge.dll >nul
copy /y unit_monitor\UnitMonitorBridge.dll UnitMonitorBridge.dll >nul
copy /y cursor\CursorHideBridge.dll CursorHideBridge.dll >nul
echo Build outputs: suite\RA2Toolbox.exe, assist\AssistBridge.dll, unit_monitor\UnitMonitorBridge.dll
echo Close game and toolbox before replacing all four output files in v0.3.0 installation.
pause
exit /b 0
:fail
echo Build failed. Do not copy incomplete binaries.
pause
exit /b 1

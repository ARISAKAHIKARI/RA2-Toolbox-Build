﻿RA2 Toolbox v0.6.2 Full BuildFix4（文件版本 0.6.2.4）

本包已实际编译，包含 RA2Toolbox.exe、AssistBridge.dll、UnitMonitorBridge.dll、CursorHideBridge.dll。
也包含完整 assets、profiles、runtime、engine、许可和当前修复源码。无需再次编译即可使用。

运行：
1. 完整解压到新文件夹。更新时先关闭旧工具箱和游戏，避免加载上一份 DLL。
2. 双击 Start-Message.cmd，按系统提示以管理员权限启动。也可直接运行 RA2Toolbox.exe。
3. 进入游戏后查看高刷光标、单位统计、战术助手三页状态。设置仍保存到包旁的 INI。

环境：Windows 10/11 x64。工具箱和三个桥接 DLL 为 x86，以匹配 32 位游戏；
单独启动的预处理 Python 及 NumPy/SciPy/OpenCV 为 x64，两者不在同一进程加载。

默认使用消息调度；Start-Frame.cmd 是原有的实验性帧入口。
Orders.MegaMissionBackend 和 Orders.ObjectEventBackend 继续默认 0。
默认科技逻辑仍为本基线的外部目录与原版生产事件，未增加侧栏或规则改写。

检查结果：63 项便携回归全部通过；四模块 PE32/导出/依赖/协议一致性通过；
两份用户游戏 EXE 的 21 处入口签名、6 处帧 CALL 上下文及 QueueMegaMission 静态 ABI 匹配。
Full 的 2,987 个原资源文件逐个核对，内容与 BuildFix3 完整包相同。

本次在 Linux 使用 Zig 0.13.0 交叉编译，未在 Windows 启动工具箱、进入游戏或双人联机。
实际运行及同步效果不以静态校验或便携测试代替。详情见 CHECK_REPORT_v0.6.2_BuildFix4.md。

需要重新编译时：使用 Zig 0.13.0，将 zig.exe 放到 toolchain\zig.exe，或设置 ZIG_EXE / PATH，
然后运行 BUILD-AND-PACK-FULL.cmd。编译器不打进运行包。完整编译日志与源码均在包内。

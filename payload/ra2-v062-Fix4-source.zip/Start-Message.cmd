@echo off
setlocal
cd /d "%~dp0"
if not exist "BUILD-VERIFIED-v062.tag" (
 echo This folder does not yet contain a verified v0.6.2 build.
 echo Run BUILD-0.6.2-ON-WINDOWS.cmd first.
 pause
 exit /b 1
)
for %%F in ("RA2Toolbox.exe" "AssistBridge.dll" "UnitMonitorBridge.dll" "CursorHideBridge.dll") do if not exist "%%~F" (echo Missing %%~F & pause & exit /b 1)
set "RA2_TOOLBOX_DRIVER=message"
start "" "%~dp0RA2Toolbox.exe"

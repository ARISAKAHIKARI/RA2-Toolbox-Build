@echo off
setlocal
cd /d "%~dp0"
call "%~dp0BUILD-AND-PACK-FULL.cmd"
exit /b %errorlevel%

"""Static source inventory; candidates are not runtime resolved pointers."""
from pathlib import Path
import re,csv
root=Path(__file__).resolve().parents[1];out=root/'docs';rows=[];calls=[];api=[];access=[]
for module in ('assist','external_reader','unit_monitor','cursor','suite'):
 for p in sorted((root/module/'source').glob('*')):
  if p.suffix not in ('.h','.cpp'):continue
  for number,line in enumerate(p.read_text().splitlines(),1):
   line=line.strip()
   if line.startswith('//'):continue
   loc=(module,str(p.relative_to(root)),number)
   for m in re.finditer(r'0x[0-9A-Fa-f]+',line):
    v=int(m.group(),16)
    if v<0x10:continue
    kind='absolute_candidate' if 0x400000<=v<=0x00FFFFFF else 'offset_or_constant'
    if re.search(r'call\s*<|__thiscall|__fastcall|__cdecl',line) and kind=='absolute_candidate':kind='call_candidate'
    if re.search(r'patchNativeInput|writeInputCode|VirtualProtect|Patch|Original|Site|site=',line) and kind=='absolute_candidate':kind='code_site_candidate'
    rows.append((*loc,f'0x{v:X}',kind,line))
   if re.search(r'call\s*<|__thiscall|__fastcall|__cdecl|invoke\(',line):calls.append((*loc,line))
   if re.search(r'get\s*<|put\s*<|\bread\(|read_\(|\bbytes\(|memcpy\(|ReadProcessMemory|WriteProcessMemory',line):access.append((*loc,line))
   if re.search(r'OpenProcess|ReadProcessMemory|WriteProcessMemory|VirtualAlloc|VirtualProtect|CreateRemoteThread|SetWindowsHookEx|UnhookWindowsHookEx|LoadLibrary|GetProcAddress|MapViewOfFile|CreateFileMapping|PostMessage|SendInput|GetAsyncKeyState',line):api.append((*loc,line))
for name,header,data in [('memory-addresses.csv',['module','file','line','hex','classification','expression'],rows),('memory-accesses.csv',['module','file','line','expression'],access),('native-call-sites.csv',['module','file','line','expression'],calls),('windows-api-sites.csv',['module','file','line','expression'],api)]:
 with (out/name).open('w',encoding='utf-8-sig',newline='') as f:w=csv.writer(f);w.writerow(header);w.writerows(data)
 print(name,len(data))

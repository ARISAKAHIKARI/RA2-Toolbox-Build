@echo off
setlocal
cd /d "%~dp0"
if defined ZIG_EXE (set "ZIG=%ZIG_EXE%") else (set "ZIG=zig")
"%ZIG%" version
if errorlevel 1 goto missing
set "RA2_ZIG_VERSION="
"%ZIG%" version > "%~dp0zig-version.tmp"
if errorlevel 1 goto missing
set /p RA2_ZIG_VERSION=<"%~dp0zig-version.tmp"
del /q "%~dp0zig-version.tmp"
if not "%RA2_ZIG_VERSION%"=="0.13.0" goto version_mismatch
rem Normal DLL CRT entry initializes linked runtime and C++ static objects.
for %%F in (BUILD-VERIFIED-v062.tag WINDOWS_BUILD_ARTIFACTS.json) do if exist "%%F" del /q "%%F"
"%ZIG%" rc /fo suite\source\app.res suite\source\app.rc
if errorlevel 1 goto fail
"%ZIG%" c++ -target x86-windows-msvc -O2 -fms-extensions -fno-stack-protector -c assist\source\guard.cpp -o assist\source\guard.o
if errorlevel 1 goto fail
"%ZIG%" c++ -target x86-windows-gnu -std=c++17 -O2 -fms-extensions -fasm-blocks -fno-stack-protector -fno-builtin -fno-exceptions -fno-rtti -c assist\source\bridge.cpp -o assist\source\bridge.o
if errorlevel 1 goto fail
"%ZIG%" c++ -target x86-windows-gnu -shared assist\source\bridge.o assist\source\guard.o assist\source\bridge.def -o AssistBridge.dll -lkernel32 -luser32 -lwinmm
if errorlevel 1 goto fail
"%ZIG%" c++ -target x86-windows-gnu -std=c++17 -O2 -fms-extensions -fasm-blocks -fno-stack-protector -fno-builtin -fno-exceptions -fno-rtti -c unit_monitor\source\bridge.cpp -o unit_monitor\source\bridge.o
if errorlevel 1 goto fail
"%ZIG%" c++ -target x86-windows-gnu -shared unit_monitor\source\bridge.o unit_monitor\source\bridge.def -o UnitMonitorBridge.dll -lkernel32 -luser32
if errorlevel 1 goto fail
"%ZIG%" c++ -target x86-windows-msvc -O2 -fms-extensions -fno-stack-protector -c cursor\source\resource_guard.cpp -o cursor\source\resource_guard.o
if errorlevel 1 goto fail
"%ZIG%" c++ -target x86-windows-gnu -O2 -DUNICODE -D_UNICODE -fms-extensions -fasm-blocks -fno-stack-protector -fno-builtin -fno-exceptions -fno-rtti -c cursor\source\hide.cpp -o cursor\source\hide.o
if errorlevel 1 goto fail
"%ZIG%" c++ -target x86-windows-gnu -shared cursor\source\hide.o cursor\source\resource_guard.o cursor\source\hide.zig.def -o CursorHideBridge.dll -lkernel32 -luser32 -lgdi32
if errorlevel 1 goto fail
"%ZIG%" c++ -target x86-windows-gnu -std=c++17 -O2 -DRA2_UNIFIED -DwWinMain=CursorEntry -Isuite\source -c cursor\source\main.cpp -o suite\source\cursor.o
if errorlevel 1 goto fail
"%ZIG%" c++ -target x86-windows-gnu -std=c++17 -O2 -DRA2_UNIFIED -DwWinMain=MonitorEntry -Isuite\source -c unit_monitor\source\main.cpp -o suite\source\monitor.o
if errorlevel 1 goto fail
"%ZIG%" c++ -target x86-windows-gnu -std=c++17 -O2 -DRA2_UNIFIED -DwWinMain=TacticalEntry -Isuite\source -c assist\source\main.cpp -o suite\source\tactical.o
if errorlevel 1 goto fail
"%ZIG%" c++ -target x86-windows-gnu -std=c++17 -O2 -municode suite\source\main.cpp suite\source\cursor.o suite\source\monitor.o suite\source\tactical.o suite\source\app.res -o RA2Toolbox.exe -Wl,--subsystem,windows -lgdiplus -lcomctl32 -luser32 -lgdi32 -lwinmm -lshell32 -lole32 -lcomdlg32
if errorlevel 1 goto fail
echo Build complete. Close the game and toolbox before replacing all four files.
if not defined RA2_NO_PAUSE pause
exit /b 0
:missing
echo Install Zig 0.13.0 and add its folder to PATH, or set ZIG_EXE to zig.exe.
if not defined RA2_NO_PAUSE pause
exit /b 1
:version_mismatch
echo Zig 0.13.0 required. Found %RA2_ZIG_VERSION%.
if not defined RA2_NO_PAUSE pause
exit /b 2
:fail
echo Build failed. Do not copy incomplete output files.
if not defined RA2_NO_PAUSE pause
exit /b 1

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>

#include "sampler.h"
extern "C" void* __cdecl memset(void* p,int c,size_t n){volatile unsigned char* d=(volatile unsigned char*)p;while(n--)*d++=(unsigned char)c;return p;}
extern "C" void* __cdecl memcpy(void* p,const void* q,size_t n){volatile unsigned char* d=(volatile unsigned char*)p;const volatile unsigned char* s=(const volatile unsigned char*)q;while(n--)*d++=*s++;return p;}
extern "C" int __cdecl memcmp(const void* p,const void* q,size_t n){const unsigned char* a=(const unsigned char*)p,*b=(const unsigned char*)q;while(n--){if(*a!=*b)return int(*a)-int(*b);a++;b++;}return 0;}
static void mapName(wchar_t* out,DWORD pid){const wchar_t* prefix=L"Local\\RA2UnitMonitor_v013_";int i=0;while(*prefix)out[i++]=*prefix++;wchar_t digits[16];int n=0;do{digits[n++]=L'0'+pid%10;pid/=10;}while(pid);while(n)out[i++]=digits[--n];out[i]=0;}
static um::Shared* shared;static HANDLE mapping;static DWORD last;static bool busy;
static bool readmem(uint32_t p,void* out,size_t n){SIZE_T got=0;return p>=0x10000&&n<=4*1024*1024&&uint64_t(p)+n<0x80000000ull&&ReadProcessMemory(GetCurrentProcess(),(void*)(uintptr_t)p,out,n,&got)&&got==n;}
static uint32_t resolve(uint32_t p){
 // Called only on the game's own message thread, after version signature verification.
 using F=void*(__thiscall*)(void*);return (uint32_t)(uintptr_t)((F)0x69E580)((void*)(uintptr_t)p);
}
static um::Sampler<decltype(&readmem),decltype(&resolve)> sampler(readmem,resolve);
static bool supported(){uint8_t b[8],want[]={0x83,0xEC,0x70,0x55,0x57,0x8B,0xF9,0x89};return readmem(0x69E580,b,8)&&!memcmp(b,want,8);}
static void disconnect(){if(shared)UnmapViewOfFile(shared);shared=nullptr;if(mapping)CloseHandle(mapping);mapping=nullptr;}
static void tick(){
 if(!shared){sampler.reset();wchar_t name[80];mapName(name,GetCurrentProcessId());mapping=OpenFileMappingW(FILE_MAP_ALL_ACCESS,FALSE,name);if(!mapping)return;
 shared=(um::Shared*)MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(um::Shared));if(!shared||shared->magic!=um::Magic||shared->pid!=GetCurrentProcessId()){disconnect();return;}}
 DWORD now=GetTickCount();if(shared->command==2||DWORD(now-shared->heartbeat)>3000){shared->command=0;disconnect();return;}
 if(DWORD(now-last)<250)return;last=now;
 if(!supported()){InterlockedIncrement((volatile LONG*)&shared->seq);shared->data.status=-1;MemoryBarrier();InterlockedIncrement((volatile LONG*)&shared->seq);return;}
 const auto& data=sampler.sample(now,true);
 InterlockedIncrement((volatile LONG*)&shared->seq);memcpy(&shared->data,&data,sizeof data);MemoryBarrier();InterlockedIncrement((volatile LONG*)&shared->seq);
}
extern "C" __declspec(dllexport) LRESULT CALLBACK UnitMonitorHook(int code,WPARAM wp,LPARAM lp){
 __declspec(align(16)) BYTE fx[512];__asm {fxsave fx}
 if(code>=0&&!busy){busy=true;tick();busy=false;}
 __asm {fxrstor fx}
 return CallNextHookEx(NULL,code,wp,lp);
}
extern "C" BOOL WINAPI DllMain(HINSTANCE h,DWORD why,LPVOID){if(why==DLL_PROCESS_ATTACH)DisableThreadLibraryCalls(h);else if(why==DLL_PROCESS_DETACH)disconnect();return TRUE;}

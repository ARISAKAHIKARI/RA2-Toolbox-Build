#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${CXX:=i686-w64-mingw32-clang++}"
"${WINDRES:-i686-w64-mingw32-windres}" app.rc -O coff -o app.res.o
"$CXX" -std=c++17 -O2 -static -municode -mwindows main.cpp app.res.o -o ../UnitMonitor.exe -lgdiplus -luser32 -lgdi32 -lshell32
"$CXX" -std=c++17 -O2 -shared -fms-extensions -fasm-blocks -fno-stack-protector -fno-builtin -fno-exceptions -fno-rtti -nostdlib bridge.cpp -o ../UnitMonitorBridge.dll -Wl,--entry,_DllMain@12,--kill-at -lkernel32 -luser32 "$("$CXX" -print-libgcc-file-name)"

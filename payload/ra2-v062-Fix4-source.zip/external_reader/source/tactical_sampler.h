#pragma once
#include "../../assist/source/protocol.h"
#include <algorithm>
#include <cmath>
#include <vector>
#include <array>
#include <cstring>
#include <unordered_set>
#include "game_view.h"
#include "layout_probe.h"
namespace external {
struct Projection {int cameraX=0,cameraY=0,width=0,height=0;double zScale=0.0866025403784;};
inline bool project(const Projection&p,int x,int y,int z,int&sx,int&sy){
 if(std::abs(int64_t(x))>1048576||std::abs(int64_t(y))>1048576||std::abs(int64_t(z))>1048576||!std::isfinite(p.zScale)||p.zScale<0||p.zScale>1)return false;
 sx=int((int64_t(x)-y)*30/256)-p.cameraX;sy=int((int64_t(x)+y)*15/256)-int(z*p.zScale+int(z>=728)+.5)-p.cameraY;
 return sx>=-80&&sx<p.width+80&&sy>=-60&&sy<p.height+60;
}
template<class Read> class TacticalSampler {
 Read read_;assist::Snapshot state_{};layout::Result probe_{};uint32_t house_=0,serial_=0;int lastFrame_=-1;
 int sceneFrame_=-1,sceneX_=0,sceneY_=0,sceneWidth_=0,sceneHeight_=0;uint32_t sceneFlags_=0,selectionHash_=0;
 uint32_t typePointers_[assist::MaxTypes]{};std::unordered_set<uint32_t> stopped_;
 struct FactoryState {uint32_t pointer=0;int type=-1;bool busy=false,paused=false,complete=false,seen=false;};FactoryState factories_[4];uint32_t productionAt_=0;
 template<class T>T get(uint32_t a,T fallback={}){T v{};return read_(a,&v,sizeof v)?v:fallback;}
 std::vector<uint32_t> vec(uint32_t a,int maximum=16384){
  uint32_t items=get<uint32_t>(a+4);int cap=get<int>(a+8,-1),n=get<int>(a+16,-1);
  if(n<0||n>maximum||cap<n||cap>65536||(n&&items<0x10000))return {};
  std::vector<uint32_t> out(size_t(n),0);if(n&&!read_(items,out.data(),size_t(n)*4))out.clear();return out;
 }
 int kind(uint32_t p){uint32_t v=get<uint32_t>(p);return v==0x7F5C70?2:v==0x7EB058?1:v==0x7E3EBC?3:v==0x7E22A4?0:-1;}
 uint32_t type(uint32_t p,int k){return get<uint32_t>(p+(k==3?0x520:k==1?0x6C0:0x6C4));}
 void name(uint32_t type,uint16_t*out){uint32_t p=get<uint32_t>(type+0x60);uint16_t s[40]{};if(p>=0x10000&&read_(p,s,sizeof s)){std::memcpy(out,s,sizeof s);out[39]=0;}else{char id[24]{};read_(type+0x24,id,23);for(int j=0;j<23;++j)out[j]=uint8_t(id[j]);}}
 int frozen(uint32_t object){
  uint32_t temporal=get<uint32_t>(object+0x278);if(temporal<0x10000||get<uint32_t>(temporal+0x28)!=object)return 0;
  int remaining=get<int>(temporal+0x48);if(remaining<=0)return 0;
  uint32_t seen[52]{};int count=0;int64_t rate=0;
  // Mirrors the raw helper chain used by GetWarpPerStep; never calls it (it writes WarpPerStep).
  for(uint32_t p=temporal;p>=0x10000&&count<52;p=get<uint32_t>(p+0x44)){
   bool loop=false;for(int j=0;j<count;++j)if(seen[j]==p)loop=true;if(loop||get<uint32_t>(p+0x28)!=object)break;seen[count++]=p;
   int step=get<int>(p+0x4C);if(step>0&&step<1000000)rate+=step;
  }
  if(!rate)return 0;return int(std::min<int64_t>(1000000,(remaining+rate-1)/rate));
 }
 void types(){
  state_.typeCount=0;uint32_t arrays[]={0xA8B218,0xA8E348,0xA83CE0,0xA83C68};int kinds[]={3,16,40,7};
  for(int c=0;c<4;++c){auto list=vec(arrays[c],4096);for(size_t j=0;j<list.size()&&state_.typeCount<assist::MaxTypes;++j){auto p=list[j];
   if(!p||!assist::validType(get<int>(p+0x634,-1),get<uint8_t>(p+0x232)!=0,get<uint8_t>(p+0xD54)!=0,get<uint32_t>(p+0x6CC)))continue;
   typePointers_[state_.typeCount]=p;auto&t=state_.types[state_.typeCount++];t={};read_(p+0x24,t.id,23);name(p,t.name);t.kind=kinds[c];t.index=int(j);t.naval=get<uint8_t>(p+0xCCE);t.cost=get<int>(p+0x610);
  }}
 }
public:
 int flashCount=0,flashes[4]{};
 explicit TacticalSampler(Read read):read_(read){}
 layout::Result probe()const{return probe_;}
 void reset(){probe_={};house_=serial_=0;lastFrame_=-1;state_={};sceneFrame_=-1;sceneFlags_=selectionHash_=0;flashCount=0;productionAt_=0;for(auto&f:factories_)f={};stopped_.clear();}
 void stopped(const std::vector<uint32_t>&ids){stopped_.clear();stopped_.insert(ids.begin(),ids.end());}
 void refreshCamera(uint32_t now){
  if(state_.status!=1)return;uint32_t tactical=get<uint32_t>(0x887324);if(tactical<0x10000)return;
  int x=get<int>(tactical+0xB0),y=get<int>(tactical+0xB4),dx=x-state_.cameraX,dy=y-state_.cameraY;
  if(!dx&&!dy)return;state_.cameraX=x;state_.cameraY=y;state_.sampledTick=now;
  for(int i=0;i<state_.labels;++i){state_.label[i].x-=dx;state_.label[i].y-=dy;}
  for(int i=0;i<state_.crateCount;++i){state_.crates[i].x-=dx;state_.crates[i].y-=dy;}
  for(int i=0;i<state_.threatCount;++i){auto&t=state_.threats[i];t.x-=dx;t.y-=dy;t.tx-=dx;t.ty-=dy;}
 }
 const assist::Snapshot&sample(uint32_t now,uint32_t flags){
  state_.sampledTick=now;
  probe_=layout::inspect(read_);
  if(probe_.stage!=layout::Stage::Ready){
   state_.status=0;state_.labels=state_.selected=state_.transports=state_.used=state_.capacity=0;
   state_.typeCount=state_.swCount=state_.threatCount=state_.crateCount=0;
   house_=0;return state_;
  }
  uint32_t house=get<uint32_t>(0xA83D4C);int frame=get<int>(0xA8ED84,-1);
  auto houses=vec(0xA80228,32);if(std::find(houses.begin(),houses.end(),house)==houses.end()){
   probe_={layout::Stage::MissingLocalHouseInList,0xA80228,house};
   state_.status=0;state_.labels=state_.typeCount=state_.swCount=0;
   state_.threatCount=state_.crateCount=0;house_=0;return state_;
  }
  bool fresh=house!=house_||frame<lastFrame_;if(fresh){++serial_;house_=house;types();for(auto&f:factories_)f={};flashCount=0;productionAt_=now-100;}lastFrame_=frame;
  state_.status=1;state_.frame=frame;state_.match=serial_;state_.session=get<int>(0xA8B238);state_.chat=get<uint8_t>(0xA8BC60+25);state_.credits=get<int>(house+0x30C);
  uint32_t tactical=get<uint32_t>(0x887324);Projection proj;proj.width=state_.width=get<int>(0xA8EB84);proj.height=state_.height=get<int>(0xA8EB88);
  proj.cameraX=state_.cameraX=get<int>(tactical+0xB0);proj.cameraY=state_.cameraY=get<int>(tactical+0xB4);proj.zScale=get<double>(0xB0CD48,0.0866025403784);
  uint32_t selectedHash=2166136261u;for(uint32_t p:vec(0xA8ECB8,4096))selectedHash=(selectedHash^p)*16777619u;
  bool scene=fresh||frame!=sceneFrame_||flags!=sceneFlags_||selectedHash!=selectionHash_||proj.cameraX!=sceneX_||proj.cameraY!=sceneY_||proj.width!=sceneWidth_||proj.height!=sceneHeight_;
  if(!scene)return state_;
  sceneFrame_=frame;sceneFlags_=flags;selectionHash_=selectedHash;sceneX_=proj.cameraX;sceneY_=proj.cameraY;sceneWidth_=proj.width;sceneHeight_=proj.height;
  state_.labels=state_.selected=state_.transports=state_.used=state_.capacity=state_.threatCount=state_.crateCount=0;
  GameView<Read> view(read_);auto objects=vec(0xA8EC78);uint32_t allies=get<uint32_t>(house+0x5788);
  // A valid process handle and match flag do not prove that the YR 1.001
  // object ABI applies. Report a mismatch rather than silently showing zero
  // units if a populated array has no recognizable TechnoClass vtables.
  if(objects.size()>=4){bool anyKnown=false;
   for(size_t i=0;i<objects.size()&&i<128;++i){if(objects[i]&&kind(objects[i])>=0){anyKnown=true;break;}}
   if(!anyKnown){probe_={layout::Stage::UnrecognizedUnitLayout,0xA8EC78,uint32_t(objects.size())};
    state_.status=0;state_.labels=state_.typeCount=state_.swCount=0;
    state_.threatCount=state_.crateCount=0;return state_;}
  }
  for(auto p:objects){int k=p?kind(p):-1;if(k<0||get<int>(p+0x6C)<=0||!get<uint8_t>(p+0x74)||get<uint8_t>(p+0x81)||!get<uint8_t>(p+0x90))continue;
   uint32_t owner=get<uint32_t>(p+0x21C),t=type(p,k);bool local=owner==house,selected=local&&get<uint8_t>(p+0x83);if(selected)++state_.selected;
   int cap=local&&t&&k!=3&&(flags&assist::Capacity)?get<int>(t+0x5E0):0;
   bool capacity=cap>0&&cap<=1024&&(selected||(flags&assist::AllTransports));int used=0;
   if(capacity){uint32_t q=get<uint32_t>(p+0x118),seen[256]{};int count=0;while(q>=0x10000&&count<256){bool loop=false;for(int j=0;j<count;++j)if(seen[j]==q)loop=true;if(loop)break;seen[count++]=q;int qk=kind(q);if(qk<0)break;uint32_t qt=type(q,qk);double size=get<double>(qt+0x380);if(!(size>0&&size<=128))break;used+=int(size);q=get<uint32_t>(q+0x30);}used=std::min(used,cap);if(selected){++state_.transports;state_.used+=used;state_.capacity+=cap;}}
   if((flags&assist::Psychic)&&view.enemy(p,house)&&state_.threatCount<assist::MaxThreats){uint32_t target=get<uint32_t>(p+0x2B4);if(view.live(target)&&get<uint32_t>(target+0x21C)==house){int sx,sy,tx,ty;if(project(proj,get<int>(p+0x9C),get<int>(p+0xA0),get<int>(p+0xA4),sx,sy)&&project(proj,get<int>(target+0x9C),get<int>(target+0xA0),get<int>(target+0xA4),tx,ty))state_.threats[state_.threatCount++]={get<uint32_t>(p+0x10),get<uint32_t>(target+0x10),sx,sy,tx,ty};}}
   int iron=(flags&assist::Iron)?assist::remaining(get<int>(p+0x18C),get<int>(p+0x194),frame):0;
   int freeze=(flags&assist::Frozen)?frozen(p):0;
   uint32_t id=get<uint32_t>(p+0x10);bool advanced=local&&stopped_.count(id);
   if(!capacity&&!iron&&!freeze&&!advanced)continue;int sx,sy;if(!tactical||!project(proj,get<int>(p+0x9C),get<int>(p+0xA0),get<int>(p+0xA4),sx,sy)||state_.labels>=assist::MaxLabels)continue;
   uint8_t rgb[3]={255,255,255};if(owner>=0x10000)read_(owner+22265,rgb,3);uint32_t color=0xff000000u|(uint32_t(rgb[0])<<16)|(uint32_t(rgb[1])<<8)|rgb[2];
   auto&l=state_.label[state_.labels++];l={id,sx,sy,used,capacity?cap:0,iron,get<int>(p+0x1C4)!=0,advanced,color,freeze};
  }
  state_.swCount=0;auto supers=vec(house+0x254,256);for(size_t i=0;i<supers.size()&&state_.swCount<assist::MaxSW;++i){uint32_t p=supers[i];if(!p||get<uint32_t>(p+0x2C)!=house||!get<uint8_t>(p+0x6D))continue;uint32_t t=get<uint32_t>(p+0x28);if(!t)continue;auto&d=state_.supers[state_.swCount++];d={};read_(t+0x24,d.id,23);name(t,d.name);d.index=int(i);d.frames=assist::remaining(get<int>(p+0x30),get<int>(p+0x38),frame);d.ready=!get<uint8_t>(p+0x70)&&(get<uint8_t>(t+0xE5)?get<int>(p+0x7C)!=0:get<uint8_t>(p+0x6F)!=0);}
  if(!productionAt_||uint32_t(now-productionAt_)>=100){productionAt_=now;state_.factories=state_.busyFactories=state_.pausedFactories=state_.completedFactories=0;const int offsets[]={0x53BC,0x53B4,0x53B8,0x53AC};
   for(int i=0;i<4;++i){uint32_t f=get<uint32_t>(house+offsets[i]);auto&before=factories_[i];if(f<0x10000||get<uint32_t>(f+0x6C)!=house){before={};continue;}++state_.factories;
    uint32_t p=get<uint32_t>(f+0x58),t=p?type(p,kind(p)):0;int index=-1;for(int j=0;t&&j<state_.typeCount;++j)if(typePointers_[j]==t){index=j;break;}
    bool busy=p||get<int>(f+0x50)>0,paused=busy&&(get<uint8_t>(f+0x5C)||get<uint8_t>(f+0x71)),complete=busy&&get<int>(f+0x24)>=54;
    state_.busyFactories+=busy;state_.pausedFactories+=paused;state_.completedFactories+=complete;
    if((flags&assist::Production)&&before.seen&&before.pointer==f&&((before.busy&&!busy&&!before.complete)||(!before.paused&&paused)||(!before.complete&&complete))){int changed=index>=0?index:before.type;
     if(changed>=0&&(state_.types[changed].kind==3||state_.types[changed].kind==7)&&flashCount<4){bool seen=false;for(int j=0;j<flashCount;++j)if(flashes[j]==changed)seen=true;if(!seen)flashes[flashCount++]=changed;++state_.noticeSerial;}
    }if(index<0&&before.pointer==f)index=before.type;before={f,index,busy,paused,complete,(flags&assist::Production)!=0};
   }
  }
  if((flags&assist::Crates)&&tactical){uint32_t cells=get<uint32_t>(0x87F7E8+316);int capacity=get<int>(0x87F7E8+320);auto overlays=vec(0xA83D80,4096);
   if(cells>=0x10000&&capacity>0&&capacity<=512*512)for(int i=0;i<256&&state_.crateCount<assist::MaxCrates;++i){uint32_t c=0x87F7E8+344+i*16;int x=get<int16_t>(c+12),y=get<int16_t>(c+14);if(x<=0||y<=0||x>=512||y>=512||y*512+x>=capacity||!assist::remaining(get<int>(c),get<int>(c+8),frame))continue;
    uint32_t cell=get<uint32_t>(cells+(y*512+x)*4);int overlay=get<int>(cell+0x44,-1);if(overlay<0||overlay>=int(overlays.size())||!get<uint8_t>(overlays[overlay]+0x2AA))continue;
    int level=get<int8_t>(cell+0x11B),height=get<int>(0x89E7C0,104);if(height<=0||height>1024)height=104;int z=level*height,slope=get<uint8_t>(cell+0x11C);
    if(slope>0&&slope<=19&&(get<uint8_t>(0x89E770)&7)==7){uint32_t a=0x81C900+(slope-1)*40;double scale=get<double>(0x89E740),extra=128*(get<double>(a)+get<double>(a+8))*scale+get<double>(a+16)+get<double>(a+32),maximum=get<double>(a+24);if(std::isfinite(extra)&&maximum>=0&&maximum<=4096)z+=int(std::clamp(extra,0.0,maximum));}
    int sx,sy;if(!project(proj,x*256+128,y*256+128,z,sx,sy))continue;int preview=get<uint8_t>(cell+0x11E);state_.crates[state_.crateCount++]={x,y,sx,sy,preview<19?preview:-1};
   }
  }
  return state_;
 }
};
}

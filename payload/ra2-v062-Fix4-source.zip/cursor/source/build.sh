#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${CXX:=i686-w64-mingw32-clang++}"
: "${WINDRES:=i686-w64-mingw32-windres}"
"$WINDRES" app.rc -O coff -o app.res.o
"$CXX" -std=c++17 -O2 -static -municode -mwindows main.cpp app.res.o -o ../ExternalCursor.exe -luser32 -lgdi32 -lwinmm -lshell32 -lole32 -lcomdlg32
"$CXX" -std=c++17 -O2 -static -municode preview.cpp -o ../CursorPreview.exe -lshell32
"$CXX" --target=i686-pc-windows-msvc -O2 -fms-extensions -fno-stack-protector -fno-autolink -c resource_guard.cpp -o resource_guard.o
"$CXX" -std=c++17 -O2 -DUNICODE -D_UNICODE -shared -fms-extensions -fasm-blocks -fno-stack-protector -fno-builtin -fno-exceptions -fno-rtti -nostdlib hide.cpp resource_guard.o -o ../CursorHideBridge.dll -Wl,--entry,_DllMain@12,--kill-at -lkernel32 -luser32 -lgdi32 -lmsvcrt

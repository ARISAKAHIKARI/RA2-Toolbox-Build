#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${CXX:=i686-w64-mingw32-clang++}"
: "${WINDRES:=i686-w64-mingw32-windres}"
"$WINDRES" app.rc -O coff -o app.res.o
"$CXX" -std=c++17 -O2 -DRA2_UNIFIED -DwWinMain=CursorEntry -I. -c ../../cursor/source/main.cpp -o cursor.o
"$CXX" -std=c++17 -O2 -DRA2_UNIFIED -DwWinMain=MonitorEntry -I. -c ../../unit_monitor/source/main.cpp -o monitor.o
"$CXX" -std=c++17 -O2 -DRA2_UNIFIED -DwWinMain=TacticalEntry -I. -c ../../assist/source/main.cpp -o tactical.o
"$CXX" -std=c++17 -O2 -static -municode -mwindows main.cpp cursor.o monitor.o tactical.o app.res.o -o ../RA2Toolbox.exe -lgdiplus -lcomctl32 -luser32 -lgdi32 -lwinmm -lshell32 -lole32 -lcomdlg32

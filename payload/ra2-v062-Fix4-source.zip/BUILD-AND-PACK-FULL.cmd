@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title RA2 Toolbox 0.6.2 - Build and Pack Full Win32

echo [1/4] Finding Zig 0.13.0...
if not defined ZIG_EXE (
  if exist "%~dp0toolchain\zig.exe" set "ZIG_EXE=%~dp0toolchain\zig.exe"
)
if not defined ZIG_EXE (
  if exist "%~dp0zig\zig.exe" set "ZIG_EXE=%~dp0zig\zig.exe"
)
if defined ZIG_EXE (
  "%ZIG_EXE%" version >nul 2>&1
) else (
  where zig >nul 2>&1
)
if errorlevel 1 goto nozig

echo [2/4] Building four new PE32 x86 binaries...
set "RA2_NO_PAUSE=1"
for %%F in (RA2Toolbox.exe AssistBridge.dll UnitMonitorBridge.dll CursorHideBridge.dll BUILD-VERIFIED-v062.tag WINDOWS_BUILD_ARTIFACTS.json) do if exist "%%F" del /q "%%F"
call "%~dp0BUILD_ZIG.cmd" > "%~dp0build-v062-full.log" 2>&1
if errorlevel 1 goto failed

echo [3/4] Verifying that binaries are PE32 x86 and NOT v0.4.1...
set "PYTHON_EXE=python"
if exist "%~dp0runtime\python.exe" set "PYTHON_EXE=%~dp0runtime\python.exe"
"%PYTHON_EXE%" "%~dp0tools\verify_windows_outputs.py"
if errorlevel 1 goto verification_failed

echo [4/4] Packaging executable plus FULL resources...
"%PYTHON_EXE%" "%~dp0tools\package_full_release.py"
if errorlevel 1 goto packaging_failed

echo.
echo SUCCESS: RA2-Toolbox-v0.6.2-Full-Win32-BuildFix4.zip
echo PE32, ABI, exports, imports and Full resources verified.
echo Game runtime and multiplayer testing still required.
pause
exit /b 0
:nozig
echo Zig 0.13.0 missing. Download the Windows x64 version from:
echo https://ziglang.org/download/0.13.0/zig-windows-x86_64-0.13.0.zip
echo Extract and place zig.exe in toolchain\ or add zig.exe to PATH.
echo Then double-click BUILD-AND-PACK-FULL.cmd again.
pause
exit /b 2
:failed
echo COMPILE FAILED. No old DLLs will be substituted.
set "RA2_BUILD_LOG=%~dp0build-v062-full.log"
echo -------- Last 40 log lines --------
powershell -NoProfile -Command "Get-Content -LiteralPath $env:RA2_BUILD_LOG -Tail 40" 2>nul
echo -----------------------------------
echo Upload build-v062-full.log if errors remain.
pause
exit /b 1
:verification_failed
echo VERIFY FAILED: outputs are missing, wrong architecture, or not current build.
pause
exit /b 1
:packaging_failed
echo PACKAGE FAILED. All 4 files must be verified before packing Full.
pause
exit /b 1

// Local mouse/UI entry points only. Received network events, simulation AI,
// weapon selectors, ownership, rules and missions are never patched.
#include "../../external_reader/source/game_view.h"
#include "business_effects.h"
struct LocalRawRead {bool operator()(uint32_t a,void*out,size_t n)const{if(a<0x10000||uint64_t(a)+n>=0x80000000ull)return false;memcpy(out,(const void*)(uintptr_t)a,n);return true;}};
static external::GameView<LocalRawRead> clickView(LocalRawRead{});
static const unsigned char footClickOriginal[6]={0x81,0xEC,0xF8,0,0,0};
static const unsigned char decideOriginal[8]={0x83,0xEC,0x10,0xA1,0xC8,0xEC,0xA8,0};
static const unsigned char mouseUpOriginal[6]={0x83,0xEC,0x7C,0x53,0x55,0x56};
static unsigned char footClickPatch[6],decidePatch[8],mouseUpPatch[6];
static unsigned char *footClickCode,*decideCode,*mouseUpCode;static bool footClickPatched,decidePatched,mouseUpPatched;
static uint32_t clickSerial,cooperativePlanSeen;static int cooperativeAt;
struct EnterReservation {uint32_t id,target,type,token;int frame,slots;};
static EnterReservation entryReservations[cooperative::MaxSources];static int entryReservationCount;
struct CooperativeEffect {uint32_t actor=0,target=0,ticket=0,match=0,actorPointer=0,targetPointer=0,beforeTarget=0,queuedAt=0;int frame=0,mission=0,rearmStart=-1;bool acquired=false;};
static CooperativeEffect cooperativeEffects[cooperative::MaxSources];static int cooperativeEffectCount;
static void observeCooperativeEffects(uint32_t house,int frame){
 for(int i=0;i<cooperativeEffectCount;){const auto e=cooperativeEffects[i];
  uint32_t actor=worldByID(e.actor),target=worldByID(e.target);
  bool identity=e.match==match&&frame>=e.frame&&actor&&actor==e.actorPointer&&get<uint32_t>(actor+0x21C)==house;
  bool active=identity&&live(actor); // aircraft can temporarily leave the map
  bool targetSame=target&&target==e.targetPointer; // no target-ID reuse false positive
  bool boarded=identity&&e.mission==7&&targetSame&&get<uint32_t>(actor+0x11C)==target;
  bool targeting=active&&e.mission==1&&frame>e.frame&&targetSame&&get<uint32_t>(actor+0x2B4)==target;
  // An already-selected target is not fresh acquisition, but a NEW rearm can
  // still demonstrate that the repeated Attack caused another firing cycle.
  if(targeting&&e.beforeTarget!=target)cooperativeEffects[i].acquired=true;
  int rearm=active?get<int>(actor+0x2EC):-1; // verified raw combat field, read-only
  auto air=effects::aircraft(active,targeting,e.rearmStart,rearm,e.frame,frame);
  bool shot=e.mission==1&&air==effects::Aircraft::ShotObserved;
  // Temporarily absent aircraft are not immediate failure. A reused pointer is.
  bool expired=e.match!=match||(actor&&actor!=e.actorPointer)||(target&&target!=e.targetPointer)||frame<e.frame||frame-e.frame>180;
  if(boarded||shot||expired){
   if(e.ticket){gateway::Receipt receipt{};gateway::Intent intent{e.match,e.queuedAt,e.actor,e.target,0};
    gateway::planned(receipt,e.ticket,intent);receipt.owner=taskarbiter::Owner::Cooperative;
    receipt.queuedAt=e.queuedAt;
    // Shot evidence = changed rearm after target acquisition, not proven damage.
    receipt.phase=(boarded||shot)?gateway::Phase::Completed:
       cooperativeEffects[i].acquired?gateway::Phase::Observed:gateway::Phase::Expired;
    receipt.failure=(expired&&!boarded&&!shot&&!cooperativeEffects[i].acquired)?gateway::Failure::Stale:gateway::Failure::None;
    receipt.observedAt=receipt.phase!=gateway::Phase::Expired?sampleClock(sh):0;
    missionObserver.dismissTicket(e.match,e.ticket);recordReceipt(receipt);
    actorLeaseArbiter.release(e.match,e.actor,e.ticket);
   }
   cooperativeEffects[i]=cooperativeEffects[--cooperativeEffectCount];
  }else ++i;
 }
}
// Only cancel older watch records AFTER the replacement event was enqueued.
// Never cancel on a failed queue attempt; that would lose a valid task.
static void supersedeCooperativeEffect(uint32_t actor,uint32_t session){
 for(int i=0;i<cooperativeEffectCount;){auto e=cooperativeEffects[i];
  if(e.actor==actor&&e.match==session){
   gateway::Receipt rec{};gateway::Intent intent{e.match,e.queuedAt,e.actor,e.target,0};
   gateway::planned(rec,e.ticket,intent);rec.owner=taskarbiter::Owner::Cooperative;
   rec.queuedAt=e.queuedAt;gateway::cancelled(rec,gateway::Failure::Superseded);
   missionObserver.dismissTicket(e.match,e.ticket);recordReceipt(rec);++snap.receiptCancelled;
   actorLeaseArbiter.release(e.match,e.actor,e.ticket);
   cooperativeEffects[i]=cooperativeEffects[--cooperativeEffectCount];
  }else ++i;
 }
}
static bool modifierHeld(uint32_t key){
 if(key==VK_CONTROL||key==VK_MENU||key==VK_SHIFT)return (GetAsyncKeyState(key)&0x8000)!=0;
 return configuredKeyHeld(key);
}
static bool airUnit(uint32_t p){int k=kind(p);return k==0||(k==2&&(get<bool>(p+0x134)||get<int>(p+0x94)==3||get<bool>(p+0x84)||get<bool>(p+0x8D)));}
static bool shiftBinding(uint32_t key){return key==VK_SHIFT||((key>>8)&1)!=0;}
static bool vehicleSellCell(uint32_t p){
 uint32_t cell=readMapCell(get<int>(p+0x9C)/256,get<int>(p+0xA0)/256);if(!cell)return false;
 for(uint32_t q=get<uint32_t>(cell+0xE4),n=0;q>=0x10000&&n<256;++n){if(!worldObjects.contains(q))return false;if(kind(q)==3)return true;uint32_t next=get<uint32_t>(q+0x30);if(next==q)return false;q=next;}return false;
}
static bool sellAllowed(uint32_t p){
 if(!nativeReady()||!get<bool>(0x87F7E8+0x11B1)||!(GetAsyncKeyState(VK_CONTROL)&0x8000)||!p||!live(p))return false;
 int k=kind(p);uint32_t owner=get<uint32_t>(p+0x21C);bool drained=get<uint32_t>(p+0x1D0)!=0;
 if(owner!=lastHouse&&!eventdelivery::isSingleplayer(get<int>(0xA8B238)))return false;
 if(drained&&!(sh->flags&SellDrained))return false;
 if(k==2)return owner>=0x10000&&(sh->flags&SellVehicles)&&vehicleSellCell(p);
 if(k!=3)return false;
 if(owner!=lastHouse)return (sh->flags&SellEnemy)&&nativeEnemy(p,lastHouse);
 return drained&&(sh->flags&SellDrained);
}
static bool newCooperative(uint32_t p,uint32_t target,int mode){
 auto&r=sh->cooperativeRequest;int frame=get<int>(0xA8ED84);DWORD now=sampleClock(sh);uint32_t id=get<uint32_t>(p+0x10),targetID=get<uint32_t>(target+0x10);
 if(!id||!targetID)return false;
 if(get<int>(0xA8ECB8+16)>cooperative::MaxSources){
  if(r.count<=cooperative::MaxSources||r.frame!=frame||r.target!=targetID||r.mode!=mode){InterlockedIncrement(&sh->cooperativeSeq);memset(&r,0,sizeof r);r.serial=++clickSerial;if(!r.serial)r.serial=++clickSerial;r.match=match;r.target=targetID;r.mode=mode;r.frame=frame;r.tick=now;r.count=cooperative::MaxSources+1;MemoryBarrier();InterlockedIncrement(&sh->cooperativeSeq);notifyHost();}return false;
 }
 bool same=r.serial&&r.match==match&&r.target==targetID&&r.mode==mode&&r.frame==frame&&r.count>=0&&r.count<=cooperative::MaxSources&&DWORD(now-r.tick)<100;
 if(same)for(int i=0;i<r.count;++i)if(r.sources[i].id==id){same=false;break;}
 if(same&&r.count>=cooperative::MaxSources)return false;
 if(!manualVersions.trackable(id))return false;
 cancelNative(p);InterlockedIncrement(&sh->cooperativeSeq);
 if(!same){memset(&r,0,sizeof r);r.serial=++clickSerial;if(!r.serial)r.serial=++clickSerial;r.match=match;r.target=targetID;r.type=typeOf(target,kind(target));r.mode=mode;r.frame=frame;
  uint32_t tactical=get<uint32_t>(0x887324);if(tactical>=0x10000){r.cameraX=get<int>(tactical+0xB0);r.cameraY=get<int>(tactical+0xB4);}
  int width=get<int>(0xB0CE30),height=get<int>(0xB0CE34);r.viewWidth=width>0&&width<=32768?width:get<int>(0xA8EB84);r.viewHeight=height>0&&height<=32768?height:get<int>(0xA8EB88);
 }
 r.tick=now;r.sources[r.count++]={id,manualVersions.get(id)};MemoryBarrier();InterlockedIncrement(&sh->cooperativeSeq);notifyHost();return true;
}
extern "C" int CooperativeClick(uint32_t p,uint32_t action,uint32_t target,uint32_t force){
 if(!nativeReady()||!p||!target||!own(p,lastHouse)||!get<bool>(p+0x83)||get<bool>(p+0x1C8)||get<uint32_t>(p+0x11C))return 0;
 // No queued/planning-mode conversion: retain the native Shift/waypoint path.
 bool explicitShift=((sh->flags&AdvancedEnter)&&shiftBinding(sh->enterKey)&&modifierHeld(sh->enterKey))||((sh->flags&AircraftSpread)&&((shiftBinding(sh->airKey1)&&modifierHeld(sh->airKey1))||(shiftBinding(sh->airKey2)&&modifierHeld(sh->airKey2))));
 if(((GetAsyncKeyState(VK_SHIFT)&0x8000)&&!explicitShift)||get<bool>(0x87F7E8+0x11B3)||get<bool>(0x87F7E8+0x11B1))return 0;
 indexWorld(get<int>(0xA8ED84));if(!worldObjects.contains(p)||!worldObjects.contains(target)||!live(target))return 0;
 if((sh->flags&AdvancedEnter)&&modifierHeld(sh->enterKey)&&clickView.entryCompatible(p,target,lastHouse))return newCooperative(p,target,cooperative::Enter)?1:0;

 if((sh->flags&DiskPrimary)&&kind(p)==2&&kind(target)==3&&(GetAsyncKeyState(VK_CONTROL)&0x8000)){
  uint32_t t=typeOf(p,2),secondary=t?get<uint32_t>(t+0x898+28):0;
  if(t&&(sameid((const char*)(t+0x24),"DISK")||(secondary>=0x10000&&get<bool>(secondary+0x142)))){
   int x=get<int>(target+0x9C)/256,y=get<int>(target+0xA0)/256;if(!readMapCell(x,y)||!loadInterfaces())return 0;
   uint32_t diskID=get<uint32_t>(p+0x10);if(!diskID)return 0;
   int frame=get<int>(0xA8ED84);actorFrameArbiter.begin(match,frame);
   if(!actorFrameArbiter.canIssue(diskID,manualVersions.get(diskID))){++snap.commandRejected;return -1;}
   // Ground-cell Attack is a MegaMission too: same backend selector, no
   // fallback to self-written OutList when the native engine rejects it.
   cancelNative(p);releaseAutoOwner(diskID);
   return submitMegaMission(lastHouse,get<uint32_t>(p+0x10),1,
                 uint32_t(y*1000+x),11,0,0,0,0)?(actorFrameArbiter.record(diskID,manualVersions.get(diskID),taskarbiter::Owner::Generic),1):-1;
  }
 } if((sh->flags&AircraftSpread)&&airUnit(p)&&nativeEnemy(target,lastHouse)){
  int mode=sh->airKey2&&modifierHeld(sh->airKey2)?cooperative::AirSecond:modifierHeld(sh->airKey1)?cooperative::AirFirst:0;
  if(mode)return newCooperative(p,target,mode)?1:0;
 }
 return 0;
}
extern "C" int CooperativeDecide(uint32_t object){
 if(!nativeReady()||!object)return -1;indexWorld(get<int>(0xA8ED84));if(!worldObjects.contains(object)||!live(object))return -1;
 if(sellAllowed(object))return kind(object)==2?13:12;
 if((sh->flags&AdvancedEnter)&&modifierHeld(sh->enterKey)&&(!(GetAsyncKeyState(VK_SHIFT)&0x8000)||shiftBinding(sh->enterKey))&&!get<bool>(0x87F7E8+0x11B3)&&!get<bool>(0x87F7E8+0x11B1)){
  Vec selected=vec(0xA8ECB8,4096);for(int i=0;i<selected.count;++i){uint32_t p=item(selected,i);if(p&&clickView.entryCompatible(p,object,lastHouse))return 3;}
 }
 return -1;
}
extern "C" int CooperativeSell(uint32_t object){
 if(!nativeReady())return 0;indexWorld(get<int>(0xA8ED84));if(!worldObjects.contains(object)||!sellAllowed(object))return 0;
 uint32_t owner=get<uint32_t>(object+0x21C);int house=owner>=0x10000?get<int>(owner+0x30):-1;if(house<0||house>=32)return 0;
 // Original receiver checks target owner and a building in a vehicle cell.
 // Enemy-owner events still require real transport/multiplayer validation.
 return nativeObjectEvent(house,0x16,get<uint32_t>(object+0x10))?1:-1;
}
extern "C" void CooperativeFault(){if(sh)sh->clickHookStatus=-2;}
extern "C" int GuardedCooperativeClick(uint32_t,uint32_t,uint32_t,uint32_t);
extern "C" int GuardedCooperativeDecide(uint32_t);
extern "C" int GuardedCooperativeSell(uint32_t);
static bool __fastcall footClickGate(void*self,void*,uint32_t action,uint32_t target,bool force){
 __declspec(align(16)) BYTE fx[512];__asm {fxsave fx}int result=GuardedCooperativeClick(uint32_t(self),action,target,force);__asm {fxrstor fx}
 return result?result>0:call<bool>(uint32_t(footClickCode),uint32_t(self),action,target,force);
}
static uint32_t __fastcall decideGate(void*self,void*,uint32_t cell,uint32_t object,uint32_t unknown){
 __declspec(align(16)) BYTE fx[512];__asm {fxsave fx}int result=GuardedCooperativeDecide(object);__asm {fxrstor fx}
 return result>=0?uint32_t(result):call<uint32_t>(uint32_t(decideCode),uint32_t(self),cell,object,unknown);
}
static void __fastcall mouseUpGate(void*self,void*,uint32_t coords,uint32_t cell,uint32_t object,uint32_t action,uint32_t unknown){
 __declspec(align(16)) BYTE fx[512];__asm {fxsave fx}int result=GuardedCooperativeSell(object);__asm {fxrstor fx}
 // Keep the native mouse cleanup even after a forced sale. NoSell is the
 // native no-op branch, preventing a second sale event from this click.
 call<void>(uint32_t(mouseUpCode),uint32_t(self),coords,cell,object,result?14:action,unknown);
}
static void resetCooperativeState(){entryReservationCount=cooperativeEffectCount=0;cooperativeAt=0;cooperativePlanSeen=0;}
static void restoreClickHooks(){
 if(footClickPatched){
  if(writeInputCodeGuarded(0x4D74E0,footClickPatch,footClickOriginal,6))footClickPatched=false;
  else{codeHookRegistry.markConflict(0x4D74E0);if(sh)sh->clickHookStatus=-3;}
 }
 if(decidePatched){
  if(writeInputCodeGuarded(0x692610,decidePatch,decideOriginal,8))decidePatched=false;
  else{codeHookRegistry.markConflict(0x692610);if(sh)sh->clickHookStatus=-3;}
 }
 if(mouseUpPatched){
  if(writeInputCodeGuarded(0x4AB9B0,mouseUpPatch,mouseUpOriginal,6))mouseUpPatched=false;
  else{codeHookRegistry.markConflict(0x4AB9B0);if(sh)sh->clickHookStatus=-3;}
 }
}
static void clickHooksTick(uint32_t flags){
 if(!eventdelivery::isSingleplayer(get<int>(0xA8B238)))flags&=~uint32_t(SellEnemy);
 if(!(flags&SpecialClickFlags)){restoreClickHooks();sh->clickHookStatus=(footClickPatched||decidePatched||mouseUpPatched)?-3:0;return;}
 if(sh->clickHookStatus<0){restoreClickHooks();return;}
 bool foreign=(footClickPatched&&memcmp((void*)0x4D74E0,footClickPatch,6))||(decidePatched&&memcmp((void*)0x692610,decidePatch,8))||(mouseUpPatched&&memcmp((void*)0x4AB9B0,mouseUpPatch,6));
 if(foreign){
  if(footClickPatched&&memcmp((void*)0x4D74E0,footClickPatch,6))codeHookRegistry.markConflict(0x4D74E0);
  if(decidePatched&&memcmp((void*)0x692610,decidePatch,8))codeHookRegistry.markConflict(0x692610);
  if(mouseUpPatched&&memcmp((void*)0x4AB9B0,mouseUpPatch,6))codeHookRegistry.markConflict(0x4AB9B0);
  restoreClickHooks();sh->clickHookStatus=-3;return;}
 bool ok=true;
 if(!bridgePinned){HMODULE module=0;ok=GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)&decideGate,&module)!=0;if(ok)bridgePinned=true;}
 if(ok&&(flags&(CooperativeFlags|DiskPrimary)))ok=patchNativeInput(0x4D74E0,footClickOriginal,footClickPatch,6,(void*)&footClickGate,footClickCode,footClickPatched);
 if(ok&&(flags&(AdvancedEnter|SellDrained|SellVehicles|SellEnemy)))ok=patchNativeInput(0x692610,decideOriginal,decidePatch,8,(void*)&decideGate,decideCode,decidePatched);
 if(ok&&(flags&(SellDrained|SellVehicles|SellEnemy)))ok=patchNativeInput(0x4AB9B0,mouseUpOriginal,mouseUpPatch,6,(void*)&mouseUpGate,mouseUpCode,mouseUpPatched);
 if(footClickPatched&&!(flags&(CooperativeFlags|DiskPrimary))){
   if(writeInputCodeGuarded(0x4D74E0,footClickPatch,footClickOriginal,6))footClickPatched=false;
   else{codeHookRegistry.markConflict(0x4D74E0);ok=false;}
  }
 if(decidePatched&&!(flags&(AdvancedEnter|SellDrained|SellVehicles|SellEnemy))){
   if(writeInputCodeGuarded(0x692610,decidePatch,decideOriginal,8))decidePatched=false;
   else{codeHookRegistry.markConflict(0x692610);ok=false;}
  }
 if(mouseUpPatched&&!(flags&(SellDrained|SellVehicles|SellEnemy))){
   if(writeInputCodeGuarded(0x4AB9B0,mouseUpPatch,mouseUpOriginal,6))mouseUpPatched=false;
   else{codeHookRegistry.markConflict(0x4AB9B0);ok=false;}
  }
 if(!ok){restoreClickHooks();sh->clickHookStatus=-3;}else sh->clickHookStatus=1;
}
static int entryReserved(uint32_t target,uint32_t ignore,uint32_t house){
 int reserved=0;Vec all=vec(0xA8EC78);for(int i=0;i<all.count;++i){uint32_t p=item(all,i);int k=p?kind(p):-1;
  if((k!=1&&k!=2)||!own(p,house)||get<uint32_t>(p+0x10)==ignore||get<uint32_t>(p+0x11C)||incomingVehicle(p)!=target)continue;
  int slots=clickView.entrySlots(p,target);if(!slots)return 1024;reserved+=slots;if(reserved>=1024)return 1024;
 }
 for(int i=0;i<entryReservationCount;++i){auto&r=entryReservations[i];uint32_t p=worldByID(r.id);if(r.target==get<uint32_t>(target+0x10)&&r.id!=ignore&&p&&incomingVehicle(p)!=target)reserved+=r.slots;}
 return reserved;
}
static void cooperativeTick(uint32_t house,int frame,DWORD now){
 observeCooperativeEffects(house,frame);
 for(int i=0;i<entryReservationCount;){auto&r=entryReservations[i];uint32_t p=worldByID(r.id),t=worldByID(r.target);
  if(!p||!t||!own(p,house)||manualVersions.get(r.id)!=r.token||get<uint32_t>(p+0x11C)||get<uint32_t>(p+0x2E4)||!live(p)||frame-r.frame>180)entryReservations[i]=entryReservations[--entryReservationCount];else ++i;
 }
 uint32_t plan=sh->cooperativePlan;if(plan==sh->cooperativeAck)return;MemoryBarrier();
 if(plan!=cooperativePlanSeen){cooperativePlanSeen=plan;cooperativeAt=0;sh->cooperativeAccepted=sh->cooperativeRejected=0;}
 if(sh->cooperativeCount<0||sh->cooperativeCount>cooperative::MaxSources){sh->cooperativeRejected=sh->cooperativeCount>0?cooperative::MaxSources:0;sh->cooperativeAck=plan;notifyHost();return;}
 bool enter=sh->cooperativeMode==cooperative::Enter;
 if(!nativeReady()||sh->cooperativeSerial!=sh->cooperativeRequest.serial||sh->cooperativeMode!=sh->cooperativeRequest.mode||sh->cooperativeMode<cooperative::Enter||sh->cooperativeMode>cooperative::AirSecond||sh->cooperativeRequest.match!=match||DWORD(now-sh->cooperativeTick)>5000||sh->cooperativeCount<0||sh->cooperativeCount>cooperative::MaxSources||!(sh->flags&(enter?AdvancedEnter:AircraftSpread))){sh->cooperativeRejected+=sh->cooperativeCount-cooperativeAt;cooperativeAt=sh->cooperativeCount;}
 int budget=recurringBudget(EventLane::Planning);
 while(cooperativeAt<sh->cooperativeCount&&budget>0&&outgoingRoom()>0){const auto&o=sh->cooperativeOrders[cooperativeAt];uint32_t p=worldByID(o.id),t=worldByID(o.target);bool valid=p&&t&&own(p,house)&&live(t)&&typeOf(t,kind(t))==o.type&&manualVersions.get(o.id)==o.token&&!get<bool>(p+0x1C8)&&!get<uint32_t>(p+0x11C);
  int slots=0,mission=enter?7:1;
  if(valid&&enter){valid=clickView.entryCompatible(p,t,house);auto c=clickView.capacity(t);slots=clickView.entrySlots(p,t);int reserved=entryReserved(t,o.id,house);
   valid=valid&&entryReservationCount<cooperative::MaxSources&&slots>0&&int64_t(c.used)+reserved+slots<=c.maximum;
   if(valid){int action=call<int>(get<uint32_t>(get<uint32_t>(p)+0x74),p,t,true);valid=action==3||action==11;if(action==11)mission=9;}
  }else if(valid){valid=airUnit(p)&&nativeEnemy(t,house);if(valid){planner::Actor source{},target{};rawCombatInfo(p,typeOf(p,kind(p)),kind(p),source,true);rawCombatInfo(t,o.type,kind(t),target,false);valid=planner::compatibleTarget(source,target,false);}}
  if(!valid){++sh->cooperativeRejected;++cooperativeAt;continue;}
  uint32_t ticket=0;uint32_t beforeTarget=get<uint32_t>(p+0x2B4);
  int beforeRearm=get<int>(p+0x2EC);
  if(!nativeMission(house,o.id,mission,enter?0:o.target,enter?o.target:0,enter?0x34:0,0,0,taskarbiter::Owner::Cooperative,&ticket))break;
  // Preserve raw native event encoding, add only read-only effect observations.
  supersedeCooperativeEffect(o.id,match);
  if(ticket&&cooperativeEffectCount<cooperative::MaxSources&&(mission==1||mission==7)){
   // One observer owns this ticket: avoid generic timeout/observed duplicates.
   missionObserver.dismissTicket(match,ticket);
   cooperativeEffects[cooperativeEffectCount++]={o.id,o.target,ticket,match,p,t,beforeTarget,now,frame,mission,beforeRearm,false};
  }
  if(enter)entryReservations[entryReservationCount++]={o.id,o.target,o.type,o.token,frame,slots};
  ++sh->cooperativeAccepted;++cooperativeAt;--budget;
 }
 if(cooperativeAt>=sh->cooperativeCount){MemoryBarrier();sh->cooperativeAck=plan;notifyHost();}
}

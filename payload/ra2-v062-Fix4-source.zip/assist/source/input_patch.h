#include "hook_registry.h"
static assist::hookregistry::Registry<> codeHookRegistry;
// This registry owns all supported inline patches, including the frame hook.
// It provides sticky conflict detection and owner verification, NOT atomic
// writes against threads executing in other cores. Never bypass a foreign hook.
static bool writeInputCodeGuarded(uint32_t address,const unsigned char* expected,
                                  const unsigned char* replacement,unsigned length){
 using namespace assist::hookregistry;
 Transition action=codeHookRegistry.proposal(address,expected,replacement,length);
 if(action==Transition::Deny)return false;
 MEMORY_BASIC_INFORMATION mbi{};
 if(!VirtualQuery((const void*)(uintptr_t)address,&mbi,sizeof mbi)||mbi.State!=MEM_COMMIT||
    (mbi.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;
 DWORD old=0;
 if(!VirtualProtect((void*)(uintptr_t)address,length,PAGE_EXECUTE_READWRITE,&old))return false;
 bool unchanged=!memcmp((const void*)(uintptr_t)address,expected,length);
 if(unchanged){
  memcpy((void*)(uintptr_t)address,replacement,length);
  FlushInstructionCache(GetCurrentProcess(),(const void*)(uintptr_t)address,length);
  unchanged=!memcmp((const void*)(uintptr_t)address,replacement,length);
 }
 DWORD unused=0;BOOL restoredProtect=VirtualProtect((void*)(uintptr_t)address,length,old,&unused);
 if(!unchanged||!restoredProtect){codeHookRegistry.markConflict(address);return false;}
 codeHookRegistry.commit(address,expected,replacement,length,action);return true;
}

// Immutable trampoline: prepare off-line on RW memory, then mark RX before
// publishing the game-site JMP. The page remains mapped across retries so a
// callback already in flight cannot jump into recycled executable memory.
static unsigned char* makeInputTrampoline(uint32_t at,const unsigned char*original,unsigned size){
 if(!original||size<5||size>16)return nullptr;
 auto*code=(unsigned char*)VirtualAlloc(nullptr,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
 if(!code)return nullptr;
 memcpy(code,original,size);code[size]=0xE9;
 int32_t back=int32_t((at+size)-uint32_t(uintptr_t(code+size+5)));
 memcpy(code+size+1,&back,4);
 DWORD old=0;
 if(!VirtualProtect(code,4096,PAGE_EXECUTE_READ,&old)){
  VirtualFree(code,0,MEM_RELEASE);return nullptr;
 }
 FlushInstructionCache(GetCurrentProcess(),code,size+5);
 return code;
}

#pragma once
#include "protocol.h"
namespace assist {
inline uint32_t counterTick(uint32_t tick,uint64_t start,uint64_t frequency,uint64_t current,uint32_t fallback){
 if(!frequency||current<start)return fallback;
 uint64_t delta=current-start;return tick+uint32_t((delta/frequency)*1000+(delta%frequency)*1000/frequency);
}
#ifdef _WIN32
inline uint32_t sampleClock(const Shared*shared){LARGE_INTEGER now;
 if(shared&&shared->clockFrequency&&QueryPerformanceCounter(&now))return counterTick(shared->clockTick,shared->clockStart,shared->clockFrequency,uint64_t(now.QuadPart),GetTickCount());
 return GetTickCount();
}
#endif
}

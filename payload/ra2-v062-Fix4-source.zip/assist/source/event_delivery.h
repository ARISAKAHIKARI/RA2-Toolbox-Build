#pragma once
#include <stdint.h>
// EventClass dispatch policy of MO_ExperienceEnhancements/OrderUtil.cpp.
// Single-player events go directly to DoList; LAN / Internet events MUST go
// through OutList and must not mutate the local simulation separately.
namespace assist { namespace eventdelivery {
constexpr int SingleCapacity=16384,SingleMask=16383;
enum class Lane : uint8_t { Unsupported, Single, Multiplayer };
// Explicitly verified vanilla modes only. Additional launcher modes require
// independent runtime ABI validation; never guess that they are singleplayer.
inline Lane classify(int mode){
 if(mode==0||mode==5)return Lane::Single;
 if(mode==3||mode==4)return Lane::Multiplayer;
 return Lane::Unsupported;
}
inline bool isMultiplayer(int mode){return classify(mode)==Lane::Multiplayer;}
inline bool isSingleplayer(int mode){return classify(mode)==Lane::Single;}
inline bool mayQueue(int mode){return classify(mode)!=Lane::Unsupported;}
inline bool singleRoom(int count,int next){
 return count>=0&&count<SingleCapacity&&next>=0;
}
inline void prepareSingle(unsigned char& executed,char& house,uint32_t& frame,
 char localHouse,int currentFrame){
 executed=static_cast<unsigned char>(executed&0xFEu);
 house=localHouse;frame=static_cast<uint32_t>(currentFrame)+1u;
}
}} // assist::eventdelivery

// PlaceAnywhere bypasses a shared legality check. It is restricted to confirmed
// Campaign/Skirmish sessions, including a second check at each intercepted call.
static unsigned char placementOriginal[6]={0x8A,0x81,0x03,0x17,0x00,0x00};
static unsigned char placementPatch[6];static unsigned char*placementCode;static bool placementPatched;
static bool offlinePlacement(){return eventdelivery::isSingleplayer(get<int>(0xA8B238));}
static bool __fastcall placementAllowed(uint32_t,uint32_t,const void*,uint32_t house){
 return sh&&!fault&&!sh->stop&&(sh->flags&BuildAnywhere)&&offlinePlacement()&&house==lastHouse;
}
static void __declspec(naked) placementObserver(){
 __asm {
  pushfd
  pushad
  mov ebx, esp
  sub esp, 528
  and esp, -16
  fxsave [esp]
  cld
  mov eax, [ebx+12]
  push dword ptr [eax+12]
  push dword ptr [eax+8]
  mov ecx, [ebx+24]
  xor edx, edx
  call placementAllowed
  test al, al
  jz placement_original_path
  fxrstor [esp]
  mov esp, ebx
  popad
  popfd
  mov al, 1
  ret 8
 placement_original_path:
  fxrstor [esp]
  mov esp, ebx
  popad
  popfd
  jmp dword ptr [placementCode]
 }
}
static void restorePlacement(){
 if(placementPatched){
  if(writeInputCodeGuarded(0x464AC0,placementPatch,placementOriginal,6))placementPatched=false;
  else{codeHookRegistry.markConflict(0x464AC0);snap.placementStatus=-3;}
 }
 if(!placementPatched)snap.placementStatus=0;
}
static void placementTick(){
 if(!(sh->flags&BuildAnywhere)){restorePlacement();return;}
 if(!offlinePlacement()){restorePlacement();snap.placementStatus=-3;return;}
 if(placementPatched){snap.placementStatus=codeHookRegistry.conflict(0x464AC0)?-3:1;return;}
 if(memcmp((void*)0x464AC0,placementOriginal,6)){snap.placementStatus=-1;return;}
 if(!bridgePinned){HMODULE module=0;if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)&placementObserver,&module)){snap.placementStatus=-1;return;}bridgePinned=true;}
 if(!placementCode)placementCode=makeInputTrampoline(0x464AC0,placementOriginal,6);
 if(!placementCode){snap.placementStatus=-1;return;}
 placementPatch[0]=0xE9;int offset=int(uint32_t(&placementObserver)-0x464AC0-5);memcpy(placementPatch+1,&offset,4);placementPatch[5]=0x90;
 placementPatched=writeInputCodeGuarded(0x464AC0,placementOriginal,placementPatch,6);snap.placementStatus=placementPatched?1:-1;
}

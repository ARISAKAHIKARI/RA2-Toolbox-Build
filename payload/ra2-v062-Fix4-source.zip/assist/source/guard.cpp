// Compile this tiny boundary with the MSVC x86 ABI. MinGW x86's DWARF
// exception mode cannot emit Windows SEH funclets reliably.
extern "C" void AssistTick();
extern "C" void AssistFault();
extern "C" void GuardedAssistTick() {
    __try { AssistTick(); }
    __except (1) { AssistFault(); }
}
extern "C" void CSCapture(unsigned*);
extern "C" void CSCaptureFault();
extern "C" void GuardedCSCapture(unsigned* registers) {
    __try { CSCapture(registers); }
    __except (1) { CSCaptureFault(); }
}

extern "C" void CursorCapture(unsigned*);
extern "C" void NativeEventCapture(const unsigned*);
extern "C" void NativeInputFault();
extern "C" void GuardedCursorCapture(unsigned* saved) { __try { CursorCapture(saved); } __except(1) { NativeInputFault(); } }
extern "C" void GuardedNativeEventCapture(const unsigned* saved) { __try { NativeEventCapture(saved); } __except(1) { NativeInputFault(); } }

extern "C" int CooperativeClick(unsigned,unsigned,unsigned,unsigned);
extern "C" int CooperativeDecide(unsigned);
extern "C" int CooperativeSell(unsigned);
extern "C" void CooperativeFault();
extern "C" int GuardedCooperativeClick(unsigned p,unsigned action,unsigned target,unsigned force){__try{return CooperativeClick(p,action,target,force);}__except(1){CooperativeFault();return 0;}}
extern "C" int GuardedCooperativeDecide(unsigned target){__try{return CooperativeDecide(target);}__except(1){CooperativeFault();return -1;}}
extern "C" int GuardedCooperativeSell(unsigned target){__try{return CooperativeSell(target);}__except(1){CooperativeFault();return 0;}}

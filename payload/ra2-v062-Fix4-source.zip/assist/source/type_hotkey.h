#pragma once
#include <stdint.h>
namespace typekeys {
struct Tap {
 int slot=-1;uint32_t tick=0,match=0;
 void clear(){slot=-1;}
 bool press(int next,uint32_t now,uint32_t scene,uint32_t interval){
  bool twice=next==slot&&scene==match&&uint32_t(now-tick)<=interval;
  slot=twice?-1:next;tick=now;match=scene;return twice;
 }
};
inline bool inView(int x,int y,int w,int h){return w>0&&h>0&&x>=0&&y>=0&&x<w&&y<h;}
inline bool csMission(int mission,int kind,bool active,bool selected,bool armed,bool allowed){
 return mission==2&&(kind==1||kind==2)&&active&&selected&&armed&&allowed;
}
}

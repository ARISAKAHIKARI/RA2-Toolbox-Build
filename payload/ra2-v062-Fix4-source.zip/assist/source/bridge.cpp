#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <mmsystem.h>
#include <stddef.h>
#include <utility>
#include "protocol.h"
#include "clock_ms.h"
#include "signatures.h"
#include "autoload.h"
#include "outgoing_batch.h"
#include "object_index.h"
#include "hook_policy.h"
#include "event_delivery.h"
#include "mega_queue_backend.h"
#include "constructor_adapter.h"
#include "entry_gate.h"
#include "tactical_decisions.h"
#include "object_event_backend.h"
#include "session_epoch.h"
#include "scheduler_policy.h"
#include "dispatch_router.h"
#include "order_policy.h"
#include "unit_task_arbiter.h"
#include "frame_prologue.h"
#include "frame_candidates.h"
extern "C" void* __cdecl memset(void*p,int c,size_t n){
 volatile unsigned char*d=(volatile unsigned char*)p;uint32_t word=uint32_t((unsigned char)c)*0x01010101u;
 while(n>=4){*(volatile uint32_t*)d=word;d+=4;n-=4;}while(n--)*d++=(unsigned char)c;return p;
}
extern "C" void* __cdecl memcpy(void*p,const void*q,size_t n){
 volatile unsigned char*d=(volatile unsigned char*)p;const volatile unsigned char*s=(const volatile unsigned char*)q;
 while(n>=4){*(volatile uint32_t*)d=*(const volatile uint32_t*)s;d+=4;s+=4;n-=4;}while(n--)*d++=*s++;return p;
}
extern "C" int __cdecl memcmp(const void*p,const void*q,size_t n){auto a=(const unsigned char*)p,b=(const unsigned char*)q;while(n--){if(*a!=*b)return *a-*b;++a;++b;}return 0;}
#include "input_patch.h" // Registry is needed by publishSnapshot(), defined below.
using namespace assist;
// Export concrete ABI data: an optimized mapName() may contain no contiguous
// string literal. The host validates both protocol and structure size before
// installing a hook; the release verifier can inspect these exports offline.
extern "C" __declspec(dllexport) const uint32_t AssistProtocolInfo[2]={Version,sizeof(Shared)};
extern "C" __declspec(dllexport) const wchar_t AssistMappingPrefix[]=L"Local\\RA2Assist_v037_";
static Shared*sh;static HANDLE mapping;static bool checked,good,fault;static DWORD last,slow;static uint32_t lastHouse,match,pendingAck;static int lastFrame;
static sessionepoch::Tracker sessionTracker;static Snapshot snap;
static bool assistFromGameFrame;
static unsigned nativeMegaQueueCallDepth; // own calls bypass the user-input CS interception
static volatile LONG schedulerBusy;
static volatile LONG frameLastMs;
static volatile LONG frameValidated;
static LONG frameLastSeen=-1,frameValidSteps;
static DWORD frameCallbackThread;
static volatile LONG messageGameThread; // Thread confirmed by WH_GETMESSAGE for this game window.

static uint8_t frameOriginal[12],framePatch[12];
static uint8_t *frameCode;
static unsigned frameSize;
static uint32_t frameAt=0x0055D360,frameCallTarget=0x0055D360;
static bool frameInstalled,frameTried,frameRestoreConflict;
static void restoreFrameDriver();
static uint32_t repairIDs[2048];static int repairCount,repairAt,repairDone;
static uint32_t repairAckRequest;static DWORD repairAckStarted;
static uint32_t lastIdle[3];static int prevBusy,prevPaused,prevCompleted;static bool productionBaseline;
static uint8_t techAllowed[MaxTypes];
static uint32_t typePointers[MaxTypes];
static ManualVersions manualVersions;static ObjectIndex worldObjects;static int indexedFrame=-1,indexedCount=-1;static uint32_t indexedItems;
static ObjectIndex advancedObjects;
static int outgoingFrame=-1,outgoingBudget;
static void recordReceipt(const gateway::Receipt&r){
 auto &s=snap.recentReceipts[snap.receiptWrite%RecentReceiptCapacity];
 s={r.serial,r.match,r.unit,r.target,r.queuedAt,r.observedAt,
    uint8_t(r.phase),uint8_t(r.failure),uint8_t(r.owner),0};
 ++snap.receiptWrite;
 if(snap.receiptCount<RecentReceiptCapacity)++snap.receiptCount;
}
static gateway::MissionObserver<128> missionObserver;
static taskarbiter::FrameArbiter<2048> actorFrameArbiter;
static taskarbiter::LeaseArbiter<2048> actorLeaseArbiter;
static bool bridgePinned,autoWas;static DWORD lastAuto,techRefresh;
static uint32_t repairSentID[4096];static DWORD repairSentAt[4096];
static void restoreClickHooks();static void resetCooperativeState();static void clickHooksTick(uint32_t);static void cooperativeTick(uint32_t,int,DWORD);
static void clearNativeOrders();static void restoreCSHook();static void restoreTech();static void clearFlashes();static void resetProduction();
static void clearOreOrders();static void cancelOreJob(uint32_t p);static void restorePlacement();
static uint32_t worldByID(uint32_t id);static bool rawOreCompatible(uint32_t unit,uint32_t refinery);
static void cancelUnloadPassenger(uint32_t p);
enum class EventLane {Repair,Boarding,Unload,Planning};
static int recurringBudget(EventLane lane);
struct CrateCache {int cellX,cellY,coords[3],preview;};
static CrateCache crateCache[MaxCrates];static int crateCount;static DWORD crateTick;static bool cratesOn;
static loading::Ledger<> loadLedger;
static int sceneFrame=-2147483647,sceneWidth,sceneHeight;static uint32_t sceneFlags,sceneTactical;
static DWORD sceneTick;static int cameraX,cameraY;static double sceneZoom;static uint32_t sceneResultSerial;
template<class T> static T get(uint32_t p){return *(T*)(uintptr_t)p;}
template<class T> static void put(uint32_t p,T v){*(T*)(uintptr_t)p=v;}
static bool read(uint32_t p,void*out,size_t n){SIZE_T got=0;return p>=0x10000&&uint64_t(p)+n<0x80000000ull&&ReadProcessMemory(GetCurrentProcess(),(void*)(uintptr_t)p,out,n,&got)&&got==n;}
template<class R,class...Args> static R call(uint32_t address,uint32_t self,Args...args){return ((R(__thiscall*)(void*,Args...))(uintptr_t)address)((void*)(uintptr_t)self,args...);}
struct Vec {uint32_t vt,items;int capacity;uint32_t flags;int count,step;};
static Vec vec(uint32_t p,int limit=16384){Vec v{};if(!read(p,&v,sizeof v)||v.count<0||v.count>limit||v.count>v.capacity||v.items<0x10000)return {};return v;}
static uint32_t item(Vec v,int i){return i>=0&&i<v.count?get<uint32_t>(v.items+i*4):0;}
static bool live(uint32_t p){return p>=0x10000&&get<int>(p+0x6c)>0&&get<bool>(p+0x74)&&!get<bool>(p+0x81)&&get<bool>(p+0x90);}
static int kind(uint32_t p){uint32_t v=get<uint32_t>(p);return v==0x7F5C70?2:v==0x7EB058?1:v==0x7E3EBC?3:v==0x7E22A4?0:-1;}
static uint32_t typeOf(uint32_t p,int k){return k>=0?get<uint32_t>(p+(k==3?0x520:k==1?0x6C0:0x6C4)):0;}
static void name(uint32_t t,uint16_t*out,int n){uint32_t p=get<uint32_t>(t+0x60);int i=0;for(;i<n-1;++i){uint16_t c;if(!read(p+i*2,&c,2)||!c)break;out[i]=c;}out[i]=0;if(i==0)for(i=0;i<n-1&&i<23;++i){out[i]=get<unsigned char>(t+0x24+i);if(!out[i])break;}}
static bool sameid(const char*a,const char*b){for(int i=0;i<24;++i){if(a[i]!=b[i])return false;if(!a[i])return true;}return true;}
static bool own(uint32_t p,uint32_t house){return live(p)&&get<uint32_t>(p+0x21c)==house;}
static void indexWorld(int frame){Vec all=vec(0xA8EC78);if(indexedFrame==frame&&indexedCount==all.count&&indexedItems==all.items)return;
 worldObjects.clear();for(int i=0;i<all.count;++i){uint32_t p=item(all,i);if(p>=0x10000){uint32_t id=0;if(read(p+0x10,&id,sizeof id)&&id)worldObjects.add(p,id);}}indexedFrame=frame;indexedCount=all.count;indexedItems=all.items;
 static int prunedFrame=-100000;if(manualVersions.used>=ManualVersions::Size/2&&(frame<prunedFrame||frame-prunedFrame>=300)){
  static ManualVersions liveVersions;liveVersions.copyLive(manualVersions,[](uint32_t id){uint32_t p=worldObjects.byId(id);uint32_t found=0;return p&&read(p+0x10,&found,sizeof found)&&found==id;});manualVersions=liveVersions;prunedFrame=frame;
 }
}
static void reset(){missionObserver.clear();actorFrameArbiter.clear();actorLeaseArbiter.clear();snap.megaQueueStatus=0;snap.megaQueueAccepted=snap.megaQueueRejected=0;snap.objectQueueStatus=0;snap.objectQueueAccepted=snap.objectQueueRejected=0;
 snap.queueSent=snap.queueFull=snap.queueTimingFailure=snap.planDeferred=snap.queuedEvents=snap.observedEvents=snap.commandRejected=snap.receiptCancelled=snap.receiptExpired=snap.receiptDropped=0;snap.receiptWrite=snap.receiptCount=0;restoreClickHooks();resetCooperativeState();if(sh)sh->clickHookStatus=0;clearOreOrders();restorePlacement();indexedFrame=indexedCount=-1;outgoingFrame=-1;clearNativeOrders();snap.labels=snap.selected=snap.transports=snap.used=snap.capacity=snap.swCount=0;snap.nativeHookStatus=snap.unloadIssued=0;snap.techOpen=0;restoreTech();restoreCSHook();clearFlashes();resetProduction();snap.inputPatchMask=0;repairCount=repairAt=repairDone=0;repairAckRequest=0;for(auto&v:lastIdle)v=0;productionBaseline=false;snap.typeCount=0;snap.threatCount=snap.crateCount=crateCount=0;cratesOn=false;autoWas=false;snap.autoRepair=0;snap.repairTotal=0;snap.techVisible=snap.techUnavailable=snap.techError=0;snap.crateHookStatus=snap.crateResultCount=0;snap.crateResultSerial=0;sceneResultSerial=0;snap.csHookStatus=snap.csConverted=0;loadLedger.clear();snap.loadUnits=snap.loadVehicles=snap.loadIssued=snap.loadWaiting=snap.loadUnassigned=0;memset(techAllowed,0,sizeof techAllowed);memset(repairSentID,0,sizeof repairSentID);}
static void mapName(wchar_t*out,DWORD p){const wchar_t*s=AssistMappingPrefix;int i=0;while(*s)out[i++]=*s++;wchar_t d[16];int n=0;do{d[n++]=L'0'+p%10;p/=10;}while(p);while(n)out[i++]=d[--n];out[i]=0;}
static void disconnect(){restoreFrameDriver();frameTried=false;InterlockedExchange(&messageGameThread,0);reset();sessionTracker.update(false,0,-1,-1);if(sh)UnmapViewOfFile(sh);sh=nullptr;if(mapping)CloseHandle(mapping);mapping=nullptr;lastHouse=pendingAck=0;}
static bool signatures(){for(auto&s:Signatures){unsigned char b[12];if(!read(s.address,b,s.length)||memcmp(b,s.bytes,s.length))return false;}return true;}
static void notifyHost(){
 if(!sh||!sh->hostWindow)return;
 if(!InterlockedCompareExchange(&sh->hostNotifyPending,1,0)&&!PostMessageW((HWND)(uintptr_t)sh->hostWindow,DataMessage,sh->pid,0))InterlockedExchange(&sh->hostNotifyPending,0);
}
static uint32_t micros(LARGE_INTEGER from,LARGE_INTEGER to,LARGE_INTEGER frequency){return frequency.QuadPart>0?uint32_t((to.QuadPart-from.QuadPart)*1000000/frequency.QuadPart):0;}
static void publishSnapshot(DWORD now){
 bool copyTypes=sh->seq==0||sh->data.match!=snap.match||sh->data.typeCount!=snap.typeCount;
 snap.hookConflicts=int(codeHookRegistry.conflicts());
 snap.hookInstalled=int(codeHookRegistry.installed());
 snap.sampledTick=now;InterlockedIncrement(&sh->seq);
 // Only copy populated arrays. The live type table is static within a match.
 memcpy(&sh->data,&snap,offsetof(Snapshot,label));
 memcpy(sh->data.label,snap.label,size_t(snap.labels)*sizeof(Label));
 memcpy(sh->data.supers,snap.supers,size_t(snap.swCount)*sizeof(Super));
 if(copyTypes)memcpy(sh->data.types,snap.types,size_t(snap.typeCount)*sizeof(Type));
 sh->data.threatCount=snap.threatCount;sh->data.crateCount=snap.crateCount;
 memcpy(sh->data.threats,snap.threats,size_t(snap.threatCount)*sizeof(Threat));memcpy(sh->data.crates,snap.crates,size_t(snap.crateCount)*sizeof(CrateMark));
 memcpy(&sh->data.techVisible,&snap.techVisible,sizeof(Snapshot)-offsetof(Snapshot,techVisible));
 MemoryBarrier();InterlockedIncrement(&sh->seq);
 if(pendingAck){MemoryBarrier();sh->ack=pendingAck;pendingAck=0;}
 notifyHost();
}
using Event=vanilla::Packet;
static_assert(sizeof(Event)==111,"YRpp NetworkEvent ABI mismatch");
static int outgoingRoom(){
 int frame=get<int>(0xA8ED84);if(frame!=outgoingFrame){outgoingFrame=frame;outgoingBudget=24;}
 if(outgoingBudget<=0||!eventdelivery::mayQueue(get<int>(0xA8B238)))return 0;
 // Match MO_ExperienceEnhancements/OrderUtil.cpp: SP uses DoList, MP uses
 // OutList. An OutList-only command can be acknowledged but never executed
 // by the single-player simulation.
 if(eventdelivery::isSingleplayer(get<int>(0xA8B238))){
  int count=get<int>(0x8B41F8),next=get<int>(0x8B4200);
  if(!eventdelivery::singleRoom(count,next))return 0;
  int available=eventdelivery::SingleCapacity-count;
  return available<outgoingBudget?available:outgoingBudget;
 }
 int count=get<int>(0xA802C8),tail=get<int>(0xA802D0);
 if(!queueAvailable(count,tail))return 0;
 int room=112-count;return room<outgoingBudget?room:outgoingBudget;
}
// Source: MO_ExperienceEnhancements/OrderUtil.cpp OU_SndTimings().
// 0x7E1530 contains the game's time callback pointer (not a clock value).
// Preserve EBP and the nonvolatile registers across the historical callback.
static bool gameSendTiming(uint32_t& result){
 uint32_t callback=get<uint32_t>(0x7E1530u);
 if(callback<0x10000u)return false;
 MEMORY_BASIC_INFORMATION mbi{};
 if(!VirtualQuery((const void*)(uintptr_t)callback,&mbi,sizeof(mbi))||mbi.State!=MEM_COMMIT||
    (mbi.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;
 DWORD protection=mbi.Protect&0xFF;
 if(protection!=PAGE_EXECUTE&&protection!=PAGE_EXECUTE_READ&&
    protection!=PAGE_EXECUTE_READWRITE&&protection!=PAGE_EXECUTE_WRITECOPY)return false;
 __asm {
  push ebx
  push esi
  push edi
  push ebp
  mov eax,callback
  call eax
  pop ebp
  pop edi
  pop esi
  pop ebx
  mov result,eax
 }
 return true;
}
static bool enqueue(Event&e){
 if(!sh||sh->stop||fault||snap.status!=1||!lastHouse||get<bool>(0xA8BC60+25)){++snap.commandRejected;return false;}
 if(!eventdelivery::mayQueue(get<int>(0xA8B238))){++snap.commandRejected;return false;}
 if(!outgoingRoom()){++snap.queueFull;return false;}
 // Fail closed if the game callback cannot be resolved; never fabricate its
 // output using a Windows wall-clock timer.
 uint32_t timing=0;
 if(!gameSendTiming(timing)){++snap.queueTimingFailure;return false;}
 if(eventdelivery::isSingleplayer(get<int>(0xA8B238))){
  constexpr uint32_t countAddr=0x8B41F8,nextAddr=0x8B4200;
  int count=get<int>(countAddr),next=get<int>(nextAddr);
  if(!eventdelivery::singleRoom(count,next)){++snap.queueFull;return false;}
  next&=eventdelivery::SingleMask;
  Event local=e;
  uint32_t hp=get<uint32_t>(0xA83D4C);
  if(hp<0x10000u){++snap.queueTimingFailure;return false;}
  eventdelivery::prepareSingle(local.executed,local.house,local.frame,
   get<char>(hp+0x30),get<int>(0xA8ED84));
  memcpy((void*)(0x8B4204u+unsigned(next)*sizeof(Event)),&local,sizeof local);
  put<uint32_t>(0xA70204u+unsigned(next)*4u,timing);
  put<int>(nextAddr,(next+1)&eventdelivery::SingleMask);
  put<int>(countAddr,count+1);
 }else{
  constexpr uint32_t p=0xA802C8;
  int count=get<int>(p),tail=get<int>(p+8);
  if(!queueAvailable(count,tail)){++snap.queueFull;return false;}
  // Multiplayer MUST NOT write DoList or alter constructor's executed,
  // house and frame fields: all peers use the vanilla OutList transfer.
  memcpy((void*)(p+12+tail*sizeof(Event)),&e,sizeof e);
  put<uint32_t>(p+12+128*sizeof(Event)+tail*4,timing);
  put<int>(p+8,(tail+1)&127);put<int>(p,count+1);
 }
 --outgoingBudget;++snap.queueSent;++snap.queuedEvents;return true;
}
static entrygate::Snapshot currentEntryBoundary(){
 const DWORD confirmedGameThread=DWORD(InterlockedCompareExchange(&messageGameThread,0,0));
 const int session=get<int>(0xA8B238);
 return entrygate::Snapshot{match,match,session,
  sh&&!sh->stop&&!fault&&snap.status==1,
  get<bool>(0xA8BC60+25),
  confirmedGameThread&&GetCurrentThreadId()==confirmedGameThread,
  outgoingRoom()>0};
}
// ENTRY: the only ordinary EventClass construction-and-submit channel.
// Caller / planner supplies a semantic intent, never a raw address or packet.
// This does not replace the two separately verified high-level append backends.
static bool submitConstructed(const intent::EventOrder& order){
 const entrygate::Snapshot boundary=currentEntryBoundary();
 if(entrygate::admit(boundary)!=entrygate::Outcome::Pass){++snap.commandRejected;return false;}
 // No speculative UI/probe operations: only previously supported game orders
 // reach an engine call. The other YRpp constructors are exposed as ABI
 // descriptors for offline tests, not remotely callable game commands.
 if(constructors::admit(order)!=constructors::Verdict::Ready){++snap.commandRejected;return false;}
 Event packet{};
 const auto state=constructors::fill(packet,order,
  [](uint32_t address,uint32_t self,auto... args){call<void>(address,self,args...);});
 if(state!=constructors::Verdict::Ready){++snap.commandRejected;return false;}
 return enqueue(packet); // SP DoList / MP OutList, timing and receipt centrally.
}
// Original game QueueMegaMission verified in two user-provided 32-bit EXEs.
// x86 __fastcall ABI (NOT the EventClass ctor):
// ECX=mission, EDX=pointer to a 5-byte abstract target,
// stack=(sourceID, sourceKind, pointer to abstract destination), ret 0x0C.
// It calls 0x4C6860, copies 111 bytes to the *game's own* OutList,
// obtains native send timing, and updates ring pointers itself.
// NEVER hand-write OutList after a successful native call.
static bool nativeMegaSignature(){
 static const uint8_t prologue[]={0x56,0x57,0x8B,0x7C,0x24,0x7C,0x83,0xEC,0x08,0x8B,0xF4,
  0x83,0xEC,0x08,0x89,0x3E,0x88,0x46,0x04};
 static const uint8_t ctorCall[]={0xE8,0x6B,0xF9,0xE7,0xFF}; // call 0x4C6860
 static const uint8_t queueCopy[]={0xB9,0x1B,0x00,0x00,0x00,0xF3,0xA5};
 static const uint8_t nativeTimer[]={0xFF,0x15,0x30,0x15,0x7E,0x00};
 static const uint8_t nativeReturn[]={0xC2,0x0C,0x00};
 return memcmp((const void*)0x646E95,prologue,sizeof prologue)==0
  && memcmp((const void*)0x646EF0,ctorCall,sizeof ctorCall)==0
  && memcmp((const void*)0x646F16,queueCopy,sizeof queueCopy)==0
  && memcmp((const void*)0x646F20,nativeTimer,sizeof nativeTimer)==0
  && memcmp((const void*)0x646F55,nativeReturn,sizeof nativeReturn)==0;
}
static bool nativeMegaOriginalOrOwned(); // implemented after the CS hook definitions
static bool nativeMegaTimingAvailable(){
 uint32_t callback=get<uint32_t>(0x7E1530u);if(callback<0x10000u)return false;
 MEMORY_BASIC_INFORMATION mbi{};
 if(!VirtualQuery((const void*)(uintptr_t)callback,&mbi,sizeof mbi)||mbi.State!=MEM_COMMIT||
    (mbi.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return false;
 DWORD protection=mbi.Protect&0xFF;
 return protection==PAGE_EXECUTE||protection==PAGE_EXECUTE_READ||
        protection==PAGE_EXECUTE_READWRITE||protection==PAGE_EXECUTE_WRITECOPY;
}
static bool submitMegaMission(uint32_t house,uint32_t id,int mission,
 uint32_t target,uint8_t targetTag,uint32_t destination,uint8_t destinationTag,
 uint32_t nearest,uint8_t nearestTag){
 const auto selected=sh&&sh->megaQueueMode==1 ? megaqueue::Backend::GameQueueMegaMission
                                            : megaqueue::Backend::ConstructAndEnqueue;
 if(selected==megaqueue::Backend::ConstructAndEnqueue){
  return submitConstructed(intent::mega(get<int>(house+0x30),id,mission,target,targetTag,
    destination,destinationTag,nearest,nearestTag));
 }
 const int mode=get<int>(0xA8B238);
 megaqueue::Capability cap{};
 cap.isMultiplayer=eventdelivery::isMultiplayer(mode);
 cap.isSingleplayer=eventdelivery::isSingleplayer(mode);
 // Own CS Hook can be chained; unknown detours are always rejected.
 cap.engineSignature=nativeMegaSignature();
 cap.knownOriginalOrOwnedHook=nativeMegaOriginalOrOwned();
 cap.timingCallbackExecutable=nativeMegaTimingAvailable();
 auto result=megaqueue::admit(selected,cap,nearest,nearestTag);
 if(result!=megaqueue::Result::Queued){snap.megaQueueStatus=int(result);
   ++snap.megaQueueRejected;++snap.commandRejected;return false;}
 const entrygate::Outcome gateOutcome=entrygate::admit(currentEntryBoundary());
 if(gateOutcome!=entrygate::Outcome::Pass){
  if(gateOutcome==entrygate::Outcome::NoRoom){
   snap.megaQueueStatus=int(megaqueue::Result::QueueFull);++snap.queueFull;
  }else{
   snap.megaQueueStatus=int(megaqueue::Result::NotReady);
  }
  ++snap.megaQueueRejected;++snap.commandRejected;return false;
 }
 const megaqueue::Target targetArg{target,targetTag,{0,0,0}};
 const megaqueue::Target destinationArg{destination,destinationTag,{0,0,0}};
 using Native=bool (__fastcall*)(int,const megaqueue::Target*,uint32_t,uint32_t,const megaqueue::Target*);
 const int beforeCount=get<int>(0xA802C8),beforeTail=get<int>(0xA802D0);
 ++nativeMegaQueueCallDepth;
 bool success=((Native)(uintptr_t)0x646E90)(mission,&targetArg,id,0x34,&destinationArg);
 --nativeMegaQueueCallDepth;
 const int afterCount=get<int>(0xA802C8),afterTail=get<int>(0xA802D0);
 if(!megaqueue::appended(beforeCount,beforeTail,afterCount,afterTail)){
  snap.megaQueueStatus=int(megaqueue::Result::NoAppend);
  ++snap.megaQueueRejected;++snap.commandRejected;return false;
 }
 // A physical append is the only delivery claim. Treat a surprising
 // false return plus a proven append as queued, never retry the same order.
 (void)success;
 --outgoingBudget;++snap.queueSent;++snap.queuedEvents;++snap.megaQueueAccepted;
 snap.megaQueueStatus=int(megaqueue::Result::Queued);
 return true;
}
// The high-level virtual call is guarded at invocation. We never jump through
// a foreign detour or chain our own 0x6FFE00 input hook from this path.
static bool nativeObjectUnhooked(); // definition follows input-hook state
static bool nativeObjectSignature(){
 static const unsigned char original[]={0x83,0xEC,0x78,0x56,0x57};
 // This original prologue is also captured in our input-hook module.
 return memcmp((const void*)0x6FFE00,original,sizeof original)==0;
}
static bool loadInterfaces();
static void cancelReceiptTicket(uint32_t session,uint32_t ticket){
 missionObserver.cancelTicket(session,ticket,gateway::Failure::Superseded,
  [](const gateway::Receipt& receipt){recordReceipt(receipt);++snap.receiptCancelled;});
}
static void releaseAutoOwner(uint32_t actor){
 int index=actorLeaseArbiter.find(actor);
 if(index>=0){auto old=actorLeaseArbiter.leases[index];cancelReceiptTicket(old.match,old.serial);}
 actorLeaseArbiter.manual(actor);
}
// Unified game-thread command gateway. All existing features submit normal
// EventClass orders here; no event is executed directly on just one peer.
// Constructors/ABI are verified against the supported game build at startup.
static bool nativeMission(uint32_t house,uint32_t id,int mission,uint32_t target,
                          uint32_t dest,int destTag,uint32_t nearest=0,int nearestTag=0,
                          taskarbiter::Owner owner=taskarbiter::Owner::Generic,uint32_t* receiptID=nullptr){
 if(!id||!house||house!=lastHouse||!eventdelivery::mayQueue(get<int>(0xA8B238))||!loadInterfaces())return false;
 const uint32_t submittedAt=sampleClock(sh);
 const gateway::Context ctx{match,submittedAt,sh&&!sh->stop&&!fault&&snap.status==1,
                            get<bool>(0xA8BC60+25)};
 const gateway::Intent intent{match,submittedAt,id,target,manualVersions.get(id)};
 if(gateway::validate(ctx,intent,3500)!=gateway::Failure::None){++snap.commandRejected;return false;}
 // The command gateway, not just the planner, owns the final game-thread
 // actor/ownership preflight. Never serialize a vanished/foreign actor ID.
 uint32_t object=worldByID(id);
 uint32_t targetObject=target?worldByID(target):0;
 uint32_t destObject=(destTag==0x34&&dest)?worldByID(dest):0;
 auto reject=orderpolicy::mission(object!=0,object&&own(object,house),object&&live(object),
  mission,target!=0,!target||targetObject!=0,destTag==0x34,destObject!=0);
 if(reject!=orderpolicy::Reject::None){++snap.commandRejected;return false;}
 const int frame=get<int>(0xA8ED84);
 actorFrameArbiter.begin(match,frame);
 if(!actorFrameArbiter.canIssue(id,manualVersions.get(id))||
    !actorLeaseArbiter.canIssue(match,frame,id,object,manualVersions.get(id),owner)){
  ++snap.commandRejected;return false;
 }
 gateway::MissionState before{};
 before.valid=true;before.mission=get<int>(object+0xAC);
 before.queued=get<int>(object+0xB4);before.carrier=get<uint32_t>(object+0x11C);
 if(!submitMegaMission(house,id,mission,target,target?0x34:0,
                       dest,uint8_t(destTag),nearest,uint8_t(nearestTag)))return false;
 actorFrameArbiter.record(id,manualVersions.get(id),owner);
 // A queued EventClass is not an executed mission. This read-only tracker
 // records the later state transition; unsupported events stay unconfirmed.
 uint32_t ticket=missionObserver.record(match,id,destTag==0x34?dest:target,mission,
                             frame,submittedAt,before,owner);
 taskarbiter::Lease superseded{};
 actorLeaseArbiter.record(match,frame,id,object,manualVersions.get(id),owner,ticket,&superseded);
 if(superseded.serial)cancelReceiptTicket(superseded.match,superseded.serial);
 if(receiptID)*receiptID=ticket;
 if(!ticket)++snap.receiptDropped;
 else {gateway::Receipt queued{};
  gateway::Intent ticketIntent{match,submittedAt,id,destTag==0x34?dest:target,manualVersions.get(id)};
  gateway::planned(queued,ticket,ticketIntent);gateway::submitted(queued,submittedAt);
  queued.owner=owner;recordReceipt(queued);
 }
 return true;
}
static bool nativeObjectEvent(int houseIndex,int eventType,uint32_t objectId){
 if(houseIndex<0||houseIndex>=32||!objectId||!lastHouse){++snap.commandRejected;return false;}
 uint32_t object=worldByID(objectId);
 uint32_t owner=object?get<uint32_t>(object+0x21C):0;
 uint32_t localIndex=get<uint32_t>(lastHouse+0x30);
 uint32_t ownerIndex=owner>=0x10000?get<uint32_t>(owner+0x30):0xFFFFFFFFu;
 const int mode=get<int>(0xA8B238);
 if(!eventdelivery::mayQueue(mode)){++snap.commandRejected;return false;}
 const bool mp=eventdelivery::isMultiplayer(mode);
 auto reject=orderpolicy::objectEvent(eventType,object!=0,object&&live(object),
  uint32_t(houseIndex)==localIndex,uint32_t(houseIndex)==ownerIndex,mp);
 if(reject!=orderpolicy::Reject::None){++snap.commandRejected;return false;}
 if(!sh||sh->objectQueueMode!=1){
  return submitConstructed(intent::object(houseIndex,eventType,objectId));
 }
 const uint32_t vtable=object?get<uint32_t>(object):0;
 uint32_t method=0;
 const bool tableReadable=vtable>=0x10000u&&
   read(vtable+objectqueue::ClickedEventVtableOffset,&method,sizeof method);
 const entrygate::Snapshot boundary=currentEntryBoundary();
 objectqueue::Capability cap{};
 cap.multiplayer=mp;
 cap.validEvent=eventType==0x15||eventType==0x16;
 cap.actorOwnedAlive=object&&live(object)&&kind(object)==3&&own(object,lastHouse);
 cap.signature=nativeObjectSignature();
 cap.unhooked=nativeObjectUnhooked();
 cap.vtableValid=tableReadable&&method==objectqueue::ClickedEventVanilla;
 cap.sameGameThread=boundary.gameThread;
 cap.ready=boundary.active&&!boundary.chat&&loadInterfaces();
 cap.hasRoom=boundary.queueRoom;
 auto decision=objectqueue::admit(objectqueue::Backend::ClickedEvent,cap);
 if(decision!=objectqueue::Result::Appended){snap.objectQueueStatus=int(decision);
   ++snap.objectQueueRejected;if(decision==objectqueue::Result::QueueFull)++snap.queueFull;
   else ++snap.commandRejected;return false;}
 // Use the YRpp virtual API, not an arbitrary raw event buffer. In these
 // supported builds the vtable slot +0x374 resolves to vanilla 0x6FFE00.
 // NetworkEvents is unsigned char; x86 thiscall passes a 32-bit stack slot.
 const int preCount=get<int>(0xA802C8),preTail=get<int>(0xA802D0);
 using NativeClicked=bool (__thiscall*)(void*,uint32_t);
 const bool accepted=((NativeClicked)(uintptr_t)method)((void*)(uintptr_t)object,uint32_t(eventType));
 const int postCount=get<int>(0xA802C8),postTail=get<int>(0xA802D0);
 if(!objectqueue::appended(preCount,preTail,postCount,postTail)){
  // DO NOT retry through handcrafted enqueue! A return of true can hide
  // a full native queue, or there may be an incompatible runtime detour.
  snap.objectQueueStatus=int(objectqueue::Result::NoAppend);
  ++snap.objectQueueRejected;++snap.commandRejected;
  return false;
 }
 (void)accepted; // Real append outranks the engine's unreliable bool.
 --outgoingBudget;++snap.queueSent;++snap.queuedEvents;++snap.objectQueueAccepted;
 snap.objectQueueStatus=int(objectqueue::Result::Appended);
 return true;
}
static bool nativeProduceEvent(uint32_t house,const Type&t){
 const int mode=get<int>(0xA8B238);
 if(!house||!eventdelivery::mayQueue(mode))return false;
 // Native build authorization and prerequisite consistency have NOT yet been
 // verified in multiplayer. Default to refusing speculative production there.
 const bool mp=eventdelivery::isMultiplayer(mode);
 const bool unsafeAllowed=(sh&&sh->flags&UnsafeTech)!=0;
 if(mp&&!unsafeAllowed)return false;
 intent::EventOrder order{};
 const decisions::ProductionView view{get<int>(house+0x30),t.kind,t.index,t.naval,true,mp,unsafeAllowed};
 if(!decisions::planProduction(view,order)){++snap.commandRejected;return false;}
 return submitConstructed(order);
}
static bool repairEvent(uint32_t house,uint32_t id){return nativeObjectEvent(get<int>(house+0x30),0x15,id);}
#include "autoload_bridge.h"
static bool selection(uint32_t p){return call<bool>(0x6FBFA0,p);}
static void unselect(){((void(__cdecl*)())0x48DC90)();}
static int selectFilter(uint32_t house,int action){
 static uint32_t chosen[4096];int n=0;Vec v=vec(action==EmptyTransports?0xA8EC78:0xA8ECB8);
 for(int i=0;i<v.count&&n<4096;++i){uint32_t p=item(v,i);if(!own(p,house))continue;int k=kind(p);if(k<0||k==3)continue;uint32_t t=typeOf(p,k);if(!t)continue;
 bool harv=k==2&&(get<bool>(t+0xE0E)||get<bool>(t+0xE0F)),eng=k==1&&get<bool>(t+0xEC3);
 bool ok=action==CombatSelection?(!harv&&!eng&&get<bool>(t+0xDBC)):action==EmptyTransports?(get<int>(t+0x5E0)>0&&get<int>(p+0x114)==0):get<int>(p+0x6c)<get<int>(t+0xA0);
 if(ok)chosen[n++]=p;
 }if(!n)return 0;unselect();for(int i=0;i<n;++i)selection(chosen[i]);return n;
}
static int findIdle(uint32_t house,int mode){Vec v=vec(0xA8EC78);uint32_t next=0,first=0,nextid=0xffffffff,firstid=0xffffffff;int slot=mode-IdleHarvester;
 for(int i=0;i<v.count;++i){uint32_t p=item(v,i);if(!own(p,house))continue;int k=kind(p);if(k<0||k==3)continue;uint32_t t=typeOf(p,k);if(!t)continue;
 bool category=slot==0?(k==2&&(get<bool>(t+0xE0E)||get<bool>(t+0xE0F))):slot==1?(k==1&&get<bool>(t+0xEC3)):(get<int>(t+0x5E0)>0&&get<int>(p+0x114)==0);
 if(!category||!idleMission(get<int>(p+0xAC),get<int>(p+0xB4),get<uint32_t>(p+0x2B4)!=0,get<bool>(p+0x1C8)))continue;
 uint32_t id=get<uint32_t>(p+0x10);if(id<firstid){firstid=id;first=p;}if(id>lastIdle[slot]&&id<nextid){nextid=id;next=p;}
 }if(!next){next=first;nextid=firstid;}if(!next)return 0;lastIdle[slot]=nextid;unselect();selection(next);
 uint32_t tactical=get<uint32_t>(0x887324);if(tactical)call<void>(0x6D2420,tactical,(void*)(next+0x9C),0);return 1;
}
static void scanTypes(){snap.typeCount=0;const uint32_t arrays[]={0xA8B218,0xA8E348,0xA83CE0,0xA83C68};const int kinds[]={3,16,40,7};
 for(int k=0;k<4;++k){Vec v=vec(arrays[k],4096);for(int i=0;i<v.count&&snap.typeCount<MaxTypes;++i){uint32_t t=item(v,i);if(!t||!validType(get<int>(t+0x634),get<bool>(t+0x232),get<bool>(t+0xD54),get<uint32_t>(t+0x6CC)))continue;
 typePointers[snap.typeCount]=t;auto&d=snap.types[snap.typeCount++];memset(&d,0,sizeof d);memcpy(d.id,(void*)(t+0x24),23);name(t,d.name,40);d.kind=kinds[k];d.index=i;d.naval=get<bool>(t+0xCCE);d.cost=get<int>(t+0x610);
 }}
}
#include "sidebar.h"
#include "type_select_bridge.h"
static uint32_t rawObjectID(uint32_t pointer);
#include "raw_combat.h"
static bool rawArmed(uint32_t p){int k=kind(p);uint32_t type=typeOf(p,k);if(!type)return false;int slots[2],count=rawWeaponSlots(p,type,slots);return count&&rawWeapon(type,get<float>(p+0x150),slots[0])>=0x10000;}
#include "native_orders_bridge.h"
#include "auto_cs_bridge.h"
static bool nativeMegaOriginalOrOwned(){
 static const uint8_t original[]={0x83,0xEC,0x70,0x32,0xC0};
 return memcmp((const void*)0x646E90,original,sizeof original)==0 ||
       (csPatched&&memcmp((const void*)0x646E90,csPatch,sizeof csPatch)==0);
}
#include "native_input_hooks.h"
static bool nativeObjectUnhooked(){
 // Avoid re-entering NativeEventCapture: it interprets ClickedEvent as a
 // manual user click. A command generated by our own planner is not one.
 return !eventPatched && nativeObjectSignature();
}
#include "external_orders_bridge.h"
#include "placement_bridge.h"
#include "cooperative_bridge.h"
// Reserve a share for other active task families, then let a lone family use
// the remaining capacity. All sends still obey the shared 24-event frame cap.
static int recurringBudget(EventLane lane){
 bool external=nativeCount||sh->plannerTracking||sh->planRequest!=sh->planAck||sh->cooperativePlan!=sh->cooperativeAck;
 bool repairs=repairAt<repairCount,loading=loadLedger.count!=0,unloading=unloadCount!=0;
 if(lane==EventLane::Planning)return repairs||(sh->flags&AutoRepair)||loading||unloading?12:24;
 if(external)return 4;
 return 24-4*((lane!=EventLane::Repair&&repairs)+(lane!=EventLane::Boarding&&loading)+(lane!=EventLane::Unload&&unloading));
}
static void selectionCommand(uint32_t house,DWORD now){
 uint32_t request=sh->selectRequest;if(request==sh->selectAck)return;MemoryBarrier();
 int result=0,count=0;
 if(sh->selectMatch!=match||DWORD(now-sh->selectTick)>1500)result=-7;
 else if(get<bool>(0xA8BC60+25))result=-8;
 else {count=sh->selectIndex==-2?selectVariant(house,sh->selectGlobal!=0):selectType(house,sh->selectIndex,sh->selectGlobal!=0);if(count<0){result=count;count=0;}else result=1;}
 sh->selectResult=result;sh->selectCount=count;MemoryBarrier();sh->selectAck=request;
}
static DWORD clampedRepairInterval(uint32_t ms){
 return ms<500?500:ms>30000?30000:ms;
}
static int collectRepairs(uint32_t house,DWORD now){Vec v=vec(0xA8EB40);repairCount=repairAt=repairDone=0;
 for(int i=0;i<v.count&&repairCount<2048;++i){uint32_t p=item(v,i);if(!own(p,house))continue;uint32_t t=typeOf(p,3),id=get<uint32_t>(p+0x10),slot=id&4095;
  const bool recent=repairSentID[slot]==id&&DWORD(now-repairSentAt[slot])<5000;
  if(t&&decisions::shouldRepair({get<int>(p+0x6C),get<int>(t+0xA0),true,
      get<bool>(p+0x6E8),recent}))repairIDs[repairCount++]=id;
 }return repairCount;
}
static int superSelect(uint32_t house,int index){Vec v=vec(house+0x254,256);uint32_t p=item(v,index);if(!p||get<uint32_t>(p+0x2C)!=house||!get<bool>(p+0x6D))return -4;
 if(!call<char>(0x6CC360,p))return -5;uint32_t t=get<uint32_t>(p+0x28);if(!t)return -4;
 if(get<int>(t+0xBC)==0){return submitConstructed(intent::superWeapon(
  get<int>(house+0x30),0x12,get<int>(t+0x98),vanilla::Cell{0,0}))?1:-6;}
 put<uint32_t>(0x88098C,0);put<uint32_t>(0x880990,0);put<int>(0x880994,-1);call<void>(0x4A8BF0,0x87F7E8,(void*)nullptr);call<void>(0x4AC8C0,0x87F7E8,0);call<void>(0x4AC660,0x87F7E8,0);
 put<unsigned char>(0x88099A,0);put<unsigned char>(0x88099B,0);put<unsigned char>(0x88099C,0);put<int>(0x8809A0,index);unselect();return 1;
}
static int namedSuper(uint32_t house,int command){const char* id=command==SelectIron?"IronCurtainSpecial":"ChronoSphereSpecial";Vec v=vec(house+0x254,256);
 for(int i=0;i<v.count;++i){uint32_t p=item(v,i);if(!p)continue;uint32_t t=get<uint32_t>(p+0x28);if(t&&sameid((const char*)(t+0x24),id))return superSelect(house,i);}return -4;
}
static void command(uint32_t house,DWORD now){uint32_t req=sh->request;if(req==sh->ack||req==repairAckRequest)return;MemoryBarrier();int c=sh->command,arg=sh->arg;int result=1,n=0;
 if(sh->requestMatch!=match||DWORD(now-sh->requestTick)>3500){result=-7;}
 else if(get<bool>(0xA8BC60+25)){result=-8;}
 else if(c==Repair){
  n=collectRepairs(house,now);
  if(n){repairAckRequest=req;repairAckStarted=now;sh->result=1;sh->count=0;return;}
 }
 else if(c==SelectType){n=selectType(house,arg,sh->arg2!=0);if(n<0){result=n;n=0;}}
 else if(c==SelectVariant){n=selectVariant(house,sh->arg2!=0);if(n<0){result=n;n=0;}}
 else if(c==SmartUnload){int sent=smartUnload(house);if(sent<0)result=sent;else n=sent;}
 else if(c==CancelAdvanced){Vec v=vec(0xA8ECB8);for(int i=0;i<v.count;++i){uint32_t p=item(v,i);if(p&&own(p,house)){cancelAutomatic(p);++n;}}}
 else if(c==AutoBoard){result=autoLoad(house);n=snap.loadIssued;}
 else if(c>=CombatSelection&&c<=DamagedSelection)n=selectFilter(house,c);
 else if(c>=IdleHarvester&&c<=IdleTransport)n=findIdle(house,c);
 else if(c==ClearBeacons){call<void>(0x431410,0x89C3B0,get<int>(house+0x30));n=1;}
 else if(c==RevealMap){
  // Early in a restarted match, House can be valid before its map-cell array.
  // A void reveal call against that transitional state silently does nothing.
  uint32_t cells=get<uint32_t>(0x87F7E8+316);
  int capacity=get<int>(0x87F7E8+320);
  if(cells<0x10000||capacity<=0||capacity>512*512)result=-14;
  else {call<void>(0x577D90,0x87F7E8,(void*)house);n=1;}
 }
 else if(c==OpenTech){
  // Only local sidebars are changed; production still uses a native event.
  {snap.techOpen=arg!=0;memcpy(techAllowed,sh->techAllowed,sizeof techAllowed);snap.techError=0;if(snap.techOpen)refreshTech(house,now);else restoreTech();n=snap.techVisible;if(snap.techError<0)result=-11;}}
 else if(c==SelectSuper){result=superSelect(house,arg);n=result>0;}
 else if(c==SelectIron||c==SelectChrono){result=namedSuper(house,c);n=result>0;}
 else if(c==Produce){
  if(!snap.techOpen||arg<0||arg>=snap.typeCount||!techAllowed[arg])result=-4;
  else if(!decisions::canProduceInSession(eventdelivery::isMultiplayer(get<int>(0xA8B238)),(sh->flags&UnsafeTech)!=0)){++snap.commandRejected;result=-13;}
  else{auto&t=snap.types[arg];result=nativeProduceEvent(house,t)?1:-6;n=result>0;}
 }
 else result=-4;
 sh->result=result;sh->count=n;pendingAck=req;
}
static void repairTick(uint32_t house,DWORD now){bool automatic=(sh->flags&AutoRepair)!=0;DWORD interval=clampedRepairInterval(sh->repairMs);
 if(!repairAckRequest&&automatic&&(!autoWas||(DWORD(now-lastAuto)>=interval&&repairAt>=repairCount))){collectRepairs(house,now);lastAuto=now;}
 if(!repairAckRequest&&!automatic&&autoWas)repairCount=repairAt=0;autoWas=automatic;snap.autoRepair=automatic;
 static int budgetFrame=-1,budget;static uint32_t budgetMatch;
 int frame=get<int>(0xA8ED84);if(budgetFrame!=frame||budgetMatch!=match){budgetFrame=frame;budgetMatch=match;budget=recurringBudget(EventLane::Repair);}
 if(repairAt<repairCount&&budget>0){
  indexWorld(frame);
  while(repairAt<repairCount&&budget>0){uint32_t id=repairIDs[repairAt],p=worldByID(id),slot=id&4095;
  const bool recent=repairSentID[slot]==id&&DWORD(now-repairSentAt[slot])<5000;
  if(p&&kind(p)==3&&own(p,house)){uint32_t t=typeOf(p,3);if(t&&decisions::shouldRepair({get<int>(p+0x6c),get<int>(t+0xA0),true,
     get<bool>(p+0x6E8),recent})){if(!repairEvent(house,id))break;--budget;++repairDone;++snap.repairTotal;repairSentID[slot]=id;repairSentAt[slot]=now;}}
  ++repairAt;
  }
 }
 // Completion reports events actually queued, not the number of candidates.
 // A congested native queue must also produce a terminal ACK, not wait forever.
 if(repairAckRequest&&(repairAt>=repairCount||DWORD(now-repairAckStarted)>3000)){
  sh->result=repairDone?1:-6;sh->count=repairDone;
  pendingAck=repairAckRequest;repairAckRequest=0;
  repairAt=repairCount; // Drop unsent candidates on timeout; no surprise later repair.
 }
}
static void scanCrates(uint32_t tactical,int frame,DWORD now,uint32_t flags){
 snap.crateCount=0;if(!(flags&Crates)){cratesOn=false;crateCount=0;return;}
 if(!cratesOn||DWORD(now-crateTick)>=500){cratesOn=true;crateTick=now;crateCount=0;
  uint32_t cells=get<uint32_t>(0x87F7E8+316);int capacity=get<int>(0x87F7E8+320);
  if(cells>=0x10000&&capacity>0&&capacity<=512*512)for(int i=0;i<256;++i){uint32_t c=0x87F7E8+344+i*16;int x=get<short>(c+12),y=get<short>(c+14);
   if(x<=0||y<=0||x>=512||y>=512||!remaining(get<int>(c),get<int>(c+8),frame))continue;
   int index=y*512+x;if(index>=capacity)continue;uint32_t cell=get<uint32_t>(cells+index*4);if(cell<0x10000)continue;
   int overlay=get<int>(cell+0x44);Vec overlays=vec(0xA83D80,4096);uint32_t overlayType=item(overlays,overlay);
   if(!overlayType||!get<bool>(overlayType+0x2AA))continue;
   auto&d=crateCache[crateCount++];d.cellX=x;d.cellY=y;int preset=get<unsigned char>(cell+0x11E);d.preview=preset<19?preset:-1;d.coords[0]=x*256+128;d.coords[1]=y*256+128;d.coords[2]=call<int>(0x578080,0x87F7E8,d.coords);
  }
 }
 if(tactical)for(int i=0;i<crateCount;++i){auto&c=crateCache[i];POINT pt{};if(!call<bool>(0x6D2140,tactical,c.coords,&pt))continue;snap.crates[snap.crateCount++]={c.cellX,c.cellY,pt.x,pt.y,c.preview};}
}
static void scan(uint32_t house,int frame,DWORD now){
 snap.labels=0;snap.selected=0;snap.transports=snap.used=snap.capacity=0;
 uint32_t tactical=get<uint32_t>(0x887324),flags=sh->flags;
 bool global=(flags&(Iron|Psychic))||((flags&Capacity)&&(flags&AllTransports))||nativeCount;
 Vec v=vec(global?0xA8EC78:0xA8ECB8);
 snap.threatCount=0;uint32_t allies=get<uint32_t>(house+0x5788);
 for(int i=0;i<v.count;++i){uint32_t p=item(v,i);if(!p||!live(p))continue;int k=kind(p);if(k<0)continue;
 bool local=get<uint32_t>(p+0x21C)==house;
 if(!local){
  if((flags&Psychic)&&tactical&&snap.threatCount<MaxThreats){uint32_t owner=get<uint32_t>(p+0x21C),target=get<uint32_t>(p+0x2B4);
   int ownerIndex=owner>=0x10000?get<int>(owner+0x30):-1;
   if(ownerIndex>=0&&ownerIndex<32&&!(allies&(1u<<ownerIndex))&&target>=0x10000&&kind(target)>=0&&own(target,house)){
    POINT a{},b{};if(call<bool>(0x6D2140,tactical,(const void*)(p+0x9C),&a)&&call<bool>(0x6D2140,tactical,(const void*)(target+0x9C),&b))snap.threats[snap.threatCount++]={get<uint32_t>(p+0x10),get<uint32_t>(target+0x10),a.x,a.y,b.x,b.y};
   }
  }
 }
 bool selected=local&&get<bool>(p+0x83);if(selected)++snap.selected;
 int iron=(flags&Iron)?remaining(get<int>(p+0x18C),get<int>(p+0x194),frame):0;uint32_t t=typeOf(p,k);int capacity=local&&t&&k!=3&&(flags&Capacity)?get<int>(t+0x5E0):0;bool capacityShow=capacity>0&&(selected||(flags&AllTransports));
 int used=0;if(capacityShow){used=call<int>(0x473460,p+0x114);if(selected){++snap.transports;snap.used+=used;snap.capacity+=capacity;}}
 int advancedIndex=local&&nativeCount?orderIndex(p):-1;bool advanced=advancedIndex>=0&&nativeOrders[advancedIndex].stopped;
 if((!capacityShow&&!iron&&!advanced)||!tactical||snap.labels>=MaxLabels)continue;
 POINT pt{};if(!call<bool>(0x6D2140,tactical,(const void*)(p+0x9C),&pt))continue;
 auto&l=snap.label[snap.labels++];l={get<uint32_t>(p+0x10),pt.x,pt.y,used,capacityShow?capacity:0,iron,get<int>(p+0x1C4)!=0,advanced};
 }
 snap.frame=frame;snap.width=get<int>(0xA8EB84);snap.height=get<int>(0xA8EB88);snap.credits=get<int>(house+0x30C);
 scanCrates(tactical,frame,now,flags);
}
static bool scanSummary(uint32_t house,int frame,DWORD now,uint32_t flags){
 if(DWORD(now-slow)<100)return false;slow=now;
 if(sh->externalDisplay){
  if(!(flags&Production))clearFlashes();
  if(sh->productionRequest!=sh->productionAck){MemoryBarrier();int count=sh->productionCount;
   if((flags&Production)&&sh->productionMatch==match&&DWORD(now-sh->productionTick)<2000&&count>=0&&count<=4)for(int i=0;i<count;++i)flashCameo(sh->productionTypes[i],frame);
   MemoryBarrier();sh->productionAck=sh->productionRequest;
  }return true;
 }
 snap.swCount=0;Vec sw=vec(house+0x254,256);for(int i=0;i<sw.count&&snap.swCount<MaxSW;++i){uint32_t p=item(sw,i);if(!p||get<uint32_t>(p+0x2C)!=house||!get<bool>(p+0x6D))continue;uint32_t t=get<uint32_t>(p+0x28);if(!t)continue;auto&d=snap.supers[snap.swCount++];memset(&d,0,sizeof d);memcpy(d.id,(void*)(t+0x24),23);name(t,d.name,40);d.index=i;d.ready=call<char>(0x6CC360,p);d.frames=remaining(get<int>(p+0x30),get<int>(p+0x38),frame);}
 scanProduction(house,frame,flags);
 return true;
}
static void shiftScene(int dx,int dy){
 for(int i=0;i<snap.labels;++i){snap.label[i].x-=dx;snap.label[i].y-=dy;}
 for(int i=0;i<snap.crateCount;++i){snap.crates[i].x-=dx;snap.crates[i].y-=dy;}
 for(int i=0;i<snap.threatCount;++i){auto&t=snap.threats[i];t.x-=dx;t.y-=dy;t.tx-=dx;t.ty-=dy;}
}
// Consume one set of game-thread intents irrespective of which callback woke
// the dispatcher. Producers write Shared requests / plans; they never choose
// the callback provider or write EventClass data themselves.
static void consumeSubmittedIntents(uint32_t house,int frame,DWORD now){
 selectionCommand(house,now);
 // Preserve the ordering of the known-good path: input observers first,
 // then command / planner / cooperative requests.
 uint32_t inputFlags=sh->flags|(unloadCount?NativeOrders:0);
 csHooksTick(inputFlags);nativeHooksTick(inputFlags);clickHooksTick(inputFlags);
 snap.inputPatchMask=(csPatched?1:0)|(cursorPatched?2:0)|(eventPatched?4:0)|(footClickPatched?8:0)|(decidePatched?16:0)|(mouseUpPatched?32:0);
 command(house,now);externalOrdersTick(house,frame,now);cooperativeTick(house,frame,now);placementTick();
}
static void tick(){
 if(!sh){wchar_t n[80];mapName(n,GetCurrentProcessId());mapping=OpenFileMappingW(FILE_MAP_ALL_ACCESS,FALSE,n);if(!mapping)return;sh=(Shared*)MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,sizeof(Shared));if(!sh||sh->magic!=Magic||sh->version!=Version||sh->pid!=GetCurrentProcessId()){disconnect();return;}}
 DWORD now=sampleClock(sh);if(sh->stop||DWORD(now-sh->heartbeat)>3000){restoreFrameDriver();Shared* old=sh;reset();if(old->stop)old->stop=2;disconnect();return;}if(!checked){good=signatures();checked=true;}if(!good){if(sh->data.status!=-1){InterlockedIncrement(&sh->seq);sh->data.status=-1;sh->data.labels=0;MemoryBarrier();InterlockedIncrement(&sh->seq);}return;}
 DWORD period=sh->foreground?sh->scanMs:((sh->flags&(AdvancedInput|MagnetronInput|AutoOreReturn))?64:500);if(period<2)period=2;if(period>1000)period=1000;
 bool selectionPending=sh->selectRequest!=sh->selectAck;bool planPending=sh->planRequest!=sh->planAck;bool cmd=sh->request!=sh->ack||selectionPending||planPending;// In game-frame mode, do not let wall-clock sampling skip a simulation frame
 // with pending combat/ejection intents. Pure overlay work stays rate-limited.
 bool frameDue=get<int>(0xA8ED84)!=lastFrame&&
   (nativeCount||unloadCount||(sh->flags&EjectAssist)||
    (sh->plannerTracking&&(sh->flags&(AdvancedInput|MagnetronInput|AutoOreReturn)))||
    sh->planRequest!=sh->planAck||sh->cooperativePlan!=sh->cooperativeAck);
 if(!cmd&&!frameDue&&DWORD(now-last)<period)return;last=now;
 LARGE_INTEGER start,end,controlEnd,worldEnd;static LARGE_INTEGER frequency{};if(!frequency.QuadPart)QueryPerformanceFrequency(&frequency);QueryPerformanceCounter(&start);
 uint32_t house=get<uint32_t>(0xA83D4C);int frame=get<int>(0xA8ED84);bool active=get<bool>(0xA8E9A0)&&house>=0x10000&&house!=get<uint32_t>(0xAC1198)&&!get<bool>(house+0x1F5)&&!get<bool>(house+0x1F6)&&!get<bool>(house+0x1F8);
 if(active){Vec hv=vec(0xA80228,32);bool found=false;for(int i=0;i<hv.count;++i)if(item(hv,i)==house)found=true;active=found;}
 if(!active){if(lastHouse||snap.status!=0)reset();sessionTracker.update(false,0,-1,-1);lastHouse=0;lastFrame=-1;snap.status=0;snap.bridgeStatus=0;snap.commandStatus=0;snap.labels=0;snap.swCount=0;if(sh->request!=sh->ack){sh->result=-3;sh->count=0;pendingAck=sh->request;}if(selectionPending){sh->selectResult=-3;sh->selectCount=0;MemoryBarrier();sh->selectAck=sh->selectRequest;}if(planPending){sh->planResult=-3;sh->planAccepted=0;sh->planAcceptedMask=sh->planRejectedMask=0;MemoryBarrier();sh->planAck=sh->planRequest;}}
 else {int sessionMode=get<int>(0xA8B238);
 // A mode switch while the House address is reused invalidates outstanding
 // requests and all actor leases; do not allow previous-lane events to leak.
 bool newMatch=sessionTracker.update(true,house,sessionMode,frame)!=sessionepoch::Transition::None;
 if(newMatch){reset();match=sessionTracker.epoch;lastHouse=house;scanTypes();slow=now-100;sceneFrame=-2147483647;sceneTick=0;}
 lastFrame=frame;snap.match=match;snap.session=sessionMode;snap.status=1;snap.bridgeStatus=1;snap.commandStatus=1;
 snap.chat=get<bool>(0xA8BC60+25);
 bool needsIndex=hookpolicy::needsWorldIndex(cmd,missionObserver.pending()||actorLeaseArbiter.count||loadLedger.count||nativeCount||unloadCount||repairAt<repairCount||entryReservationCount||cooperativeEffectCount||sh->cooperativePlan!=sh->cooperativeAck,
  sh->flags|sh->plannerTracking|((sh->cooperativePlan!=sh->cooperativeAck)?AutoOreReturn:0),(sh->flags&AutoRepair)&&(!autoWas||DWORD(now-lastAuto)>=clampedRepairInterval(sh->repairMs)));
 if(needsIndex)indexWorld(frame);
 // Release stale leases before any feature sends a new game order. No game
 // state mutation occurs here: only indexed actor identities are inspected.
 if(actorLeaseArbiter.count)actorLeaseArbiter.sweep(match,frame,[](uint32_t id){
  uint32_t p=worldByID(id);return std::pair<uint32_t,uint32_t>{p,manualVersions.get(id)};
 });
 observePausedOre(house,frame);
 // Only tick consumes feature requests; neither Hook callback can bypass
 // the shared game-thread intent/validation/event pipeline.
 consumeSubmittedIntents(house,frame,now);
 QueryPerformanceCounter(&controlEnd);snap.controlMicros=micros(start,controlEnd,frequency);
 // Release receipts before any recurring work or overlay projection. In a busy
 // scene the next user command can now be staged while rendering catches up.
 if(cmd){snap.scanMicros=snap.controlMicros;publishSnapshot(now);}
 repairTick(house,now);autoLoadTick(house,frame);nativeOrdersTick(house,frame);
 // Read-only observation, bounded to 32 outstanding orders per game frame.
 if(missionObserver.pending())snap.observedEvents+=missionObserver.pollWithReceipts(match,frame,now,[](uint32_t id){
  gateway::MissionState current{};uint32_t p=worldByID(id);
  if(p){current.valid=true;current.mission=get<int>(p+0xAC);
   current.queued=get<int>(p+0xB4);current.carrier=get<uint32_t>(p+0x11C);}
  return current;
 },[](const gateway::Receipt& receipt){
  recordReceipt(receipt);
  actorLeaseArbiter.release(receipt.match,receipt.unit,receipt.serial);
  if(receipt.phase==gateway::Phase::Cancelled)++snap.receiptCancelled;
  else if(receipt.phase==gateway::Phase::Expired)++snap.receiptExpired;
 });
 publishPlanningWorld(house,frame,now);
 QueryPerformanceCounter(&worldEnd);snap.worldMicros=micros(controlEnd,worldEnd,frequency);
 uint32_t tactical=get<uint32_t>(0x887324),flags=sh->flags;int cx=tactical?get<int>(tactical+0xB0):0,cy=tactical?get<int>(tactical+0xB4):0;
 double zoom=tactical?get<double>(tactical+0xB8):0;int width=get<int>(0xA8EB84),height=get<int>(0xA8EB88);
 bool cameraMoved=cx!=cameraX||cy!=cameraY;
 // Render cadence is independent of world scans. Scan at most about 60 Hz;
 // unchanged frames reuse their scene, and camera-only changes shift it.
 static uint32_t selectedStamp;uint32_t stamp=2166136261u;Vec selected=vec(0xA8ECB8);for(int i=0;i<selected.count;++i)stamp=(stamp^item(selected,i))*16777619u;
 bool selectionChanged=stamp!=selectedStamp;selectedStamp=stamp;
 bool force=newMatch||selectionPending||selectionChanged||flags!=sceneFlags||tactical!=sceneTactical||width!=sceneWidth||height!=sceneHeight||zoom!=sceneZoom||snap.crateResultSerial!=sceneResultSerial;
 bool full=force||(DWORD(now-sceneTick)>=16&&(frame!=sceneFrame||(cameraMoved&&DWORD(now-sceneTick)>=32)||DWORD(now-sceneTick)>=100));
 bool summaryChanged=scanSummary(house,frame,now,flags);
 if(snap.techOpen&&((techPending&&DWORD(now-techRefresh)>=16)||DWORD(now-techRefresh)>=1000))refreshTech(house,now);
 if(full){if(!sh->externalDisplay)scan(house,frame,now);sceneFrame=frame;sceneTick=now;sceneFlags=flags;sceneTactical=tactical;sceneWidth=width;sceneHeight=height;sceneZoom=zoom;sceneResultSerial=snap.crateResultSerial;}
 else if(cameraMoved)shiftScene(cx-cameraX,cy-cameraY);
 else if(!cmd&&!summaryChanged&&DWORD(now-snap.sampledTick)<250)return;
 cameraX=cx;cameraY=cy;snap.cameraX=cx;snap.cameraY=cy;
 }
 QueryPerformanceCounter(&end);if(active)snap.displayMicros=micros(worldEnd,end,frequency);
 snap.scanMicros=micros(start,end,frequency);publishSnapshot(now);
}
// The two modes share exactly the same tick() and vanilla event gateway.
// The frame mode owns ONLY scheduling. All game event construction, legality,
// acknowledgements, SP/MP routing and command semantics remain unchanged.
// Install from the game thread, only after normal EXE signatures match.
extern "C" void GuardedAssistTick();
// Both entrypoints call this ONE game-thread dispatcher. Their only job is
// waking it; event construction / queue selection are wholly inside tick().
static void dispatchFromTrigger(dispatchrouter::Trigger trigger,DWORD now);
extern "C" void GuardedFrameDispatch(){
 DWORD now=GetTickCount();
 InterlockedExchange(&frameLastMs,LONG(now));
 if(sh){
  sh->driverLastTick=now;InterlockedIncrement((volatile LONG*)&sh->driverTicks);
  DWORD expectedThread=DWORD(InterlockedCompareExchange(&messageGameThread,0,0));
  if(!expectedThread||GetCurrentThreadId()!=expectedThread){
   // Callback may be a network/graphics/wait-loop caller rather than the
   // message thread that owns our original native-order bridge. Do not submit
   // events from it; message scheduling remains the non-invasive fallback.
   InterlockedExchange(&frameValidated,0);
   frameValidSteps=0;
   sh->driverStatus=scheduler::FrameWrongThread;
   return;
  }
  // A written JMP/CALL is not proof that the game executes this entry on
  // consecutive simulation frames. Do not promote until two distinct frames
  // have been observed on the same thread while the game is active.
  if(frameInstalled&&checked&&good&&get<bool>(0xA8E9A0)){
   DWORD thread=GetCurrentThreadId();LONG frame=get<int>(0xA8ED84);
   if(!frameCallbackThread){frameCallbackThread=thread;frameLastSeen=frame;}
   else if(frameCallbackThread!=thread){frameCallbackThread=thread;frameLastSeen=frame;frameValidSteps=0;InterlockedExchange(&frameValidated,0);}
   else if(frame>frameLastSeen&&frame-frameLastSeen<300){frameLastSeen=frame;
    if(frameValidSteps<2)++frameValidSteps;
    if(frameValidSteps>=2){InterlockedExchange(&frameValidated,1);sh->driverStatus=scheduler::FrameActive;}
   }else if(frame<frameLastSeen){frameLastSeen=frame;frameValidSteps=0;InterlockedExchange(&frameValidated,0);sh->driverStatus=scheduler::FrameInstalled;}
  }
 }
 // Installation is not a verified trigger. The message hook owns gameplay
 // work until distinct simulation frames have validated this candidate.
 dispatchFromTrigger(dispatchrouter::Trigger::GameFrame,now);
}
static void __declspec(naked) assistFrameObserver(){
 __asm {
  pushfd
  pushad
  mov ebx, esp
  sub esp, 528
  and esp, -16
  fxsave [esp]
  cld
  call GuardedFrameDispatch
  fxrstor [esp]
  mov esp, ebx
  popad
  popfd
  jmp dword ptr [frameCode]
 }
}
// A patched CALL pushes its original return address. We must JMP to the
// unmodified original callee, not CALL again or fabricate a return address.
// Therefore this observer is distinct from the function-entry trampoline.
static void __declspec(naked) assistFrameCallObserver(){
 __asm {
  pushfd
  pushad
  mov ebx, esp
  sub esp, 528
  and esp, -16
  fxsave [esp]
  cld
  call GuardedFrameDispatch
  fxrstor [esp]
  mov esp, ebx
  popad
  popfd
  jmp dword ptr [frameCallTarget]
 }
}
static void restoreFrameDriver(){
 InterlockedExchange(&frameValidated,0);
 frameLastSeen=-1;frameValidSteps=0;frameCallbackThread=0;
 bool restored=!frameInstalled;
 if(frameInstalled&&frameSize&&frameSize<=sizeof(frameOriginal)){
  // Either we still own the exact patch, or it is already the exact original.
  // Anything else is a conflict, not a successful uninstallation.
  if(!memcmp((const void*)(uintptr_t)frameAt,frameOriginal,frameSize)){
   // Already-original memory while our registry still owns the patch means
   // an outside component touched our bytes. Do not silently reinstall.
   if(codeHookRegistry.active(frameAt)){codeHookRegistry.markConflict(frameAt);frameRestoreConflict=true;}
   restored=true;
  }
  else if(!memcmp((const void*)(uintptr_t)frameAt,framePatch,frameSize))
   restored=writeInputCodeGuarded(frameAt,framePatch,frameOriginal,frameSize);
 }
 // Fail closed. A failed restore is sticky for this process: never attempt
 // another installation at an uncertain address. The pinned module and RX
 // trampoline remain alive so callbacks already in flight cannot use freed code.
 if(!restored){frameRestoreConflict=true;codeHookRegistry.markConflict(frameAt);}
 // Keep ownership if the detour may still be reachable. The DLL is pinned.
 frameInstalled=!restored;
 if(sh&&sh->driverMode==scheduler::GameFrame)
  sh->driverStatus=frameRestoreConflict?scheduler::FrameConflict:scheduler::Pending;
}
static bool installFrameDriver(){
 if(frameRestoreConflict){if(sh)sh->driverStatus=scheduler::FrameConflict;return false;}
 const uint32_t selected=sh?sh->driverTarget:0;
 const framecandidate::Site* site=framecandidate::lookup(selected);
 if(selected&&!site){if(sh)sh->driverStatus=scheduler::FrameUnsupported;return false;}
 const uint32_t at=site?site->at:0x0055D360;
 if(frameInstalled)return true;
 // The existing function/address signature allowlist must pass first.
 if(!checked||!good||!sh)return false;
 unsigned char original[12]{};
 unsigned n=0;
 if(site){
  unsigned char context[21]{};
  if(at<8||!read(at-8,context,sizeof context)||
     !framecandidate::validCallSite(selected,context,sizeof context)||
     framecandidate::callTarget(at,context+8)!=0x0055D360){
   sh->driverStatus=scheduler::FrameConflict;return false;
  }
  memcpy(original,context+8,5);
  n=5;
 }else{
  if(!read(at,original,sizeof original)){sh->driverStatus=scheduler::FrameUnsupported;return false;}
  // Primary entry: exact known entry signature, not merely any relocatable opcode.
  static const uint8_t expected[]={0xA0,0xA0,0xE9,0xA8,0x00,0x81,0xEC,0xB4,0x01,0x00,0x00,0x84};
  if(memcmp(original,expected,sizeof expected)){sh->driverStatus=scheduler::FrameConflict;return false;}
  n=frameprologue::safeOverwrite(original,sizeof original);
  if(!n){sh->driverStatus=scheduler::FrameUnsupported;return false;}
 }
 MEMORY_BASIC_INFORMATION mbi{};
 if(!VirtualQuery((const void*)at,&mbi,sizeof mbi)||mbi.State!=MEM_COMMIT||
   (mbi.Protect&(PAGE_GUARD|PAGE_NOACCESS))){sh->driverStatus=scheduler::FrameUnsupported;return false;}
 DWORD prot=mbi.Protect&0xff;
 if(prot!=PAGE_EXECUTE&&prot!=PAGE_EXECUTE_READ&&prot!=PAGE_EXECUTE_READWRITE&&prot!=PAGE_EXECUTE_WRITECOPY){
  sh->driverStatus=scheduler::FrameUnsupported;return false;
 }
 // Before any JMP/CALL is installed, pin the owner DLL. A later FreeLibrary
 // cannot discard trampoline observers while a game thread is in flight.
 if(!bridgePinned){HMODULE pinned=0;
  if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,
     (LPCWSTR)&assistFrameObserver,&pinned)){
   sh->driverStatus=scheduler::FramePatchFailed;return false;
  }
  bridgePinned=true;
 }
 // This is deliberately NOT a chainable detour: conflicting patches are
 // rejected. Do not attempt to bypass launchers or other plug-ins.
 memcpy(frameOriginal,original,n);
 frameAt=at;
 memset(framePatch,0x90,n);
 if(site){
  // E8 CALL shim, original callee and return address remain unchanged.
  frameCallTarget=framecandidate::callTarget(at,original);
  framePatch[0]=0xE8;
  int32_t forward=int32_t(uint32_t(uintptr_t(&assistFrameCallObserver))-at-5);
  memcpy(framePatch+1,&forward,4);
 }else{
  // A previous trampoline page is RX; never rewrite it on reattachment.
  // Allocate a fresh page. Old pages remain mapped so an in-flight callback
  // cannot accidentally jump into released/recycled executable memory.
  uint8_t* newCode=(uint8_t*)VirtualAlloc(nullptr,4096,MEM_RESERVE|MEM_COMMIT,PAGE_READWRITE);
  if(!newCode){sh->driverStatus=scheduler::FrameAllocationFailed;return false;}
  memcpy(newCode,original,n);
  newCode[n]=0xE9;
  int32_t back=int32_t(at+n-uint32_t(uintptr_t(newCode+n+5)));
  memcpy(newCode+n+1,&back,4);
  framePatch[0]=0xE9;
  int32_t forward=int32_t(uint32_t(uintptr_t(&assistFrameObserver))-at-5);
  memcpy(framePatch+1,&forward,4);
  DWORD trampolineOld=0;
  if(!VirtualProtect(newCode,4096,PAGE_EXECUTE_READ,&trampolineOld)){
   VirtualFree(newCode,0,MEM_RELEASE);
   sh->driverStatus=scheduler::FramePatchFailed;return false;
  }
  FlushInstructionCache(GetCurrentProcess(),newCode,n+5);
  frameCode=newCode;
 }
 if(!writeInputCodeGuarded(at,original,framePatch,n)){
  sh->driverStatus=codeHookRegistry.conflict(at)?scheduler::FrameConflict:scheduler::FramePatchFailed;
  return false;
 }
 frameSize=n;frameInstalled=true;frameCallbackThread=0;frameLastSeen=-1;
 frameValidSteps=0;InterlockedExchange(&frameValidated,0);
 sh->driverStatus=scheduler::FrameInstalled;
 return true;
}
static void maintainScheduler(){
 if(!sh)return;
 if(sh->driverMode!=scheduler::GameFrame){
  if(frameInstalled)restoreFrameDriver();
  sh->driverStatus=scheduler::MessageActive;
  return;
 }
 if(frameRestoreConflict){sh->driverStatus=scheduler::FrameConflict;return;}
 if(frameInstalled){
  if(!InterlockedCompareExchange(&frameValidated,0,0)){
   if(sh->driverStatus!=scheduler::FrameWrongThread)sh->driverStatus=scheduler::FrameInstalled;
  }
  else if(DWORD(GetTickCount()-DWORD(InterlockedCompareExchange(&frameLastMs,0,0)))>250u)
   sh->driverStatus=scheduler::FrameStalled;
  else sh->driverStatus=scheduler::FrameActive;
  return;
 }
 if(!frameTried&&checked&&good){frameTried=true;installFrameDriver();}
 // Frame unsupported/conflict must remain visible until a new game attach.
}
// One place owns provider choice, fallback and the execution lock.
// This adapter does not contain feature decisions or EventClass operations.
static void dispatchFromTrigger(dispatchrouter::Trigger trigger,DWORD now){
 const bool attached=sh!=nullptr;
 const DWORD gameThread=DWORD(InterlockedCompareExchange(&messageGameThread,0,0));
 const bool sameThread=gameThread&&GetCurrentThreadId()==gameThread&&
                        frameCallbackThread==gameThread;
 const dispatchrouter::State state{
  attached,
  attached&&sh->driverMode==scheduler::GameFrame?scheduler::GameFrame:scheduler::Message,
  attached?scheduler::Status(sh->driverStatus):scheduler::Pending,
  frameInstalled,
  InterlockedCompareExchange(&frameValidated,0,0)!=0,
  sameThread,
  now,
  DWORD(InterlockedCompareExchange(&frameLastMs,0,0))
 };
 if(!dispatchrouter::accepts(trigger,state))return;
 if(InterlockedCompareExchange(&schedulerBusy,1,0)!=0)return;
 // Producers and event gateway do not know which provider woke this tick.
 // The shared request/ack serials and unit arbiter prevent redispatching an
 // already accepted user request when ownership changes between callbacks.
 if(!fault||(sh&&sh->stop)){
  assistFromGameFrame=trigger==dispatchrouter::Trigger::GameFrame;
  GuardedAssistTick();
  assistFromGameFrame=false;
 }
 // Install / remove experimental hooks only from the original message path.
 if(trigger==dispatchrouter::Trigger::Message)maintainScheduler();
 InterlockedExchange(&schedulerBusy,0);
}
extern "C" void AssistTick(){tick();}
extern "C" void AssistFault(){fault=true;restoreClickHooks();resetCooperativeState();clearNativeOrders();restorePlacement();restoreTech();restoreCSHook();if(sh){sh->result=-10;InterlockedIncrement(&sh->seq);sh->data.status=-2;sh->data.labels=0;MemoryBarrier();InterlockedIncrement(&sh->seq);sh->ack=sh->request;sh->selectResult=sh->planResult=-10;sh->selectAck=sh->selectRequest;sh->planAccepted=0;sh->planAcceptedMask=sh->planRejectedMask=0;sh->planAck=sh->planRequest;notifyHost();}}
extern "C" void GuardedAssistTick();
extern "C" __declspec(dllexport) LRESULT CALLBACK AssistHook(int code,WPARAM wp,LPARAM lp){__declspec(align(16)) BYTE fx[512];__asm {fxsave fx}
 if(code>=0){
  InterlockedCompareExchange(&messageGameThread,LONG(GetCurrentThreadId()),0);
 }
 if(code>=0&&sh&&wp==PM_REMOVE&&lp){auto*message=(MSG*)lp;if(message->message==WM_NULL&&message->wParam==WakeTag&&message->lParam==sh->owner)InterlockedExchange(&sh->gameWakePending,0);}
 if(code>=0)dispatchFromTrigger(dispatchrouter::Trigger::Message,GetTickCount());
 __asm {fxrstor fx}return CallNextHookEx(nullptr,code,wp,lp);
}
extern "C" BOOL WINAPI DllMain(HINSTANCE h,DWORD reason,LPVOID){
 if(reason==DLL_PROCESS_ATTACH)DisableThreadLibraryCalls(h);
 // Never restore executable pages, enter the command loop, close mappings, or
 // change hooks while the Windows loader lock is held. Controlled stop/ACK
 // via tick()->disconnect() handles normal shutdown on the game thread.
 // All inline-detour owners are pinned before patch installation.
 else if(reason==DLL_PROCESS_DETACH)fault=true;
 return TRUE;
}

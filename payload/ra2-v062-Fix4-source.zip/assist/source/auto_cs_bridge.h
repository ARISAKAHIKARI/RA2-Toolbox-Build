#include "type_hotkey.h"
// Observe ONLY the native local outgoing event constructor, before serialization.
// Never intercept ClickedMission or a received simulation mission.
static const unsigned char csOriginal[5]={0x83,0xEC,0x70,0x32,0xC0};
static unsigned char csPatch[5];static unsigned char*csCode;static bool csPatched;
static uint8_t csMask[MaxTypes];static uint32_t csMaskMatch;static long csMaskSeq=-1;
static void restoreCSHook(){
 if(csPatched){
  if(writeInputCodeGuarded(0x646E90,csPatch,csOriginal,5))csPatched=false;
  else{codeHookRegistry.markConflict(0x646E90);snap.csHookStatus=-3;}
 }
 csMaskSeq=-1;csMaskMatch=0;
}
static bool configuredKeyHeld(unsigned key){
 if(!(key&255)||!(GetAsyncKeyState(key&255)&0x8000))return false;
 unsigned mods=key>>8;
 return !!(GetAsyncKeyState(VK_SHIFT)&0x8000)==!!(mods&1)&&!!(GetAsyncKeyState(VK_CONTROL)&0x8000)==!!(mods&2)&&!!(GetAsyncKeyState(VK_MENU)&0x8000)==!!(mods&4);
}
static bool csHeld(){return nativeReady()&&snap.csHookStatus==1&&(sh->flags&CustomCS)&&configuredKeyHeld(sh->csHoldKey);}
static bool csActive(){return nativeReady()&&(sh->flags&AutoCS)&&snap.csHookStatus==1;}
extern "C" void CSCapture(unsigned* saved){
 if(nativeMegaQueueCallDepth||!nativeReady())return;
 // PUSHFD + PUSHAD: saved[3]+4 is entry ESP, saved[6] is ECX (mission).
 uint32_t stack=saved[3]+4;int mission=int(saved[6]);
 if(get<unsigned char>(stack+8)!=0x34)return;
 indexWorld(get<int>(0xA8ED84));uint32_t p=worldObjects.byId(get<uint32_t>(stack+4));
 if(!p||!own(p,lastHouse))return;
 uint32_t target=saved[5],destination=get<uint32_t>(stack+12);
 uint32_t targetID=target?get<uint32_t>(target):0;
 uint32_t destinationID=destination>=0x10000&&get<unsigned char>(destination+4)==0x34?get<uint32_t>(destination):0;
 bool ground=destination>=0x10000&&get<unsigned char>(destination+4)==11&&!targetID;
 if(((sh->flags&(AdvancedInput|MagnetronInput|AutoOreReturn))||sh->plannerTracking||manualVersions.watchingOre(get<uint32_t>(p+0x10)))&&nativeOutgoing(p,mission,ground?get<uint32_t>(destination):0,targetID,destinationID)){
  saved[6]=nativeOrders[nativeCount-1].mode==planner::MagnetronMove?2:29;return;
 }
 if((mission!=2&&mission!=29)||!ground||(!csActive()&&!csHeld()))return;
 int k=kind(p);if((k!=1&&k!=2)||!get<bool>(p+0x83)||get<bool>(p+0x1C8)||get<uint32_t>(p+0x11C))return;
 bool allowed=csHeld();
 if(!allowed){
  long seq=sh->csSeq;if(seq&1)return;MemoryBarrier();if(sh->csMatch!=match)return;
  if(seq!=csMaskSeq||csMaskMatch!=match){uint8_t next[MaxTypes];memcpy(next,sh->csAllowed,sizeof next);MemoryBarrier();if(seq!=sh->csSeq)return;
   memcpy(csMask,next,sizeof csMask);csMaskSeq=seq;csMaskMatch=match;
  }
  uint32_t type=typeOf(p,k);for(int i=0;i<snap.typeCount;++i)if(typePointers[i]==type){allowed=csMask[i]!=0;break;}
 }
 if(allowed&&rawArmed(p)){saved[6]=29;if(mission!=29)++snap.csConverted;}
}
extern "C" void CSCaptureFault(){snap.csHookStatus=-2;}
extern "C" void GuardedCSCapture(unsigned*);
static void __declspec(naked) csObserver(){
 __asm {
  pushfd
  pushad
  mov ebx, esp
  sub esp, 528
  and esp, -16
  fxsave [esp]
  cld
  push ebx
  call GuardedCSCapture
  add esp, 4
  fxrstor [esp]
  mov esp, ebx
  popad
  popfd
  jmp dword ptr [csCode]
 }
}
static bool installCSHook(){
 if(csPatched)return true;if(memcmp((void*)0x646E90,csOriginal,5))return false;
 if(!bridgePinned){HMODULE module=0;if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,(LPCWSTR)&csObserver,&module))return false;bridgePinned=true;}
 if(!csCode)csCode=makeInputTrampoline(0x646E90,csOriginal,5);
 if(!csCode)return false;
 csPatch[0]=0xE9;int rel=int(uint32_t(&csObserver)-0x646E90-5);memcpy(csPatch+1,&rel,4);
 if(!writeInputCodeGuarded(0x646E90,csOriginal,csPatch,5))return false;csPatched=true;return true;
}
static void csHooksTick(uint32_t flags){
 if(!(flags&(AutoCS|AdvancedInput|MagnetronInput|CustomCS))){restoreCSHook();snap.csHookStatus=csPatched?-3:0;return;}
 if(snap.csHookStatus<0){restoreCSHook();return;}
 if(csPatched&&memcmp((void*)0x646E90,csPatch,5)){
  codeHookRegistry.markConflict(0x646E90);snap.csHookStatus=-3;return;}
 snap.csHookStatus=installCSHook()?1:-1;
}

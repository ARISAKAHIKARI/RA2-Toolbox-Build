// Input-only hooks: CS cursor and cancellation by S / D / scatter / detonate.
static const unsigned char cursorOriginal[6]={0x51,0xA0,0x58,0xFE,0xB0,0x00};
static const unsigned char eventOriginal[5]={0x83,0xEC,0x78,0x56,0x57};
static unsigned char cursorPatch[6],eventPatch[5];static unsigned char *cursorCode,*eventCode;static bool cursorPatched,eventPatched,cursorForced;
extern "C" void CursorCapture(unsigned*saved){
 cursorForced=false;if(!advancedHeld()&&!magnetronHeld()&&!csHeld())return;cursorForced=true;
 // The same native predicate drives the CS cursor and ClickedMission's CS
 // conversion. Only the cursor is overridden; our initial order stays Move.
 saved[7]=(saved[7]&0xFFFFFF00)|1;
}
extern "C" void NativeEventCapture(const unsigned*saved){if(nativeReady()){
 indexWorld(get<int>(0xA8ED84));uint32_t p=saved[6];
 if(worldObjects.contains(p)&&(((sh->flags|sh->plannerTracking)&(AdvancedInput|MagnetronInput))||manualVersions.watchingOre(get<uint32_t>(p+0x10))))cancelNative(p);
}}
extern "C" void NativeInputFault(){
 // Losing the input-observation hook must never discard already tracked
 // disembarked passengers. They issue vanilla orders and do not use this hook.
 cursorForced=false;snap.nativeHookStatus=-2;nativeCount=0;advancedObjects.clear();
}
extern "C" void GuardedCursorCapture(unsigned*);
extern "C" void GuardedNativeEventCapture(const unsigned*);
static void __declspec(naked) cursorObserver(){
 __asm {
  pushfd
  pushad
  mov ebx, esp
  sub esp, 528
  and esp, -16
  fxsave [esp]
  cld
  push ebx
  call GuardedCursorCapture
  add esp, 4
  fxrstor [esp]
  mov esp, ebx
  popad
  popfd
  cmp byte ptr [cursorForced], 0
  je cursor_original_path
  ret
 cursor_original_path:
  jmp dword ptr [cursorCode]
 }
}
static void __declspec(naked) eventObserver(){
 __asm {
  pushfd
  pushad
  mov ebx, esp
  sub esp, 528
  and esp, -16
  fxsave [esp]
  cld
  push ebx
  call GuardedNativeEventCapture
  add esp, 4
  fxrstor [esp]
  mov esp, ebx
  popad
  popfd
  jmp dword ptr [eventCode]
 }
}
static void restoreNativeHooks(){
 if(cursorPatched){
  if(writeInputCodeGuarded(0x731BF0,cursorPatch,cursorOriginal,6))cursorPatched=false;
  else{codeHookRegistry.markConflict(0x731BF0);snap.nativeHookStatus=-3;}
 }
 if(eventPatched){
  if(writeInputCodeGuarded(0x6FFE00,eventPatch,eventOriginal,5))eventPatched=false;
  else{codeHookRegistry.markConflict(0x6FFE00);snap.nativeHookStatus=-3;}
 }
 cursorForced=false;
}
static bool patchNativeInput(uint32_t address,const unsigned char*original,unsigned char*patch,int length,void*observer,unsigned char*&trampoline,bool&installed){
 if(installed)return true;if(memcmp((void*)address,original,length))return false;
 if(!trampoline)trampoline=makeInputTrampoline(address,original,length);
 if(!trampoline)return false;
 memset(patch,0x90,length);patch[0]=0xE9;int rel=int(uint32_t(observer)-address-5);memcpy(patch+1,&rel,4);
 if(!writeInputCodeGuarded(address,original,patch,length))return false;installed=true;return true;
}
static void nativeHooksTick(uint32_t flags){
 if(!(flags&(NativeOrders|CustomCS))){restoreNativeHooks();snap.nativeHookStatus=(cursorPatched||eventPatched)?-3:0;return;}
 if(snap.nativeHookStatus<0){restoreNativeHooks();return;}
 if((cursorPatched&&memcmp((void*)0x731BF0,cursorPatch,6))||(eventPatched&&memcmp((void*)0x6FFE00,eventPatch,5))){
  if(cursorPatched&&memcmp((void*)0x731BF0,cursorPatch,6))codeHookRegistry.markConflict(0x731BF0);
  if(eventPatched&&memcmp((void*)0x6FFE00,eventPatch,5))codeHookRegistry.markConflict(0x6FFE00);
  restoreNativeHooks();snap.nativeHookStatus=-3;return;}
 // SmartUnload / Eject use vanilla outgoing events; installing input code patches
 // for those features only would break the user's known-good multiplayer path.
 if(!(flags&(AdvancedInput|MagnetronInput|CustomCS))){
  restoreNativeHooks();snap.nativeHookStatus=(cursorPatched||eventPatched)?-3:(loadInterfaces()?1:-1);return;
 }
 // Only cursor-dependent inputs require the CS observer. Vanilla ore orders
 // work with no code patch at all. Pin before installing *any* inline detour.
 if(!bridgePinned){HMODULE pinned=0;
  if(!GetModuleHandleExW(GET_MODULE_HANDLE_EX_FLAG_FROM_ADDRESS|GET_MODULE_HANDLE_EX_FLAG_PIN,
    (LPCWSTR)&cursorObserver,&pinned)){snap.nativeHookStatus=-1;return;}
  bridgePinned=true;
 }
 bool ok=(!hookpolicy::needsCSInputPatch(flags)||csPatched)&&loadInterfaces();
 if(ok&&(flags&(AdvancedInput|MagnetronInput|CustomCS)))ok=patchNativeInput(0x731BF0,cursorOriginal,cursorPatch,6,(void*)&cursorObserver,cursorCode,cursorPatched);
 else if(cursorPatched){
  if(writeInputCodeGuarded(0x731BF0,cursorPatch,cursorOriginal,6))cursorPatched=false;
  else{codeHookRegistry.markConflict(0x731BF0);ok=false;}
 }
 if(ok&&(flags&(AdvancedInput|MagnetronInput)))ok=patchNativeInput(0x6FFE00,eventOriginal,eventPatch,5,(void*)&eventObserver,eventCode,eventPatched);
 else if(eventPatched){
  if(writeInputCodeGuarded(0x6FFE00,eventPatch,eventOriginal,5))eventPatched=false;
  else{codeHookRegistry.markConflict(0x6FFE00);ok=false;}
 }
 snap.nativeHookStatus=ok?1:-1;if(!ok)restoreNativeHooks();
}

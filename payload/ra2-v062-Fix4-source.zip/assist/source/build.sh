#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${CXX:=i686-w64-mingw32-clang++}"
: "${WINDRES:=i686-w64-mingw32-windres}"
"$WINDRES" app.rc -O coff -o app.res.o
"$CXX" -std=c++17 -O2 -static -municode -mwindows main.cpp app.res.o -o ../TacticalAssist.exe -lgdiplus -lcomctl32 -lshell32 -luser32 -lgdi32
"$CXX" --target=i686-pc-windows-msvc -O2 -fms-extensions -fno-stack-protector -fno-autolink -c guard.cpp -o guard.o
FRAME_FLAG=()
if [[ "${ASSIST_ENABLE_SYRINGE_FRAME:-0}" == "1" ]]; then FRAME_FLAG=(-DASSIST_ENABLE_SYRINGE_FRAME); fi
"$CXX" -std=c++17 -O2 -fuse-ld=lld -shared -fms-extensions -fasm-blocks -fno-stack-protector -fno-builtin -fno-exceptions -fno-rtti -nostdlib "${FRAME_FLAG[@]}" bridge.cpp guard.o -o ../AssistBridge.dll -Wl,--entry,_DllMain@12,--kill-at -lkernel32 -luser32 -lwinmm -lmsvcrt "$("$CXX" -print-libgcc-file-name)"

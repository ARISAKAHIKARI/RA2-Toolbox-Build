@echo off
setlocal
cd /d "%~dp0"
rem Requires LLVM-MinGW bin in PATH.
i686-w64-mingw32-windres app.rc -O coff -o app.res.o
if errorlevel 1 exit /b 1
i686-w64-mingw32-clang++ -std=c++17 -O2 -static -municode -mwindows main.cpp app.res.o -o ..\TacticalAssist.exe -lgdiplus -lcomctl32 -lshell32 -luser32 -lgdi32
if errorlevel 1 exit /b 1
i686-w64-mingw32-clang++ --target=i686-pc-windows-msvc -O2 -fms-extensions -fno-stack-protector -fno-autolink -c guard.cpp -o guard.o
if errorlevel 1 exit /b 1
for /f "delims=" %%L in ('i686-w64-mingw32-clang++ -print-libgcc-file-name') do set "ASSIST_BUILTINS=%%L"
i686-w64-mingw32-clang++ -std=c++17 -O2 -fuse-ld=lld -shared -fms-extensions -fasm-blocks -fno-stack-protector -fno-builtin -fno-exceptions -fno-rtti -nostdlib bridge.cpp guard.o -o ..\AssistBridge.dll -Wl,--entry,_DllMain@12,--kill-at -lkernel32 -luser32 -lwinmm -lmsvcrt "%ASSIST_BUILTINS%"
if errorlevel 1 exit /b 1
echo Build completed.

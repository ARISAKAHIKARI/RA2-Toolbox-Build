#include "../source/type_hotkey.h"
#include <cassert>
#include <initializer_list>
int main(){
 typekeys::Tap t;
 assert(!t.press(1100,1000,1,350));assert(t.press(1100,1200,1,350));
 assert(!t.press(1100,1300,1,350)); // third press starts a new pair
 assert(!t.press(1101,1400,1,350));assert(!t.press(1100,1450,1,350));
 assert(!t.press(1100,1900,1,350));assert(!t.press(1100,1950,2,350));
 t.clear();assert(!t.press(1100,0xFFFFFFF0,2,350));assert(t.press(1100,50,2,350));
 assert(typekeys::inView(0,0,640,480));assert(typekeys::inView(639,479,640,480));
 assert(!typekeys::inView(640,100,640,480));assert(!typekeys::inView(-1,0,640,480));
 assert(typekeys::csMission(2,2,true,true,true,true));
 for(int m:{1,7,11,13,29})assert(!typekeys::csMission(m,2,true,true,true,true));
 assert(!typekeys::csMission(2,0,true,true,true,true));assert(!typekeys::csMission(2,3,true,true,true,true));
 assert(!typekeys::csMission(2,2,false,true,true,true));assert(!typekeys::csMission(2,2,true,false,true,true));
 assert(!typekeys::csMission(2,2,true,true,false,true));assert(!typekeys::csMission(2,2,true,true,true,false));
}

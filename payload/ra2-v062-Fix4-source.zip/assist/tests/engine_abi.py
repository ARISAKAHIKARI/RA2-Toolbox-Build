"""Execute original YR event constructors and the compiled bridge in x86 emulation.
Requires: pip install pefile unicorn
Usage: python engine_abi.py path/to/gamemd-spawn.exe path/to/AssistBridge.dll
No game executable is distributed with this project. Not a multiplayer test.
"""
import ctypes as C
import struct
import sys
from pathlib import Path
import pefile
from unicorn import Uc, UC_ARCH_X86, UC_MODE_32, UC_HOOK_CODE, UC_HOOK_MEM_READ
from unicorn.x86_const import *

class Label(C.Structure):
    _fields_=[('id',C.c_uint32)]+[(x,C.c_int32) for x in 'x y used capacity ironFrames shield advanced'.split()]+[('ownerColor',C.c_uint32),('frozenFrames',C.c_int32)]
class Super(C.Structure):
    _fields_=[('id',C.c_char*24),('name',C.c_uint16*40)]+[(x,C.c_int32) for x in 'index ready frames'.split()]
class Type(C.Structure):
    _fields_=[('id',C.c_char*24),('name',C.c_uint16*40)]+[(x,C.c_int32) for x in 'kind index naval cost'.split()]
class Threat(C.Structure):
    _fields_=[(x,C.c_int32) for x in 'id target x y tx ty'.split()]
class Crate(C.Structure):
    _fields_=[(x,C.c_int32) for x in 'cellX cellY x y preview'.split()]
class CrateResult(C.Structure):
    _fields_=[(x,C.c_uint32) for x in 'serial tick'.split()]+[(x,C.c_int32) for x in 'cellX cellY reward amount affected factor detail'.split()]+[('unitID',C.c_char*24),('unitName',C.c_uint16*40)]
class Weapon(C.Structure):
    _fields_=[('range',C.c_int32),('minimum',C.c_int32),('flags',C.c_uint32),('armorMask',C.c_uint32),('selectMask',C.c_uint32),('slot',C.c_int32)]
class Actor(C.Structure):
    _fields_=[(x,C.c_uint32) for x in 'id type flags manualVersion target destination destinationCell'.split()]+[(x,C.c_int32) for x in 'kind x y z mission queued cost storageLimit range'.split()]+[('veterancy',C.c_float),('storage',C.c_float*4),('dockTypes',C.c_uint32*8),('radioIDs',C.c_uint32*4)]+[(x,C.c_int32) for x in 'armor rearmStart rearmDuration airRangeBonus'.split()]+[('liftTarget',C.c_uint32),('weapons',Weapon*2)]
class Intent(C.Structure):
    _fields_=[(x,C.c_uint32) for x in 'id cell token mode'.split()]
class WaitingCell(C.Structure):
    _fields_=[('cell',C.c_uint32),('occupation',C.c_uint32),('land',C.c_int32)]
class Refinery(C.Structure):
    _fields_=[('id',C.c_uint32)]+[(x,C.c_int32) for x in 'cellX cellY dockStyleA dockStyleB count'.split()]+[('waiting',WaitingCell*40)]
class World(C.Structure):
    _fields_=[('match',C.c_uint32),('tick',C.c_uint32)]+[(x,C.c_int32) for x in 'frame count intentCount refineryCount'.split()]+[('inputSerial',C.c_uint32)]+[('actors',Actor*8192),('intents',Intent*2048),('refineries',Refinery*128)]
class Order(C.Structure):
    _fields_=[(x,C.c_uint32) for x in 'unit token target destination'.split()]+[(x,C.c_int32) for x in 'mission destinationTag purpose'.split()]+[('refinery',C.c_uint32)]

class TaskReceiptSummary(C.Structure):
    _fields_=[(x,C.c_uint32) for x in 'serial match unit target queuedAt observedAt'.split()]+[(x,C.c_uint8) for x in 'phase failure owner flags'.split()]
class Snapshot(C.Structure):
    _fields_=[(x,C.c_int32) for x in 'status frame session width height labels swCount typeCount selected transports used capacity factories busyFactories pausedFactories completedFactories credits techOpen match noticeSerial notice scanMicros'.split()]+[('label',Label*2048),('supers',Super*32),('types',Type*512),('threatCount',C.c_int32),('crateCount',C.c_int32),('threats',Threat*128),('crates',Crate*256)]+[(x,C.c_int32) for x in 'techVisible techUnavailable techError autoRepair repairTotal loadUnits loadVehicles loadIssued loadWaiting loadUnassigned sampledTick cameraX cameraY crateHookStatus crateResultCount crateResultSerial'.split()]+[('crateResults',CrateResult*16)]+[(x,C.c_int32) for x in 'chat csHookStatus csConverted nativeHookStatus advancedUnits unloadPending unloadIssued ejectWatched inputPatchMask oreQueued oreDocking oreIssued placementStatus controlMicros worldMicros displayMicros oreManual oreYielded'.split()]+[(x,C.c_uint32) for x in 'oreDelivered oreUnverified magnetShots magnetUnverified hookInstalled hookConflicts queueSent queueFull queueTimingFailure planDeferred'.split()]+[('megaQueueStatus',C.c_int32),('megaQueueAccepted',C.c_uint32),('megaQueueRejected',C.c_uint32),('objectQueueStatus',C.c_int32),('objectQueueAccepted',C.c_uint32),('objectQueueRejected',C.c_uint32)]+[(x,C.c_int32) for x in 'readStatus bridgeStatus commandStatus renderStatus'.split()]+[(x,C.c_uint32) for x in 'queuedEvents observedEvents commandRejected receiptCancelled receiptExpired receiptDropped receiptWrite receiptCount'.split()]+[('recentReceipts',TaskReceiptSummary*32)]
class CooperativeSource(C.Structure):
    _fields_=[('id',C.c_uint32),('token',C.c_uint32)]
class CooperativeRequest(C.Structure):
    _fields_=[(x,C.c_uint32) for x in 'serial match tick target type'.split()]+[(x,C.c_int32) for x in 'frame mode count cameraX cameraY viewWidth viewHeight'.split()]+[('sources',CooperativeSource*512)]
class CooperativeAssignment(C.Structure):
    _fields_=[(x,C.c_uint32) for x in 'id token target type'.split()]
class Shared(C.Structure):
    _fields_=[(x,C.c_uint32) for x in 'magic version pid owner heartbeat stop foreground flags scanMs request ack command arg arg2 requestTick requestMatch result count seq'.split()]+[('data',Snapshot),('techAllowed',C.c_uint8*512),('repairMs',C.c_uint32),('clockStart',C.c_uint64),('clockFrequency',C.c_uint64),('clockTick',C.c_uint32),('csSeq',C.c_int32),('csMatch',C.c_uint32),('csAllowed',C.c_uint8*512)]+[(x,C.c_uint32) for x in 'advancedKey pathTimeout veteranPercent elitePercent selectRequest selectAck selectIndex selectGlobal selectTick selectMatch selectResult selectCount csHoldKey'.split()]+[('worldSeq',C.c_int32),('world',World)]+[(x,C.c_uint32) for x in 'planRequest planAck planTick planMatch planCount planAccepted planResult'.split()]+[('plan',Order*24),('plannerTracking',C.c_uint32),('hostWindow',C.c_uint32),('hostNotifyPending',C.c_int32),('gameWakePending',C.c_int32),('magnetronKey',C.c_uint32),('planAcceptedMask',C.c_uint32),('planRejectedMask',C.c_uint32)]+[(x,C.c_uint32) for x in 'externalDisplay loadMode loadRadius enterKey airKey1 airKey2'.split()]+[('cooperativeSeq',C.c_int32),('cooperativeRequest',CooperativeRequest)]+[(x,C.c_uint32) for x in 'cooperativePlan cooperativeAck cooperativeSerial cooperativeTick'.split()]+[(x,C.c_int32) for x in 'cooperativeCount cooperativeAccepted cooperativeRejected cooperativeMode'.split()]+[('cooperativeOrders',CooperativeAssignment*512),('clickHookStatus',C.c_int32)]+[(x,C.c_uint32) for x in 'driverMode driverTarget megaQueueMode objectQueueMode'.split()]+[('driverStatus',C.c_int32),('driverTicks',C.c_uint32),('driverLastTick',C.c_uint32)]+[(x,C.c_uint32) for x in 'productionRequest productionAck productionMatch productionTick'.split()]+[('productionCount',C.c_int32),('productionTypes',C.c_int32*4)]

u=Uc(UC_ARCH_X86,UC_MODE_32)
game=pefile.PE(sys.argv[1]); dll=pefile.PE(sys.argv[2])
for pe in (game,dll):
    u.mem_map(pe.OPTIONAL_HEADER.ImageBase,(pe.OPTIONAL_HEADER.SizeOfImage+4095)&~4095)
    u.mem_write(pe.OPTIONAL_HEADER.ImageBase,pe.get_memory_mapped_image())
SH=0x20000000;HEAP=0x21000000;STACK=0x30000000;STOP=0x31000000;STUB=0x32000000
for a,n in [(0,0x10000),(SH,0x400000),(HEAP,0x400000),(STACK-0x100000,0x120000),(STOP,0x10000),(STUB,0x10000)]:u.mem_map(a,n)
def w(a,v):u.mem_write(a,struct.pack('<I',v&0xffffffff))
def r(a):return struct.unpack('<I',u.mem_read(a,4))[0]
def b(a,v):u.mem_write(a,bytes([int(v)]))
w(0,0xffffffff);u.reg_write(UC_X86_REG_CR4,0x600)
clock=1000;counter=1;va_count=0;held_keys=set();action_overrides={};calls=[];imports={};factory_available=True;canbuild_calls=[];used_sizes={};blocked_pairs=set();enter_queries=[];projection_calls=0;size_calls=0;projection_visible_bounds=None;posted_messages=[];projection_receipts=[];sidebar_add_calls=[];watch_reads=set();watched_read_count=0
for entry in dll.DIRECTORY_ENTRY_IMPORT:
    for imp in entry.imports:
        a=STUB+len(imports)*16;imports[a]=imp.name.decode();w(imp.address,a)
def ret(value,argc):
    sp=u.reg_read(UC_X86_REG_ESP);ip=r(sp)
    u.reg_write(UC_X86_REG_EAX,value&0xffffffff);u.reg_write(UC_X86_REG_ESP,sp+4+argc*4);u.reg_write(UC_X86_REG_EIP,ip)
def on_code(uc,a,size,_):
    global counter,projection_calls,size_calls,va_count,watched_read_count
    sp=u.reg_read(UC_X86_REG_ESP)
    arg=lambda i:r(sp+4+i*4)
    if a in imports:
        n=imports[a]
        if n=='GetCurrentProcessId':ret(123,0)
        elif n=='GetCurrentProcess':ret(0xffffffff,0)
        elif n in ('GetTickCount','timeGetTime'):ret(clock,0)
        elif n=='OpenFileMappingW':ret(1,3)
        elif n=='MapViewOfFile':ret(SH,5)
        elif n=='ReadProcessMemory':
            u.mem_write(arg(2),bytes(u.mem_read(arg(1),arg(3))));w(arg(4),arg(3));ret(1,5)
        elif n in ('QueryPerformanceCounter','QueryPerformanceFrequency'):
            u.mem_write(arg(0),struct.pack('<Q',counter if n.endswith('Counter') else 1000000));counter+=10;ret(1,1)
        elif n=='VirtualProtect':w(arg(3),0x20);ret(1,4)
        elif n=='FlushInstructionCache':ret(1,3)
        elif n=='GetModuleHandleExW':w(arg(2),dll.OPTIONAL_HEADER.ImageBase);ret(1,3)
        elif n=='VirtualAlloc':
            ret(HEAP+0x3e0000+va_count*4096,4);va_count+=1
        elif n=='GetAsyncKeyState':ret(0x8000 if arg(0) in held_keys else 0,1)
        elif n=='CallNextHookEx':ret(0,4)
        elif n=='PostMessageW':posted_messages.append(tuple(arg(i) for i in range(4)));ret(1,4)
        elif n in ('UnmapViewOfFile','CloseHandle','DisableThreadLibraryCalls'):ret(1,1)
        else:raise AssertionError('unexpected import '+n)
    elif a==0x6d2140:
        projection_calls+=1;projection_receipts.append((r(SH+Shared.ack.offset),r(SH+Shared.request.offset)));p=arg(0);x,y,z=struct.unpack('<iii',u.mem_read(p,12));tactical=u.reg_read(UC_X86_REG_ECX);w(arg(1),x//256-r(tactical+0xb0));w(arg(1)+4,y//256-r(tactical+0xb4));ret(int(projection_visible_bounds is None or (0<=x//256-r(tactical+0xb0)<projection_visible_bounds[0] and 0<=y//256-r(tactical+0xb4)<projection_visible_bounds[1])),2)
    elif a==0x4f7870:
        canbuild_calls.append((u.reg_read(UC_X86_REG_ECX),arg(0),arg(1),arg(2)));ret(1 if arg(1) else 0,3)
    elif a==0x5f7900:ret(building if factory_available else 0,4)
    elif a==0x6abc60:
        k=u.reg_read(UC_X86_REG_ECX);ret(0 if k==7 else 2 if k==16 else 3,1)
    elif a==0x6a6300:
        sidebar_add_calls.append((arg(0),arg(1)))
        k,index=arg(0),arg(1);tab=0 if k==7 else 2 if k==16 else 3
        strip=0x87f7e8+0x1544+tab*3988;count=r(strip+84)
        if not any(r(strip+88+j*52)==index and r(strip+92+j*52)==k for j in range(count)):
            w(strip+88+count*52,index);w(strip+92+count*52,k);w(strip+84,count+1)
        ret(1,2)
    elif a==0x578080:ret(0,1)
    elif a==0x473460:size_calls+=1;ret(used_sizes.get(u.reg_read(UC_X86_REG_ECX)-0x114,3),0)
    elif a in (0x51e3b0,0x73fd50):
        source=u.reg_read(UC_X86_REG_ECX);target=arg(0);assert arg(1)==1
        enter_queries.append((source,target));ret(action_overrides.get((source,target),31 if (source,target) in blocked_pairs or a==0x73fd50 else 3),2)
    elif a==0x6cc360:ret(u.mem_read(u.reg_read(UC_X86_REG_ECX)+0x6f,1)[0],0)
    elif a in (0x48dc90,0x6fbfa0,0x6d2420,0x431410,0x577d90,0x4a8bf0,0x4ac8c0,0x4ac660):
        calls.append((a,u.reg_read(UC_X86_REG_ECX),[arg(i) for i in range(2)]))
        ret(1,{0x48dc90:0,0x6fbfa0:0,0x6d2420:2,0x431410:1,0x577d90:1,0x4a8bf0:1,0x4ac8c0:1,0x4ac660:1}[a])
for target in list(imports)+[0x4f7870,0x5f7900,0x6abc60,0x6a6300,0x6d2140,0x578080,0x473460,0x51e3b0,0x73fd50,0x6cc360,0x48dc90,0x6fbfa0,0x6d2420,0x431410,0x577d90,0x4a8bf0,0x4ac8c0,0x4ac660]:
    u.hook_add(UC_HOOK_CODE,on_code,begin=target,end=target)
def run(address,args=(),self=0):
    sp=STACK+0x1e000;u.mem_write(sp,struct.pack('<'+'I'*(len(args)+1),STOP,*args));u.reg_write(UC_X86_REG_ESP,sp);u.reg_write(UC_X86_REG_ECX,self)
    u.emu_start(address,STOP,count=2000000)
    assert u.reg_read(UC_X86_REG_EIP)==STOP, 'instruction budget exceeded'
    assert u.reg_read(UC_X86_REG_ESP)==sp+4+4*len(args),'calling convention / stack imbalance'

# Original engine constructors, not a reimplementation of their serialization.
ev=SH+0x30000;cell=ev+256;w(0xa8ed84,12345);u.mem_write(cell,struct.pack('<hh',42,63))
for address,args,payload in [(0x4c65e0,(2,0x15,987,0),struct.pack('<IB',987,0)),(0x4c6970,(2,0xe,40,7,1),struct.pack('<iii',40,7,1)),(0x4c6b60,(2,0x12,3,cell),struct.pack('<ihh',3,42,63))]:
    u.mem_write(ev,b'\0'*111);run(address,args,ev);data=bytes(u.mem_read(ev,111))
    assert data[:7]==struct.pack('<BBBI',args[1],0,2,12345)
    assert data[7:7+len(payload)]==payload
print('PASS: original repair / production / superweapon event constructors and x86 stack cleanup')

cursor=HEAP
def alloc(n=4096):
    global cursor
    p=cursor;cursor+=(n+15)&~15;return p
def vector(at,values):
    p=alloc(max(16,4*len(values)))
    for i,x in enumerate(values):w(p+i*4,x)
    u.mem_write(at,struct.pack('<6I',0,p,len(values),0x101,len(values),10))
house=alloc(0x20000);enemy=alloc(0x20000);t=alloc(0x2000);engT=alloc(0x2000);buildT=alloc(0x2000)
w(house+0x30,0);w(enemy+0x30,1);w(house+0x5788,1);w(house+0x30c,10000)
for typ,id in [(t,b'HTNK'),(engT,b'ENGINEER'),(buildT,b'NAPOWR')]:
    u.mem_write(typ+0x24,id+b'\0');w(typ+0xa0,100);w(typ+0x634,5);w(typ+0x6cc,1);w(typ+0x610,500)
w(t+0x5e0,6);b(t+0xdbc,1);b(engT+0xec3,1)
def obj(vt,typ,owner,id,hp=100,selected=False):
    b(typ+0x231,1);b(typ+0xd3a,1);b(typ+0xd38,1);w(typ+0x684,0xffffffff)
    p=alloc(0x2000);w(p,vt);w(p+0x10,id);w(p+0x6c,hp);b(p+0x74,1);b(p+0x90,1);b(p+0x83,selected);w(p+0x21c,owner);w(p+(0x520 if vt==0x7e3ebc else 0x6c0 if vt==0x7eb058 else 0x6c4),typ);w(p+0xac,5);w(p+0xb4,0xffffffff);u.mem_write(p+0x9c,struct.pack('<iii',25600+id*256,25600,0));return p
unit=obj(0x7f5c70,t,house,10,60,True);eng=obj(0x7eb058,engT,house,11);building=obj(0x7e3ebc,buildT,house,12,50);enemyUnit=obj(0x7f5c70,t,enemy,13)
w(enemyUnit+0x2b4,unit);w(unit+0x18c,90);w(unit+0x194,60)
vector(0xa80228,[house,enemy]);vector(0xa8ec78,[unit,eng,building,enemyUnit]);vector(0xa8ecb8,[unit,eng]);vector(0xa8eb40,[building])
vector(0xa83ce0,[t]);vector(0xa8e348,[engT]);vector(0xa83c68,[buildT]);vector(0xa8b218,[]);vector(0xa83e30,[]);vector(house+0x254,[])
w(0xa83d4c,house);b(0xa8e9a0,1);w(0xac1198,0);w(0xa8ed84,100);w(0xa8b238,5);w(0xa8eb84,800);w(0xa8eb88,600);w(0x887324,alloc());w(0xa802c8,0);w(0xa802d0,0)
# One live crate and a stale expired entry, no whole-map scan.
cells=alloc(512*64*4);w(0x87f7e8+316,cells);w(0x87f7e8+320,512*64)
crateCell=alloc();w(crateCell+68,5);w(cells+(30*512+20)*4,crateCell)
overlayType=alloc();b(overlayType+0x2aa,1);vector(0xa83d80,[0,0,0,0,0,overlayType]);b(crateCell+0x11e,255)
u.mem_write(0x87f7e8+344,struct.pack('<iii hh',90,0,900,20,30))
u.mem_write(0x87f7e8+360,struct.pack('<iii hh',0,0,1,20,30))
s=Shared();s.magic=0x41533130;s.version=30;s.pid=123;s.heartbeat=clock;s.foreground=1;s.flags=1|2|4|16|32;s.scanMs=100;s.repairMs=2000
u.mem_write(SH,bytes(s));entry=dll.OPTIONAL_HEADER.ImageBase+next(e.address for e in dll.DIRECTORY_ENTRY_EXPORT.symbols if e.name==b'AssistHook')
def hook():
    global clock
    clock+=110;w(SH+Shared.heartbeat.offset,clock);run(entry,(0,1,0));return Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)))
s=hook();assert s.data.status==1 and s.data.typeCount==3
assert s.data.labels==1 and s.data.label[0].used==3 and s.data.label[0].capacity==6 and s.data.label[0].ironFrames==50
assert s.data.threatCount==1 and s.data.threats[0].target==10
assert s.data.crateCount==1 and s.data.crates[0].cellX==20
assert s.data.crates[0].preview==-1, 'random crate must never be advertised as money'
print('PASS: compiled bridge connection / type discovery / capacity / iron / psychic / crate filtering')
def command(c,arg=0,stale=False):
    s=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)));s.command=c;s.arg=arg;s.request+=1;s.requestTick=((clock-4000)&0xffffffff) if stale else clock;s.requestMatch=s.data.match
    u.mem_write(SH,bytes(s));out=hook();assert out.ack==out.request;return out
s=command(1);assert s.result==1 and s.count==1 and r(0xa802c8)==1
assert bytes(u.mem_read(0xa802c8+12,12))[7:12]==struct.pack('<IB',12,0x34)
s=command(2);assert s.count==1 and any(c[0]==0x6fbfa0 and c[1]==unit for c in calls)
s=command(6);assert s.count==1 and any(c[0]==0x6d2420 for c in calls)
s=command(9,stale=True);assert C.c_int32(s.result).value==-7
b(0xa8bc60+25,1);s=command(9);assert C.c_int32(s.result).value==-8;b(0xa8bc60+25,0)
s=command(9);assert s.result==1 and any(c[0]==0x577d90 for c in calls)
s=command(8);assert s.result==1 and any(c[0]==0x431410 for c in calls)
print('PASS: compiled repair event / combat filter / idle engineer / stale and chat rejection / map / beacons')
w(0x87f7e8+0x1544+3*3988+84,1);w(0x87f7e8+0x1544+3*3988+88,0);w(0x87f7e8+0x1544+3*3988+92,40)
s.techAllowed[1]=1;u.mem_write(SH,bytes(s));s=command(10,1);assert s.count==1
s=command(12,0);assert C.c_int32(s.result).value==-4
s=command(12,1);assert s.result==1
w(0xa802c8,112);s=command(12,1);assert C.c_int32(s.result).value==-6
s=command(10,0);s=command(12,1);assert C.c_int32(s.result).value==-4
print('PASS: allow-list inclusion/exclusion / disabled production / queue backpressure')
# Targeted superweapon: arm the original targeting UI without firing at (0,0).
w(0xa802c8,0);w(0xa802d0,0)
sw=alloc();swtype=alloc();w(sw+0x28,swtype);w(sw+0x2c,house);b(sw+0x6d,1);b(sw+0x6f,1);w(swtype+0xbc,1);w(swtype+0x98,3)
u.mem_write(swtype+0x24,b'IronCurtainSpecial\0');vector(house+0x254,[sw])
s=command(11,0);assert s.result==1 and r(0x8809a0)==0 and r(0xa802c8)==0
b(sw+0x6f,0);s=command(11,0);assert C.c_int32(s.result).value==-5
b(sw+0x6f,1);w(swtype+0xbc,0);s=command(11,0);assert s.result==1 and r(0xa802c8)==1
assert bytes(u.mem_read(0xa802c8+12,15))[7:15]==struct.pack('<ihh',3,0,0)
print('PASS: targeted superweapon arms without firing / cooldown rejection / targetless event payload')
factory=alloc();w(factory+0x6c,house);w(factory+0x58,unit);vector(0xa83e30,[factory]);w(house+0x53b4,factory)
for _ in range(6):s=hook()
serial=s.data.noticeSerial;w(factory+0x24,54)
for _ in range(6):s=hook()
assert s.data.noticeSerial==serial+1
assert r(0x87f7e8+0x1544+3*3988+88+48)>r(0xa8ed84), 'native vehicle cameo did not flash'
serial=s.data.noticeSerial;b(factory+0x5c,1)
for _ in range(6):s=hook()
assert s.data.noticeSerial==serial+1
serial=s.data.noticeSerial;w(factory+0x58,0);w(factory+0x50,0)
for _ in range(6):s=hook()
assert s.data.noticeSerial==serial, 'completion was announced twice when the factory became empty'
w(factory+0x58,unit)
for _ in range(6):s=hook()
print('PASS: production completion and pause transitions (no baseline alert)')
# Custom technology does not patch either sidebar CanBuild call or the shared
# house validation function. Production is an ordinary type/index event.
canbuild_entry=bytes(u.mem_read(0x4f7870,8))
sidebar_sites={a:bytes(u.mem_read(a,5)) for a in (0x6a97d2,0x6aa781)}
s=command(10,1);assert s.result==1 and s.data.techVisible==1
assert bytes(u.mem_read(0x4f7870,8))==canbuild_entry
assert all(bytes(u.mem_read(a,5))==data for a,data in sidebar_sites.items())
s=command(10,0);assert all(bytes(u.mem_read(a,5))==data for a,data in sidebar_sites.items())
print('PASS: external catalogue and vanilla production without any CanBuild code patch')
# Regression: enabling/changing the external catalogue must not patch native
# cleanup, CanBuild, add a cameo, remove a cameo, or cancel production.
retention_site=0x6aa7b6;native_cleanup=bytes(u.mem_read(retention_site,6));adds=len(sidebar_add_calls)
s=command(10,1);assert bytes(u.mem_read(retention_site,6))==native_cleanup
w(0xa802c8,0);w(0xa802d0,0)
for _ in range(30):
 w(0xa8ed84,r(0xa8ed84)+1);s=command(12,1);assert s.result==1
batch=bytes(u.mem_read(0xa802d4,30*111));assert all(batch[i*111]==0xe for i in range(30))
for _ in range(4):clock+=990;s=hook()
assert r(0xa802c8)==30 and bytes(u.mem_read(0xa802d4,30*111))==batch
assert bytes(u.mem_read(retention_site,6))==native_cleanup and len(sidebar_add_calls)==adds
s=command(10,0)
print('PASS: external technology catalogue leaves native cleanup/CanBuild/cameos unchanged; 30 explicit original Produce events retain their defined payloads (not a live production test)')

# Dedicated commands are available without a GUI combo-box binding.
u.mem_write(swtype+0x24,b'IronCurtainSpecial\0');w(swtype+0xbc,1);s=command(13);assert s.result==1
u.mem_write(swtype+0x24,b'ChronoSphereSpecial\0');s=command(14);assert s.result==1
print('PASS: direct Iron Curtain and Chronosphere hotkey commands')
# Automatic repair starts on mode enable, repeats, and respects a network toggle cooldown.
b(building+0x6e8,0);w(building+0x6c,40);w(0xa802c8,0);w(0xa802d0,0)
s=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)));s.flags|=64;s.repairMs=500;u.mem_write(SH,bytes(s))
clock+=5100;s=hook();first=r(0xa802c8);assert first==1 and s.data.autoRepair==1
for _ in range(12):s=hook()
assert r(0xa802c8)==first, 'duplicate repair can toggle repairing off before event arrives'
clock+=5100;s=hook();assert r(0xa802c8)==first+1
s.flags&=~64;u.mem_write(SH,bytes(s));clock+=6000;s=hook();assert r(0xa802c8)==first+1 and s.data.autoRepair==0
s.flags|=64;u.mem_write(SH,bytes(s));b(building+0x6e8,1);clock+=6000;s=hook();assert r(0xa802c8)==first+1
print('PASS: recurring automatic repair / duplicate cooldown / disable / already repairing skip')
# Infantry factories must not trigger the two requested categories.
inf_factory=alloc();w(inf_factory+0x6c,house);w(inf_factory+0x58,eng);w(house+0x53b0,inf_factory)
for _ in range(6):s=hook()
serial=s.data.noticeSerial;w(inf_factory+0x24,54)
for _ in range(6):s=hook()
assert s.data.noticeSerial==serial
s.flags&=~4;u.mem_write(SH,bytes(s))
for _ in range(6):s=hook()
assert r(0x87f7e8+0x1544+3*3988+88+48)==0
print('PASS: infantry reminder excluded / native flash disabled')
w(house+0x5788,3);s=hook();assert s.data.threatCount==0
b(house+0x1f5,1);s=hook();assert s.data.status==0 and s.data.threatCount==0 and s.data.crateCount==0
print('PASS: allies excluded / defeated player resets overlays')
# Persisted flags can re-apply on next match; the enabled auto mode is not cleared.
b(house+0x1f5,0);b(building+0x6e8,0);w(0xa8ed84,1);w(0xa802c8,0);s=hook();assert s.data.status==1 and s.data.autoRepair==1 and r(0xa802c8)==1
s=command(10,1);assert s.data.techOpen==1
w(SH+Shared.stop.offset,1);s=hook();assert s.stop==2
assert bytes(u.mem_read(0x6a97d2,5))==bytes.fromhex('e8 99 e0 e4 ff')
print('PASS: automatic repair re-applies on next match / stop acknowledgement restores sidebar hooks')


# Reconnect after the previous stop with a fresh test selection. These are
# synthetic game objects; the Enter event constructor remains original code.
s=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)));s.stop=0;s.flags=0;s.request=s.ack;s.heartbeat=clock;u.mem_write(SH,bytes(s))
GI=alloc(0x2000);w(GI+0xa0,100);u.mem_write(GI+0x380,struct.pack('<d',1.0))
IFV=alloc(0x2000);BFRT=alloc(0x2000);APC=alloc(0x2000)
for typ,cap in ((IFV,1),(BFRT,5),(APC,2)):
    w(typ+0x5e0,cap);w(typ+0xa0,100);u.mem_write(typ+0x388,struct.pack('<d',3.))
cars=[obj(0x7f5c70,t,house,90+j,selected=True) for j,t in enumerate((IFV,BFRT,APC))]
for car,x in zip(cars,(0,512,2048)):u.mem_write(car+0x9c,struct.pack('<iii',x,0,0))
w(cars[1]+0x114,2);used_sizes[cars[1]]=2
existing=[obj(0x7eb058,GI,house,90+j) for j in range(2)];w(cars[1]+0x118,existing[0]);w(existing[0]+0x30,existing[1])
soldiers=[obj(0x7eb058,GI,house,100+j,selected=True) for j in range(6)]
for p in soldiers:u.mem_write(p+0x9c,struct.pack('<iii',0,0,0))
manual=[obj(0x7eb058,GI,house,200+j) for j in range(2)]
for p in manual:w(p+0xac,7);w(p+0x2b4,cars[1])
vector(0xa83de8,soldiers+manual);vector(0xa8ecb8,cars+soldiers);vector(0xa8ec78,cars+soldiers+manual)
w(0xa802c8,0);w(0xa802d0,0);s=hook();s=command(15)
assert s.result==1 and s.count==4 and s.data.loadUnassigned==2,(s.result,s.count,s.data.loadUnits,s.data.loadVehicles,s.data.loadUnassigned,enter_queries[-15:])
assert s.data.loadVehicles==3 and s.data.loadUnits==6
records=[bytes(u.mem_read(0xa802c8+12+i*111,111)) for i in range(4)]
for ev,src,dest in zip(records,(100,101,102,103),(90,91,92,92)):
    assert ev[0]==4 and ev[2]==0 and ev[7:12]==struct.pack('<IB',src,0x34)
    assert ev[12]==7 and ev[14:19]==bytes(5)
    assert ev[19:24]==struct.pack('<IB',dest,0x34) and ev[24:29]==bytes(5)
assert all(r(p+0xac)==5 and r(p+0x2b4)==0 and r(p+0x11c)==0 for p in soldiers)
s=command(15);assert s.count==0 and s.data.loadWaiting==4 and r(0xa802c8)==4
print('PASS: compiled Enter events / nearest IFV and partial BFRT / manual incoming space / reservations / repeated hotkey')

# Receipt, backpressure and cancellation: a single press retains work until
# Enter becomes visible / boarding completes; it never writes attack targets.
for p in soldiers[:4]:w(p+0xac,7)
for p,dest in zip(soldiers[:4],(cars[0],cars[1],cars[2],cars[2])):w(p+0x5a4,dest)
prior=r(0xa802c8);w(0xa8ed84,r(0xa8ed84)+31);s=hook();assert r(0xa802c8)==prior
# A manual Guard after observed Enter cancels automatic boarding retries.
w(soldiers[0]+0xac,5);w(soldiers[0]+0x5a4,0);w(0xa8ed84,r(0xa8ed84)+31);s=hook();assert r(0xa802c8)==prior
# Reset the match, fill the queue, accept assignments, then drain and advance.
w(0xa8ed84,0);s=hook()
for p in soldiers+manual:w(p+0xac,5);w(p+0x5a4,0);w(p+0x2b4,0)
vector(0xa8ecb8,[cars[2],soldiers[0],soldiers[1]]);vector(0xa83de8,soldiers)
w(0xa802c8,112);w(0xa802d0,0);s=command(15);assert s.result==2 and s.count==0 and r(0xa802c8)==112
w(0xa802c8,0);w(0xa802d0,0);w(0xa8ed84,1);s=hook();assert r(0xa802c8)==2
assert all(r(0xa802d4+i*111+14)==0 and r(0xa802d4+i*111+19)==92 for i in range(2))
# Boarding ends the retry job. Unloading later cannot restart it.
for q in soldiers[:2]:w(q+0x11c,cars[2]);b(q+0x81,1)
w(0xa8ed84,2);s=hook();prior=r(0xa802c8)
for q in soldiers[:2]:w(q+0x11c,0);b(q+0x81,0)
w(0xa8ed84,200);s=hook();assert r(0xa802c8)==prior
print('PASS: native Enter has null attack target / queued-once automatic retry / receipt suppression / queue backpressure / no reload after disembark')
w(0xa802c8,0);w(0xa802d0,0)
b(0xa8bc60+25,1);s=command(15);assert C.c_int32(s.result).value==-8;b(0xa8bc60+25,0)
s=command(15,stale=True);assert C.c_int32(s.result).value==-7
saved_vector=bytes(u.mem_read(0xa8ec78,24));u.mem_write(0xa8ec78,bytes(24));s=command(15);assert C.c_int32(s.result).value==-4;u.mem_write(0xa8ec78,saved_vector)
print('PASS: auto-board chat / stale / missing-world rejection')
# Global timers retain own-player capacity filtering. Repeated render wakes
# must not scan or publish the same simulation frame hundreds of times.
ally=alloc(0x20000);w(ally+0x30,2);vector(0xa80228,[house,enemy,ally]);w(house+0x5788,5)
alliedUnit=obj(0x7f5c70,t,ally,800,selected=True)
vector(0xa8ec78,[unit,building,enemyUnit,alliedUnit])
for p in (unit,building,enemyUnit,alliedUnit):w(p+0x18c,100);w(p+0x194,150)
w(building+0x1c4,1);w(0xa8ed84,100)
s=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)));s.flags=1|2|32;s.scanMs=2;u.mem_write(SH,bytes(s));s=hook()
assert {s.data.label[i].id for i in range(s.data.labels)}=={10,12,13,800}
assert s.data.transports==1 and s.data.capacity==6
assert next(s.data.label[i] for i in range(s.data.labels) if s.data.label[i].id==12).shield==1
assert all(s.data.label[i].capacity==0 for i in range(s.data.labels) if s.data.label[i].id!=10)
def pulse(delta=2):
    global clock
    clock+=delta;w(SH+Shared.heartbeat.offset,clock);run(entry,(0,1,0));return Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)))
seq=s.seq;projections=projection_calls;reads=size_calls
for _ in range(20):s=pulse()
assert s.seq==seq and projection_calls==projections and size_calls==reads
w(0xa8ed84,101);s=pulse(20);assert s.data.label[0].ironFrames==149 and projection_calls>projections
projections=projection_calls;tactical=r(0x887324);old_x=s.data.label[0].x;w(tactical+0xb0,12);s=pulse()
assert s.data.cameraX==12 and s.data.label[0].x==old_x-12 and projection_calls==projections
print('PASS: global enemy / allied / building shield timers; own capacity; paused-frame scan reuse; camera-only cache shift')
many=[obj(0x7f5c70,t,enemy,1000+i) for i in range(220)]
for p in many:w(p+0x18c,101);w(p+0x194,150)
vector(0xa8ec78,many);s=pulse(110);assert s.data.labels==220
print('PASS: more than the previous 192 protected-unit labels')

# Removed feature: even the legacy on-bit must never patch collection code.
sites={0x481dc3:7,0x482215:5,0x482449:5,0x483389:5}
original_sites={a:bytes(u.mem_read(a,n)) for a,n in sites.items()}
s.flags|=256;u.mem_write(SH,bytes(s));s=pulse(110)
assert s.data.crateHookStatus==0 and s.data.crateResultCount==0
assert all(bytes(u.mem_read(a,n))==original_sites[a] for a,n in sites.items())
s.flags&=~256;u.mem_write(SH,bytes(s));s=pulse(110)
print('PASS: removed crate-result flag cannot install any reward hook')
country=alloc();w(house+0x34,country);w(enemy+0x34,country)
tracked=[UC_X86_REG_EAX,UC_X86_REG_ECX,UC_X86_REG_EDX,UC_X86_REG_EBX,UC_X86_REG_EBP,UC_X86_REG_ESI,UC_X86_REG_EDI,UC_X86_REG_ESP,UC_X86_REG_EFLAGS,UC_X86_REG_MXCSR,UC_X86_REG_FPCW,UC_X86_REG_FPSW]+[UC_X86_REG_XMM0+i for i in range(8)]+[UC_X86_REG_FP0+i for i in range(8)]
# New type-selection commands exercise compiled bridge selection and real
# CanBeSelectedNow. Only its final rendering visibility check is isolated.
selectable=True;projection_visible_bounds=(640,480)
u.hook_add(UC_HOOK_CODE,lambda uc,a,size,_:ret(int(selectable),0),begin=0x5f6c70,end=0x5f6c70)
extra=obj(0x7f5c70,t,house,910);offscreen=obj(0x7f5c70,t,house,911)
for p,x,y in ((unit,20,20),(extra,639,479),(offscreen,640,480)):
    u.mem_write(p+0x9c,struct.pack('<iii',x*256,y*256,0));b(p+0x1c8,0);w(p+0x2dc,0);w(p+0x2e4,0);b(p+0x418,0)
vector(0xa8ec78,[unit,extra,offscreen,eng,enemyUnit,alliedUnit,building]);w(tactical+0xb0,0);w(tactical+0xb4,0);w(tactical+0xb8,640);w(tactical+0xbc,480)
# Avoid triggering an artificial new match due to earlier test frame rewinds.
s=pulse(110);idx=next(i for i in range(s.data.typeCount) if s.data.types[i].id==b'HTNK')
s.arg2=0;u.mem_write(SH,bytes(s));calls.clear();s=command(16,idx)
assert s.count==2 and {p for a,p,args in calls if a==0x6fbfa0}=={unit,extra}
s.arg2=1;u.mem_write(SH,bytes(s));calls.clear();s=command(16,idx)
assert s.count==3 and {p for a,p,args in calls if a==0x6fbfa0}=={unit,extra,offscreen}
selectable=False;calls.clear();s=command(16,idx);assert s.count==0 and not calls;selectable=True
s=command(16,-1);assert C.c_int32(s.result).value==-4
b(0xa8bc60+25,1);s=command(16,idx);assert C.c_int32(s.result).value==-8;b(0xa8bc60+25,0)
print('PASS: compiled single-screen / full-map type selection, exact viewport edges, own/live/selectable filtering and chat rejection')

# Separate selection mailbox: exercise repeated intents while a gameplay request
# is also pending. Selection is local, and emits no network event.
for global_scope in (0,1,0,1,0,1):
    s=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)));s.selectIndex=idx;s.selectGlobal=global_scope;s.selectMatch=s.data.match;s.selectTick=clock;s.selectRequest+=1
    s.command=9;s.request+=1;s.requestMatch=s.data.match;s.requestTick=(clock-4000)&0xffffffff
    u.mem_write(SH,bytes(s));calls.clear();s=pulse(110)
    assert s.selectAck==s.selectRequest and C.c_int32(s.selectResult).value==1 and s.selectCount==(3 if global_scope else 2)
    assert C.c_int32(s.result).value==-7
print('PASS: repeated screen/global selection has its own acknowledged lane independent of a rejected gameplay request')

# Native outgoing CS emitter. No simulated-state helper is allowed to run.
projection_visible_bounds=None
weapon=alloc(0x200);projectile=alloc();warhead=alloc();w(weapon+0xa4,777);w(weapon+0xb4,1024);w(weapon+0xa0,projectile);w(weapon+0xac,warhead);b(projectile+0x2a5,1)
for j in range(11):u.mem_write(warhead+0xa0+j*8,struct.pack('<d',1.0))
w(t+0x898,weapon)
packed_target=alloc();packed_cell=alloc();w(packed_target,0);b(packed_target+4,0);w(packed_cell,30020);b(packed_cell+4,11)
b(unit+0x83,1);w(unit+0x11c,0)
cs_site=0x646e90;clicked_original=bytes(u.mem_read(0x6ffbe0,6));cs_original=bytes(u.mem_read(cs_site,5))
assert cs_original==bytes.fromhex('83ec7032c0')
s=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)));s.flags=512;s.csSeq=2;s.csMatch=s.data.match;s.csAllowed[idx]=1;u.mem_write(SH,bytes(s));s=pulse(110)
assert s.data.csHookStatus==1 and bytes(u.mem_read(cs_site,1))==b'\xe9'
assert bytes(u.mem_read(0x6ffbe0,6))==clicked_original
cs_patch=bytes(u.mem_read(cs_site,5));u.ctl_remove_cache(cs_site,cs_site+5)
def emitter_probe(mission=2,source=unit,target=0,dock=0):
    w(packed_cell,dock or 30020);b(packed_cell+4,0x34 if dock else 11)
    w(packed_target,target);b(packed_target+4,0x34 if target else 0)
    sp=STACK+0x1d000;u.mem_write(sp,struct.pack('<4I',STOP,r(source+0x10),0x34,packed_cell))
    for reg,val in ((UC_X86_REG_EAX,0x12345678),(UC_X86_REG_ECX,mission),(UC_X86_REG_EDX,packed_target),(UC_X86_REG_EBX,0x456789ab),(UC_X86_REG_EBP,0x56789abc),(UC_X86_REG_ESI,0x6789abcd),(UC_X86_REG_EDI,0x789abcde),(UC_X86_REG_ESP,sp),(UC_X86_REG_EFLAGS,0x202),(UC_X86_REG_MXCSR,0x1f80),(UC_X86_REG_FPCW,0x37f),(UC_X86_REG_FPSW,0),(UC_X86_REG_FPTAG,0xffff)):u.reg_write(reg,val)
    for i in range(8):u.reg_write(UC_X86_REG_XMM0+i,0x123456789abcdef000123456789abcdef+i);u.reg_write(UC_X86_REG_FP0+i,(0,0))
    before=[u.reg_read(reg) for reg in tracked]
    endpoint=u.hook_add(UC_HOOK_CODE,lambda uc,a,size,_:u.emu_stop(),begin=cs_site+5,end=cs_site+5)
    try:u.emu_start(cs_site,STOP,count=800000)
    finally:u.hook_del(endpoint)
    assert u.reg_read(UC_X86_REG_EIP)==cs_site+5
    after=[u.reg_read(reg) for reg in tracked]
    assert before[2:7]==after[2:7] and after[7]==sp-0x70
    assert before[9:]==after[9:],'XMM / x87 state changed'
    return u.reg_read(UC_X86_REG_ECX)
assert emitter_probe()==29
for mission in (1,7,10,11,13,29):assert emitter_probe(mission)==mission
assert emitter_probe(source=enemyUnit)==2 and emitter_probe(target=r(extra+0x10))==2
b(unit+0x83,0);assert emitter_probe()==2;b(unit+0x83,1)
s.csSeq+=2;s.csAllowed[idx]=0;u.mem_write(SH,bytes(s));assert emitter_probe()==2
s.csSeq+=2;s.csAllowed[idx]=1;u.mem_write(SH,bytes(s));assert emitter_probe()==29
b(0xa8bc60+25,1);assert emitter_probe()==2;b(0xa8bc60+25,0)
s.foreground=0;u.mem_write(SH,bytes(s));assert emitter_probe()==2;s.foreground=1;u.mem_write(SH,bytes(s))
w(SH+Shared.heartbeat.offset,clock-3001);assert emitter_probe()==2;w(SH+Shared.heartbeat.offset,clock)
time_import=r(0x7e1530);u.hook_add(UC_HOOK_CODE,lambda uc,a,size,_:ret(clock,0),begin=time_import,end=time_import)
def native_click(mission=2):
    w(packed_target,0);b(packed_target+4,0);w(0xa802c8,0);w(0xa802d0,0);u.reg_write(UC_X86_REG_EFLAGS,0x202)
    sp=STACK+0x1d000;u.mem_write(sp,struct.pack('<4I',STOP,r(unit+0x10),0x34,packed_cell));u.reg_write(UC_X86_REG_ESP,sp);u.reg_write(UC_X86_REG_ECX,mission);u.reg_write(UC_X86_REG_EDX,packed_target)
    u.emu_start(cs_site,STOP,count=800000)
    assert u.reg_read(UC_X86_REG_EIP)==STOP and u.reg_read(UC_X86_REG_ESP)==sp+16 and r(0xa802c8)==1
    return bytes(u.mem_read(0xa802d4,111))
manual=native_click(29);converted=native_click(2)
# The original constructor leaves unused union padding uninitialized. Compare
# every defined MegaMission field, rather than unrelated stack padding.
assert manual[:30]==converted[:30] and converted[12]==29 and r(0xa802d4+7)==10

# Full trampoline register/flags result equals vanilla construction prologue.
u.mem_write(cs_site,cs_original);u.ctl_remove_cache(cs_site,cs_site+5);emitter_probe(29);baseline=[u.reg_read(reg) for reg in tracked]
u.mem_write(cs_site,cs_patch);u.ctl_remove_cache(cs_site,cs_site+5);emitter_probe(2);observed=[u.reg_read(reg) for reg in tracked]
assert baseline==observed
s=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)));s.flags=0;u.mem_write(SH,bytes(s));s=pulse(110);assert bytes(u.mem_read(cs_site,5))==cs_original
print('PASS: CS changes only the outgoing mission, preserves registers/FPU, leaves ClickedMission intact and emits identical defined native CS fields')

# External planning integration: trap the former game-side decision functions.
ui_query_guards={}
for address in (0x73fd50,0x740fd0,0x7414a0,0x44efb0):
    ui_query_guards[address]=u.hook_add(UC_HOOK_CODE,lambda uc,a,size,_:(_ for _ in ()).throw(AssertionError('unexpected game decision '+hex(a))),begin=address,end=address)
u.mem_write(unit+0x9c,struct.pack('<iii',5000,5000,0));u.mem_write(enemyUnit+0x9c,struct.pack('<iii',5500,5100,0));w(unit+0x194,0);w(enemyUnit+0x194,0)
s.flags=1024|8192;s.advancedKey=ord('G')|(4<<8);s.pathTimeout=90;s.foreground=1;u.mem_write(SH,bytes(s));s=pulse(110)
assert s.data.nativeHookStatus==1
for address,n in ((cs_site,5),(0x731bf0,6),(0x6ffe00,5)):u.ctl_remove_cache(address,address+n)
held_keys.update((ord('G'),0x12));assert emitter_probe()==29;held_keys.clear()
w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert s.world.intentCount==1 and s.world.intents[0].id==10
intent=s.world.intents[0];assert intent.cell==30020
unit_raw=next(a for a in s.world.actors[:s.world.count] if a.id==10);assert unit_raw.range==1024
w(0xa802c8,0);w(0xa802d0,0)
def external_order(mission,target=0,destination=0,tag=0,purpose=1,token=None,wrong_match=False,stale=False,unit_id=10,refinery_id=0):
    q=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)));q.planCount=1;q.planMatch=q.data.match+int(wrong_match);q.planTick=((clock-400)&0xffffffff) if stale else clock
    q.plan[0]=Order(unit_id,intent.token if token is None else token,target,destination,mission,tag,purpose,refinery_id);q.planRequest+=1;u.mem_write(SH,bytes(q));out=pulse(110);assert out.planAck==out.planRequest;return out
s=external_order(1,target=13);assert s.planAccepted==1 and r(0xa802c8)==1
record=bytes(u.mem_read(0xa802d4,111));assert record[12]==1 and record[14:19]==struct.pack('<IB',13,0x34)
before=r(0xa802c8);s=external_order(1,target=800);assert s.planAccepted==0 and r(0xa802c8)==before
s=external_order(1,target=13,token=intent.token-1);assert s.planAccepted==0 and r(0xa802c8)==before
s=external_order(1,target=13,wrong_match=True);assert C.c_int32(s.planResult).value==-7
s=external_order(1,target=13,stale=True);assert C.c_int32(s.planResult).value==-7
w(0xa802c8,112);s=external_order(1,target=13);assert C.c_int32(s.planResult).value==-6 and s.planAccepted==0
w(0xa802c8,0);w(0xa802d0,0)
# A manual S-style local event entry invalidates the old token, before vanilla execution.
sp=STACK+0x1d000;u.mem_write(sp,struct.pack('<2I',STOP,6));u.reg_write(UC_X86_REG_ESP,sp);u.reg_write(UC_X86_REG_ECX,unit)
endpoint=u.hook_add(UC_HOOK_CODE,lambda uc,a,size,_:u.emu_stop(),begin=0x6ffe05,end=0x6ffe05)
try:u.emu_start(0x6ffe00,STOP,count=800000)
finally:u.hook_del(endpoint)
s=external_order(1,target=13);assert s.planAccepted==0 and r(0xa802c8)==0
held_keys.update((ord('G'),0x12));assert emitter_probe()==29;held_keys.clear()
w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);intent=s.world.intents[0]
# Position/state can change after the EXE's snapshot. Late checks reject it.
u.mem_write(enemyUnit+0x9c,struct.pack('<iii',8000,8000,0));s=external_order(1,target=13);assert s.planAccepted==0
u.mem_write(enemyUnit+0x9c,struct.pack('<iii',5500,5100,0));b(enemyUnit+0x134,1);s=external_order(1,target=13);assert s.planAccepted==0;b(enemyUnit+0x134,0)
w(enemyUnit+0x194,60);w(enemyUnit+0x18c,r(0xa8ed84));s=external_order(1,target=13);assert s.planAccepted==0;w(enemyUnit+0x194,0)
print('PASS: late raw range / AA / invulnerability guards reject targets that changed after planning')
print('PASS: raw world publication and native external Attack serialization; enemy/ally, stale match, stale token, backpressure and manual-input cancellation guards; no game-side tactical decision calls')

# PlaceAnywhere: only confirmed single-player sessions can install/use it.
placement_site=0x464ac0;placement_original=bytes(u.mem_read(placement_site,6));assert placement_original==bytes.fromhex('8a8103170000')
s=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)));s.flags=65536;u.mem_write(SH,bytes(s));w(0xa8b238,5);s=pulse(110)
assert s.data.placementStatus==1;u.ctl_remove_cache(placement_site,placement_site+6)
run(placement_site,(packed_cell,house),buildT);assert u.reg_read(UC_X86_REG_EAX)&255==1
w(0xa8b238,3);s=pulse(110);assert s.data.placementStatus==-3 and bytes(u.mem_read(placement_site,6))==placement_original
s.flags=0;u.mem_write(SH,bytes(s));s=pulse(110)
assert bytes(u.mem_read(cs_site,5))==cs_original
assert bytes(u.mem_read(0x6ffbe0,6))==clicked_original
print('PASS: single-player placement hook and automatic restoration/blocking in LAN mode')

# Push receipts are coalesced and published before overlay projection.
vector(0xa8ec78,[unit,building,enemyUnit]);vector(0xa8ecb8,[unit]);vector(0xa8eb40,[building])
w(0xa8ed84,r(0xa8ed84)+1);w(unit+0x18c,r(0xa8ed84));w(unit+0x194,150)
s=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)));s.flags=2;s.hostWindow=0x12345;s.owner=77;s.hostNotifyPending=0;s.gameWakePending=1;u.mem_write(SH,bytes(s))
message=alloc();u.mem_write(message,struct.pack('<7I',0,0,0x41533230,77,0,0,0))
posted_messages.clear();clock+=110;w(SH+Shared.heartbeat.offset,clock);run(entry,(0,1,message));s=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)))
assert s.gameWakePending==0 and s.hostNotifyPending==1
assert posted_messages==[(0x12345,0x8002,123,0)]
for _ in range(3):w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert len(posted_messages)==1
w(SH+Shared.hostNotifyPending.offset,0);projection_receipts.clear();s=command(2)
assert posted_messages[-1]==(0x12345,0x8002,123,0)
assert projection_receipts and all(ack==request for ack,request in projection_receipts), 'gameplay ACK was still blocked by overlay projection'
print('PASS: coalesced host notifications / tagged game-wake receipt / gameplay ACK before any recurring overlay scan')

# Advanced enabled with no local intent does not publish a whole-world snapshot.
s.flags=1024|8192;s.hostWindow=0;u.mem_write(SH,bytes(s));w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert s.world.count==0 and s.world.intentCount==0
revision=s.worldSeq
for _ in range(4):w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert s.worldSeq==revision
# Count actual object-ID memory reads in the compiled DLL, after mode switches
# settle. Display flags are off in both cases; no command or intent is pending.
idle_reads=[]
def watch_memory(uc,access,address,size,value,_):
    global watched_read_count
    if address in watch_reads:watched_read_count+=1
for mode in (0,1024|8192):
    s.flags=mode;u.mem_write(SH,bytes(s));w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
    watch_reads.update(p+0x10 for p in (unit,building,enemyUnit));watched_read_count=0
    probe_hooks=[u.hook_add(UC_HOOK_MEM_READ,watch_memory,begin=p,end=p+3) for p in watch_reads]
    for _ in range(4):w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
    for h in probe_hooks:u.hook_del(h)
    idle_reads.append(watched_read_count);watch_reads.clear()
print('IDLE_INDEX_PROBE: disabled_id_reads=%d advanced_idle_id_reads=%d frames=4 actors=3'%tuple(idle_reads))
if '--idle-probe' in sys.argv:raise SystemExit(0)
assert idle_reads[1]<=idle_reads[0], 'idle advanced still rebuilds world object index'
# Ore alone reads owned miners and their compatible refineries, excluding armies.
miner_type=alloc(0x2000);refinery_type=alloc(0x2000);w(miner_type+0xa0,100);w(miner_type+0x800,28);b(miner_type+0xe0e,1);w(refinery_type+0xa0,100);vector(miner_type+0x3e8,[refinery_type])
vector(0xa83ce0,[t,miner_type])
miner=obj(0x7f5c70,miner_type,house,6000);refinery=obj(0x7e3ebc,refinery_type,house,6001)
u.mem_write(miner+0x9c,struct.pack('<iii',2560,2560,0));u.mem_write(refinery+0x9c,struct.pack('<iii',5120,5120,0))
u.mem_write(miner+0x33c,struct.pack('<4f',28,0,0,0));w(miner+0xac,10)
vector(0xa8ec78,[unit,building,enemyUnit,miner,refinery]);s.flags=32768;u.mem_write(SH,bytes(s));w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert {a.id for a in s.world.actors[:s.world.count]}=={6000,6001}
assert s.world.refineryCount==1
w(0xa802c8,0);w(0xa802d0,0)
s=external_order(7,destination=6001,tag=0x34,purpose=0,token=0,unit_id=6000,refinery_id=6001);assert s.planAccepted==1
record=bytes(u.mem_read(0xa802d4,111));assert record[12]==7 and record[14:19]==bytes(5) and record[19:24]==struct.pack('<IB',6001,0x34)
links=alloc();w(links,unit);w(refinery+0xe4,links);w(refinery+0xe8,1)
before=r(0xa802c8);s=external_order(7,destination=6001,tag=0x34,purpose=0,token=0,unit_id=6000,refinery_id=6001);assert s.planAccepted==0 and r(0xa802c8)==before
w(refinery+0xe8,0);vector(miner_type+0x3e8,[])
s=external_order(7,destination=6001,tag=0x34,purpose=0,token=0,unit_id=6000,refinery_id=6001);assert s.planAccepted==0
vector(miner_type+0x3e8,[refinery_type]);b(refinery+0x81,1)
s=external_order(7,destination=6001,tag=0x34,purpose=0,token=0,unit_id=6000,refinery_id=6001);assert s.planAccepted==0;b(refinery+0x81,0)
# The same-frame object index can outlive an object's original ID. Never use
# a recycled own pointer as if it were the older miner/refinery ID.
for pointer,old_id,new_id in ((miner,6000,6090),(refinery,6001,6091)):
    w(pointer+0x10,new_id);before=r(0xa802c8)
    s=external_order(7,destination=6001,tag=0x34,purpose=0,token=0,unit_id=6000,refinery_id=6001)
    assert s.planAccepted==0 and r(0xa802c8)==before
    w(pointer+0x10,old_id)
old_storage=bytes(u.mem_read(miner+0x33c,16));u.mem_write(miner+0x33c,struct.pack('<4f',.25,0,0,0))
s=external_order(7,destination=6001,tag=0x34,purpose=2,token=0,unit_id=6000,refinery_id=6001);assert s.planAccepted==1
u.mem_write(miner+0x33c,old_storage)
print('PASS: recycled miner/refinery IDs are rejected in cached same-frame lookup; fractional remaining ore may be released with native Enter')
print('PASS: native ore Enter has null attack target and a building destination; late occupied/incompatible/limbo refinery checks reject stale plans')
print('PASS: idle advanced mode publishes no repeated world; ore-only world excludes unrelated own/enemy armies')
# Manual input beats already-computed waiting / docking orders. The game's old
# Harvest snapshot at click time must not undo the pause.
w(miner+0xb4,0xffffffff)
def miner_snapshot():
    global s
    w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
    return next(a for a in s.world.actors[:s.world.count] if a.id==6000)
emitter_probe(2,source=miner);a=miner_snapshot();assert a.flags&67108864 and a.manualVersion>0
old_token=a.manualVersion
s=external_order(7,destination=6001,tag=0x34,purpose=0,token=old_token,unit_id=6000,refinery_id=6001);assert s.planAccepted==0
w(miner+0xac,2);a=miner_snapshot();assert a.flags&67108864
u.mem_write(miner+0x33c,bytes(16));w(miner+0xac,5);assert miner_snapshot().flags&67108864
u.mem_write(miner+0x33c,old_storage);assert miner_snapshot().flags&67108864
w(miner+0xac,10);a=miner_snapshot();assert not a.flags&67108864
# Explicit Harvest can resume while still full, before native execution.
emitter_probe(1,source=miner);a=miner_snapshot();assert a.flags&67108864
emitter_probe(10,source=miner);a=miner_snapshot();assert not a.flags&67108864
s=external_order(7,destination=6001,tag=0x34,purpose=0,token=a.manualVersion,unit_id=6000,refinery_id=6001);assert s.planAccepted==1
# Enter an unrelated building remains manual; own compatible refinery resumes.
emitter_probe(7,source=miner,dock=12);assert miner_snapshot().flags&67108864
emitter_probe(7,source=miner,dock=6001);a=miner_snapshot();assert not a.flags&67108864
s=external_order(7,destination=6001,tag=0x34,purpose=0,token=old_token,unit_id=6000,refinery_id=6001);assert s.planAccepted==0
# Native Stop-style local events pause even before the task changes in memory.
sp=STACK+0x1d000;u.mem_write(sp,struct.pack('<2I',STOP,6));u.reg_write(UC_X86_REG_ESP,sp);u.reg_write(UC_X86_REG_ECX,miner)
endpoint=u.hook_add(UC_HOOK_CODE,lambda uc,a,size,_:u.emu_stop(),begin=0x6ffe05,end=0x6ffe05)
try:u.emu_start(0x6ffe00,STOP,count=800000)
finally:u.hook_del(endpoint)
a=miner_snapshot();assert a.flags&67108864
w(miner+0xac,5);assert miner_snapshot().flags&67108864
w(miner+0xac,10);a=miner_snapshot();assert a.flags&67108864
for purpose in (0,2):
    s=external_order(7,destination=6001,tag=0x34,purpose=purpose,token=a.manualVersion,unit_id=6000,refinery_id=6001);assert s.planAccepted==0
emitter_probe(10,source=miner);assert not miner_snapshot().flags&67108864
print('PASS: compiled manual miner pause, old Harvest input lag, no empty/full resume, fresh Harvest / compatible-refinery hand-back and late stale-token rejection')
# Switch-off still observes a previously paused miner's hand-back. No automatic
# ore event may be emitted, and the last observer restores both code sites.
emitter_probe(2,source=miner);w(miner+0xac,2);a=miner_snapshot();assert a.flags&67108864
s.flags=0;s.plannerTracking=0;u.mem_write(SH,bytes(s));before=r(0xa802c8)
w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert s.data.oreManual==1 and bytes(u.mem_read(cs_site,1))==b'\xe9' and bytes(u.mem_read(0x6ffe00,1))==b'\xe9'
assert s.data.inputPatchMask==5 and r(0xa802c8)==before
emitter_probe(10,source=miner);w(miner+0xac,10);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert s.data.oreManual==0 and s.data.inputPatchMask==0 and r(0xa802c8)==before
assert bytes(u.mem_read(cs_site,5))==cs_original
s.flags=32768;u.mem_write(SH,bytes(s));w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
emitter_probe(1,source=miner);w(miner+0xac,1);a=miner_snapshot();assert a.flags&67108864
s.flags=0;u.mem_write(SH,bytes(s));w(miner+0x6c,0);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert s.data.oreManual==0 and s.data.inputPatchMask==0
w(miner+0x6c,100);w(miner+0xac,10);s.flags=32768;u.mem_write(SH,bytes(s));w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
a=next(a for a in s.world.actors[:s.world.count] if a.id==6000)
# Revalidate native unloading and a self-owned dock link even after EXE planning.
before=r(0xa802c8);b(miner+0x6d1,1)
for mission,destination,tag in ((7,6001,0x34),(2,30020,11)):
    s=external_order(mission,destination=destination,tag=tag,purpose=0,token=a.manualVersion,unit_id=6000,refinery_id=6001)
    assert s.planAccepted==0 and r(0xa802c8)==before
b(miner+0x6d1,0);w(links,miner);w(refinery+0xe8,1)
s=external_order(2,destination=30020,tag=11,purpose=0,token=a.manualVersion,unit_id=6000,refinery_id=6001)
assert s.planAccepted==0 and r(0xa802c8)==before
w(refinery+0xe8,0)
print('PASS: off-switch observes only paused miners, explicit Harvest clears hooks without ore orders, dead miners release metadata, and unloading / self-dock links reject stale waiting Moves')


# Smart unload's existing native missions are retained. Turning the automation
# off during its Sleep stage sends Guard, even when NativeOrders is now off.
carrier=cars[0];passenger=soldiers[0];w(carrier+0x114,1);w(passenger+0x11c,carrier);b(passenger+0x81,1);b(GI+0xec8,1)
vector(0xa8ec78,[carrier,passenger]);vector(0xa8ecb8,[carrier]);vector(0xa83de8,[passenger]);vector(0xa8eb40,[])
s.flags=1024|16384;u.mem_write(SH,bytes(s));w(0xa8ed84,r(0xa8ed84)+1);w(0xa802c8,0);w(0xa802d0,0)
is_deployed=r(0x7eb058+0x554);can_deploy=r(0x7eb058+0x314);deployed=False;deploy_ready=False
u.hook_add(UC_HOOK_CODE,lambda uc,a,size,_:ret(int(deployed),0),begin=is_deployed,end=is_deployed)
u.hook_add(UC_HOOK_CODE,lambda uc,a,size,_:ret(int(deploy_ready),0),begin=can_deploy,end=can_deploy)
s=command(17);assert s.count==1 and r(0xa802c8)==1
assert u.mem_read(0xa802d4+12,1)[0]==16
w(passenger+0x11c,0);b(passenger+0x81,0);w(passenger+0xac,5);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert r(0xa802c8)==2 and u.mem_read(0xa802d4+111+12,1)[0]==0
w(passenger+0xac,0);s.flags=0;u.mem_write(SH,bytes(s));w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert r(0xa802c8)==3 and u.mem_read(0xa802d4+222+12,1)[0]==5 and s.data.unloadPending==0
print('PASS: unchanged native Unload/Sleep missions; switch-off releases a settling passenger through native Guard instead of stranding it')
# Observe Sleep, then issue a normal attack before auto-deploy. A mode switch
# must not later overwrite that player action with a delayed Guard.
w(passenger+0x11c,carrier);b(passenger+0x81,1);s.flags=1024|16384;u.mem_write(SH,bytes(s));w(0xa8ed84,r(0xa8ed84)+1);s=command(17)
w(passenger+0x11c,0);b(passenger+0x81,0);w(passenger+0xac,5);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
w(passenger+0xac,0);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
prior=r(0xa802c8);w(passenger+0xac,1);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert r(0xa802c8)==prior and s.data.unloadPending==0
s.flags=0;u.mem_write(SH,bytes(s));w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);assert r(0xa802c8)==prior
print('PASS: manual takeover after observed Sleep ends unload tracking without a delayed Deploy/Guard override')


# Exercise actual follow-up events, not just the carrier's Unload receipt.
unload_weapon=alloc(0x200);unload_projectile=alloc();unload_wh=alloc()
w(unload_weapon+0xb4,1024);w(unload_weapon+0xa4,50);w(unload_weapon+0xa0,unload_projectile);w(unload_weapon+0xac,unload_wh);b(unload_projectile+0x2a5,1)
for j in range(11):u.mem_write(unload_wh+0xa0+j*8,struct.pack('<d',1.0))
w(GI+0x898,unload_weapon);b(GI+0xec8,0)
hostile=obj(0x7f5c70,t,enemy,9101);friendly=obj(0x7f5c70,t,ally,9102)
neutral_house=alloc(0x20000);neutral_country=alloc();w(neutral_house+0x30,3);w(neutral_house+0x34,neutral_country);b(neutral_country+0x1a6,1)
neutral_unit=obj(0x7f5c70,t,neutral_house,9103);protected_unit=obj(0x7f5c70,t,enemy,9104)
for q,x in ((hostile,800),(friendly,10),(neutral_unit,20),(protected_unit,30)):
    u.mem_write(q+0x9c,struct.pack('<iii',x,0,0))
w(protected_unit+0x18c,r(0xa8ed84));w(protected_unit+0x194,1000)
def begin_followup(enemies,buildings=()):
    global s
    s=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)));s.flags=1024|16384;u.mem_write(SH,bytes(s))
    w(carrier+0x114,1);w(passenger+0x11c,carrier);b(passenger+0x81,1);w(passenger+0xac,7);w(passenger+0x2b4,0);w(passenger+0x5a4,0)
    vector(0xa8ec78,[carrier,passenger]+list(enemies));vector(0xa8ecb8,[carrier]);vector(0xa83de8,[passenger]);vector(0xa8eb40,list(buildings))
    w(0xa802c8,0);w(0xa802d0,0);w(0xa8ed84,r(0xa8ed84)+1);s=command(17);assert s.count==1 and r(0xa802c8)==1
def disembark(mission=5):
    global s
    w(carrier+0x114,0);w(passenger+0x11c,0);b(passenger+0x81,0);w(passenger+0xac,mission);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
def last_mission():return bytes(u.mem_read(0xa802d4+(r(0xa802c8)-1)*111,111))
begin_followup([friendly,neutral_unit,protected_unit,hostile]);disembark()
record=last_mission();assert r(0xa802c8)==2 and record[12]==1 and record[14:19]==struct.pack('<IB',9101,0x34) and record[19:24]==bytes(5)
assert s.data.unloadPending==0 and r(passenger+0x2b4)==0
prior=r(0xa802c8);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);assert r(0xa802c8)==prior
begin_followup([friendly,neutral_unit]);disembark(0);assert last_mission()[12]==5 and s.data.unloadPending==0
print('PASS: ordinary unloaded passenger attacks nearest compatible hostile player; excludes allies/neutral/protected units; native Attack target serialization; no target-pointer writes or repeated follow-up; no-target sleeper released to Guard')
begin_followup([hostile,friendly]);w(carrier+0x114,0);w(passenger+0x11c,0);b(passenger+0x81,0);w(passenger+0xac,1);w(passenger+0x2b4,friendly)
w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert r(0xa802c8)==1 and s.data.unloadPending==0 and r(passenger+0x2b4)==friendly
w(passenger+0x2b4,0)
print('PASS: an already observed targeted passenger action is preserved instead of overwritten by the follow-up')


# Legal deployment does not wait for a separate Sleep event or its observation.
b(GI+0xec8,1);deploy_ready=True;deployed=False
begin_followup([]);disembark();assert r(0xa802c8)==2 and last_mission()[12]==16
w(passenger+0xac,16);deployed=True;w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);assert s.data.unloadPending==0 and r(0xa802c8)==2
# If Sleep was never observed but the passenger is quietly guarding, do not
# wait the entire timeout after native deployment becomes legal.
deployed=False;deploy_ready=False;begin_followup([]);disembark();assert last_mission()[12]==0
deploy_ready=True;w(0xa8ed84,r(0xa8ed84)+2);s=pulse(110);assert last_mission()[12]==16
deployed=True;w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);assert s.data.unloadPending==0
deployed=False;deploy_ready=False;b(GI+0xec8,0)
print('PASS: ready passenger deploys directly; pending Sleep/quiet Guard recovers as soon as deployment is legal; observed deployed state ends tracking without a toggling resend')

special_building=obj(0x7e3ebc,buildT,enemy,9201);u.mem_write(special_building+0x9c,struct.pack('<iii',800,0,0))
for role,action,mission in [('c4',5,1),('c4',16,17),('engineer',9,8),('spy',3,7)]:
    b(GI+0xec2,role=='c4');b(GI+0xec3,role=='engineer');b(GI+0xebe,role=='spy')
    action_overrides[(passenger,special_building)]=action
    begin_followup([special_building],[special_building]);disembark()
    record=last_mission();assert r(0xa802c8)==2 and record[12]==mission
    if mission==1:assert record[14:19]==struct.pack('<IB',9201,0x34) and record[19:24]==bytes(5)
    else:assert record[14:19]==bytes(5) and record[19:24]==struct.pack('<IB',9201,0x34)
    if role in ('engineer','spy'):
        assert s.data.unloadPending==1
        w(passenger+0xac,mission);w(passenger+0x5a4,special_building);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
    assert s.data.unloadPending==0
b(GI+0xec2,0);b(GI+0xec3,0);b(GI+0xebe,0)
print('PASS: C4 ordinary Attack differs from Sabotage; engineer Capture and spy Enter follow-up preserve native target/destination fields')
# All follow-up roles target hostile players only, including engineers. Native
# capture eligibility does not grant permission to target allied/neutral owners.
b(GI+0xec3,1)
neutral_building=obj(0x7e3ebc,buildT,neutral_house,9202);allied_building=obj(0x7e3ebc,buildT,ally,9203)
for q,x in ((neutral_building,100),(special_building,1000),(allied_building,1)):
    u.mem_write(q+0x9c,struct.pack('<iii',x,0,0));action_overrides[(passenger,q)]=9
begin_followup([neutral_building,special_building,allied_building],[allied_building,special_building,neutral_building]);disembark()
record=last_mission();assert record[12]==8 and record[19:24]==struct.pack('<IB',9201,0x34) and s.data.unloadPending==1
# Compare defined payload to the ORIGINAL ClickedMission + outgoing constructor,
# with the same destination arguments used by native Foot::ObjectClickedAction.
recorder_hook=u.hook_add(UC_HOOK_CODE,lambda uc,a,size,_:ret(0,0),begin=0x637aa0,end=0x637aa0)
voice_enabled=u.mem_read(0x822cf2,1);b(0x822cf2,0)
# Native Pack() obtains non-cell IDs through the AbstractClass COM interface.
# Fixtures used by the bridge's raw reader have no COM object until this test.
net_vt=alloc();net_id_stub=STUB+0xf100
u.mem_write(net_id_stub,bytes.fromhex('8b4424048b400cc20400'));w(net_vt+0x10,net_id_stub)
for pointer in (passenger,special_building):w(pointer+4,net_vt)
# Ctrl/Shift and replay queries are local UI environment, not mission routing.
key_hook=u.hook_add(UC_HOOK_CODE,lambda uc,a,size,_:ret(0,0),begin=0x731bf0,end=0x731bf0)
run(0x6ffbe0,(8,0,special_building,0),passenger)
u.hook_del(key_hook)
u.mem_write(0x822cf2,bytes(voice_enabled))
u.hook_del(recorder_hook)
def mission_fields(event):
    # Native construction leaves executed/union padding uninitialized and
    # carries an arbitrary ID when its NetID tag is null. Neither is a target.
    ids=[(event[o:o+4] if event[o+4] else bytes(4),event[o+4]) for o in (7,14,19,24)]
    return event[0],event[2:7],event[12],ids
assert mission_fields(last_mission())==mission_fields(record), 'Capture fields differ from native mouse click'
# Pending event is not spammed. If it vanished during ramp exit, idle specialists
# receive a bounded retry, and stop tracking once its destination is observed.
before=r(0xa802c8);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);assert r(0xa802c8)==before
w(0xa8ed84,r(0xa8ed84)+30);s=pulse(110);assert r(0xa802c8)==before+1 and last_mission()[12]==8
w(passenger+0xac,8);w(passenger+0x5a4,special_building);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);assert s.data.unloadPending==0
# A temporarily unavailable native action is retried instead of discarding the
# passenger on its first on-map frame.
action_overrides[(passenger,special_building)]=31
begin_followup([special_building],[special_building]);disembark();assert r(0xa802c8)==1 and s.data.unloadPending==1
action_overrides[(passenger,special_building)]=9;w(0xa8ed84,r(0xa8ed84)+6);s=pulse(110);assert r(0xa802c8)==2 and last_mission()[12]==8
w(passenger+0xac,8);w(passenger+0x5a4,special_building);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);assert s.data.unloadPending==0
# Exhausted specialist retries must not leave an unloaded sleeper stuck.
begin_followup([special_building],[special_building]);disembark(0)
for _ in range(3):w(0xa8ed84,r(0xa8ed84)+30);s=pulse(110)
assert s.data.unloadPending==0 and last_mission()[12]==5
assert sum(u.mem_read(0xa802d4+i*111+12,1)[0]==8 for i in range(r(0xa802c8)))==3
# Turning off during the acknowledgement delay is immediate, including a
# sleeper. A newly observed manual Move/Stop/AreaGuard also ends tracking now.
begin_followup([special_building],[special_building]);disembark(0);assert s.data.unloadPending==1
s.flags=0;u.mem_write(SH,bytes(s));w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert s.data.unloadPending==0 and last_mission()[12]==5
for mission in (2,11,13):
    begin_followup([special_building],[special_building]);disembark();assert s.data.unloadPending==1
    before=r(0xa802c8);w(passenger+0xac,mission);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
    assert s.data.unloadPending==0 and r(0xa802c8)==before
b(GI+0xec3,0)
print('PASS: engineer hostile-player-only capture, allied/neutral exclusion, original mouse-click payload equality, ramp-exit retry, immediate switch-off/manual takeover and observed destination acknowledgement')

# Cancel-current-task must release a tool-issued Sleep. A full outgoing queue
# retains that release until the next frame instead of dropping its record.
b(GI+0xec8,1);deploy_ready=False;deployed=False
begin_followup([]);disembark();assert last_mission()[12]==0
w(passenger+0xac,0);vector(0xa8ecb8,[passenger]);w(0xa802c8,112)
w(0xa8ed84,r(0xa8ed84)+1);s=command(18);assert s.count==1 and s.data.unloadPending==1
w(0xa802c8,0);w(0xa802d0,0);deploy_ready=True;w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert s.data.unloadPending==0 and r(0xa802c8)==1 and last_mission()[12]==5
for mission in (2,11,13):
    deploy_ready=False;begin_followup([]);disembark();assert last_mission()[12]==0
    before=r(0xa802c8);w(passenger+0xac,mission);deploy_ready=True;w(0xa8ed84,r(0xa8ed84)+3);s=pulse(110)
    assert s.data.unloadPending==0 and r(0xa802c8)==before
b(GI+0xec8,0);deploy_ready=False
print('PASS: cancel-current-task retains Sleep release across queue-full, then emits Guard only; manual Move/Stop/AreaGuard during deploy wait is preserved')


# Reboarding explicitly cancels delayed unloading/deployment without input hooks.
b(GI+0xec8,1);begin_followup([]);disembark();assert last_mission()[12]==0
vector(0xa8ecb8,[carrier,passenger]);w(passenger+0xac,5);s=command(15)
assert s.count==1
before=r(0xa802c8);deploy_ready=True;w(0xa8ed84,r(0xa8ed84)+3);s=pulse(110)
assert s.data.unloadPending==0
assert not any(u.mem_read(0xa802d4+i*111+12,1)[0]==16 for i in range(before,r(0xa802c8)))
s.flags=0;u.mem_write(SH,bytes(s));w(passenger+0x11c,carrier);b(passenger+0x81,1);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
w(passenger+0x11c,0);b(passenger+0x81,0);b(GI+0xec8,0);deploy_ready=False
print('PASS: explicit auto-board cancels pending unload/deploy follow-up without installing additional input hooks')

# Budget fairness: external tactical plans can consume at most 12 events per
# simulation frame; recurring repair retains its own four-event share.
b(unit+0x83,1);w(unit+0x114,0);w(unit+0x11c,0);b(unit+0x1c8,0)
new_repairs=[obj(0x7e3ebc,buildT,house,7000+j,50) for j in range(5)]
vector(0xa8ec78,[unit,enemyUnit]+new_repairs);vector(0xa8eb40,new_repairs);vector(0xa8ecb8,[unit])
s.flags=1024|8192|64;s.advancedKey=1095;s.repairMs=500;u.mem_write(SH,bytes(s));w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
held_keys.update((ord('G'),0x12));assert emitter_probe()==29;held_keys.clear()
w(0xa802c8,0);w(0xa802d0,0);clock+=5100;w(0xa8ed84,r(0xa8ed84)+1)
s=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)));s.planCount=24;s.planMatch=s.data.match;s.planTick=clock;s.planRequest+=1
# The click has changed only the local token. A one-frame pulse publishes it.
u.mem_write(SH,bytes(s));w(SH+Shared.planRequest.offset,s.planAck);s=pulse(110)
intent=s.world.intents[0]
# End the fixture's older repair batch before mixing fresh repairs and plans.
s.flags&=~64;u.mem_write(SH,bytes(s));w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);s.flags|=64
w(0xa802c8,0);w(0xa802d0,0)
fresh_repairs=[obj(0x7e3ebc,buildT,house,8000+j,50) for j in range(5)]
vector(0xa8ec78,[unit,enemyUnit]+fresh_repairs);vector(0xa8eb40,fresh_repairs)
# Move to a new simulation frame to reset all bounded event budgets.
clock+=5100;w(0xa8ed84,r(0xa8ed84)+1)
s.planCount=24;s.planMatch=s.data.match;s.planTick=clock;s.planRequest+=1
for j in range(24):s.plan[j]=Order(10,intent.token,13,0,1,0,1)
u.mem_write(SH,bytes(s));s=pulse(110)
assert s.planAccepted==12 and r(0xa802c8)==16,(s.planAccepted,r(0xa802c8),s.data.nativeHookStatus,s.data.advancedUnits,s.data.autoRepair)
assert all(u.mem_read(0xa802d4+i*111,1)[0]==21 for i in range(12,16))
# Additional batch wakes in the same simulation frame do not bypass the cap.
prior=r(0xa802c8);s.planTick=clock;s.planRequest+=1;u.mem_write(SH,bytes(s));s=pulse(110)
assert s.planAccepted==0 and r(0xa802c8)==prior
print('PASS: external plans retain 12-event cap across repeated wakes while automatic repair still submits four events in the same frame')

# Magnetron uses its own held key even with ordinary Advanced disabled. The
# initial ground click stays Move, avoiding vanilla CS auto-acquiring a building.
s=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)));s.flags=1024|262144;s.magnetronKey=ord('M')|(4<<8);u.mem_write(SH,bytes(s));b(weapon+0x15c,1);b(warhead+0x15b,1)
w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
held_keys.update((ord('M'),0x12));assert emitter_probe()==2;held_keys.clear();w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert s.world.intentCount==1 and s.world.intents[0].mode==1;intent=s.world.intents[0]
# No tactic may enter game decision functions or consume the game's randomizer.
def forbidden_random(uc,a,size,_):raise AssertionError('planner consumed native RNG')
rng_guard=u.hook_add(UC_HOOK_CODE,forbidden_random,begin=0x65c7e0,end=0x65c7e0)
w(0xa802c8,0);w(0xa802d0,0);w(unit+0x2ec,r(0xa8ed84));w(unit+0x2f4,10)
s=external_order(1,target=13,purpose=3);assert s.planAccepted==0
w(unit+0x2ec,r(0xa8ed84)-10);s=external_order(1,target=13,purpose=3);assert s.planAccepted==1
for offset,value in ((0x2b0,unit),(0x427,1),(0x428,unit),(0x6ad,1),(0x134,1),(0x8d,1)):
    if offset in (0x2b0,0x428):w(enemyUnit+offset,value)
    else:b(enemyUnit+offset,value)
    before=r(0xa802c8);s=external_order(1,target=13,purpose=3);assert s.planAccepted==0 and r(0xa802c8)==before
    if offset in (0x2b0,0x428):w(enemyUnit+offset,0)
    else:b(enemyUnit+offset,0)
b(t+0xd97,1);s=external_order(1,target=13,purpose=3);assert s.planAccepted==0;b(t+0xd97,0)
# Absolute Z alone must not exclude ordinary units standing on elevated ground.
w(unit+0xa4,1024);w(enemyUnit+0xa4,1024);s=external_order(1,target=13,purpose=3);assert s.planAccepted==1;w(unit+0xa4,0);w(enemyUnit+0xa4,0)
u.hook_del(rng_guard)
print('PASS: independent magnetic Move capture; original native Attack; actual rearm boundary; all lift/source/manipulation/falling/organic guards; elevated ground retained; no native RNG or tactical decision calls')
s.flags=1024|8192;u.mem_write(SH,bytes(s));b(weapon+0x15c,0);b(warhead+0x15b,0);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
held_keys.update((ord('G'),0x12));assert emitter_probe()==29;held_keys.clear();w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);intent=s.world.intents[0]

# Individual receipts: one stale target no longer prevents later valid orders.
w(0xa802c8,0);w(0xa802d0,0);w(0xa8ed84,r(0xa8ed84)+1)
s=Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)));s.planCount=3;s.planMatch=s.data.match;s.planTick=clock;s.planRequest+=1
s.plan[0]=Order(10,intent.token,800,0,1,0,1)
s.plan[1]=Order(10,intent.token,13,0,1,0,1)
s.plan[2]=Order(10,intent.token,13,0,1,0,1)
u.mem_write(SH,bytes(s));s=pulse(110)
assert s.planAccepted==2 and s.planAcceptedMask==6 and s.planRejectedMask==1 and r(0xa802c8)==2
# Failed GuardArea destination twice is handled externally; a valid GuardArea
# receipt sets a local stopped marker only. Moving/attacking clears that marker.
s=external_order(6);assert s.planAccepted==1
s=pulse(110);assert any(x.id==10 and x.advanced for x in s.data.label[:s.data.labels])
s=external_order(1,target=13);assert s.planAccepted==1
w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);assert not any(x.id==10 and x.advanced for x in s.data.label[:s.data.labels])
print('PASS: individual accepted/rejected masks keep later valid orders running; stopped-only marker follows native GuardArea receipt and clears on Attack')
# IFV active mode is checked against original read-only SelectWeapon/GetWeapon,
# then against the compiled DLL snapshot and late validation.
def make_weapon(range_value,air=False,damage=50):
    p=alloc(0x200);proj=alloc();wh=alloc();w(p+0xb4,range_value);w(p+0xa4,damage);w(p+0xa0,proj);w(p+0xac,wh);b(proj+0x2a4,air);b(proj+0x2a5,not air)
    for j in range(11):u.mem_write(wh+0xa0+j*8,struct.pack('<d',1.0))
    return p
ifv_weapon=make_weapon(1536);elite_weapon=make_weapon(2048);w(t+0x808,4);w(t+0x80c,6);w(unit+0x138,3);w(t+0x898+3*28,ifv_weapon)
run(0x6f3330,(enemyUnit,),unit);assert u.reg_read(UC_X86_REG_EAX)==3
run(0x70e140,(3,),unit);assert r(u.reg_read(UC_X86_REG_EAX))==ifv_weapon
w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);profile=next(a for a in s.world.actors[:s.world.count] if a.id==10)
assert profile.weapons[0].slot==3 and profile.weapons[0].range==1536 and profile.weapons[1].range==0
w(t+0xa94+3*28,elite_weapon);u.mem_write(unit+0x150,struct.pack('<f',2.0));run(0x70e140,(3,),unit);assert r(u.reg_read(UC_X86_REG_EAX))==elite_weapon
w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);assert next(a for a in s.world.actors[:s.world.count] if a.id==10).weapons[0].range==2048
u.mem_write(unit+0x150,struct.pack('<f',0.0));ground_stage=make_weapon(900);air_stage=make_weapon(1800,True)
w(t+0x898+28,air_stage);w(t+0x898+4*28,ground_stage);w(t+0x898+5*28,air_stage);b(t+0xcd5,1);w(unit+0x140,2);b(enemyUnit+0x14,7)
air_method=r(0x7f5c70+0x54);air_probe=False
air_hook=u.hook_add(UC_HOOK_CODE,lambda uc,a,size,_:ret(int(air_probe),0),begin=air_method,end=air_method)
run(0x6f3330,(enemyUnit,),unit);assert u.reg_read(UC_X86_REG_EAX)==4
air_probe=True;run(0x6f3330,(enemyUnit,),unit);assert u.reg_read(UC_X86_REG_EAX)==5;u.hook_del(air_hook)
w(t+0x68c,512);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);profile=next(a for a in s.world.actors[:s.world.count] if a.id==10)
assert [q.slot for q in profile.weapons]==[4,5] and [q.range for q in profile.weapons]==[900,1800] and profile.airRangeBonus==512
# Unit-deployed weapon overrides its undeployed/IFV slot.
b(unit+0x6e0,1);b(t+0x6ac,1);w(t+0x6a8,3);w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110)
assert next(a for a in s.world.actors[:s.world.count] if a.id==10).weapons[0].slot==3
# Infantry has a sequence-based deployed selector, unlike Unit.Deployed.
old_infantry_type=r(unit+0x6c0);w(unit,0x7eb058);w(unit+0x6c0,t);w(unit+0x6c4,27)
run(0x5218e0,(enemyUnit,),unit);assert u.reg_read(UC_X86_REG_EAX)==3
w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);assert next(a for a in s.world.actors[:s.world.count] if a.id==10).weapons[0].slot==3
w(unit+0x6c4,2);run(0x5218e0,(enemyUnit,),unit);assert u.reg_read(UC_X86_REG_EAX)==0
w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);assert next(a for a in s.world.actors[:s.world.count] if a.id==10).weapons[0].slot==0
w(unit,0x7f5c70);w(unit+0x6c0,old_infantry_type);w(unit+0x6c4,t)
b(unit+0x6e0,0);b(t+0x6ac,0);b(t+0xcd5,0);w(t+0x808,0);w(t+0x898+28,0);w(t+0x68c,0);w(unit+0x138,0)
# Those reference calls are tests only: normal snapshots/plans must not call
# native SelectWeapon, CanFire, IsCloseEnough, a pathfinder, or native RNG.
for address in (0x6f3330,0x746cd0,0x5218e0,0x6f7220,0x65c7e0):
    u.hook_add(UC_HOOK_CODE,lambda uc,a,size,_:(_ for _ in ()).throw(AssertionError('native decision invoked '+hex(a))),begin=address,end=address)
# Late special-state guards use fresh fields even if read-only type metadata is
# still cached in the published snapshot.
b(warhead+0x155,1);b(t+0xd35,1);s=external_order(1,target=13);assert s.planAccepted==0;b(t+0xd35,0);b(warhead+0x155,0)
b(warhead+0x178,1);b(t+0xd36,1);s=external_order(1,target=13);assert s.planAccepted==0;b(t+0xd36,0);b(warhead+0x178,0)
b(warhead+0x159,1);w(enemyUnit+0x694,unit);s=external_order(1,target=13);assert s.planAccepted==0;w(enemyUnit+0x694,0);b(warhead+0x159,0)
b(warhead+0x15a,1);b(t+0xd3a,0);s=external_order(1,target=13);assert s.planAccepted==0;b(t+0xd3a,1);b(warhead+0x15a,0)
w(weapon+0xa4,-1);s=external_order(1,target=13);assert s.planAccepted==0;w(weapon+0xa4,777)
b(t+0x233,1);s=external_order(1,target=13);assert s.planAccepted==0;b(t+0x233,0)
b(t+0x231,0);s=external_order(1,target=13);assert s.planAccepted==0;b(t+0x231,1)
w(0xa8ed84,r(0xa8ed84)+1);s=pulse(110);s=external_order(1,target=13);assert s.planAccepted==1
print('PASS: IFV ordinary/elite, Gattling ground/AA pair and deployed slots match original selectors; AA range bonus; fresh special-state/healing/illegal target rejection; no native tactical/RNG callbacks')

# The local sidebar hook also preserves an unrelated patch on conflict.
original_retention=bytes(u.mem_read(0x6aa7b6,6));u.mem_write(0x6aa7b6,b'\x90'*6);u.ctl_remove_cache(0x6aa7b6,0x6aa7bc)
s=command(10,1);assert s.result==1 and s.data.techOpen==1 and bytes(u.mem_read(0x6aa7b6,6))==b'\x90'*6
s=command(10,0);assert bytes(u.mem_read(0x6aa7b6,6))==b'\x90'*6
u.mem_write(0x6aa7b6,original_retention);u.ctl_remove_cache(0x6aa7b6,0x6aa7bc)
print('PASS: external technology panel never modifies a foreign sidebar patch')

# A foreign patch at our emission entry is preserved and tactical submission
# stops; do not overwrite or blindly chain another mod's modified code.
foreign=bytes.fromhex('9090909090');u.mem_write(cs_site,foreign);u.ctl_remove_cache(cs_site,cs_site+5)
s=pulse(110);assert C.c_int32(s.data.csHookStatus).value==-1
assert bytes(u.mem_read(cs_site,5))==foreign
s=external_order(1,target=13,token=intent.token);assert s.planAccepted==0
print('PASS: foreign input patch preserved; CS/advanced automation fails closed instead of submitting through a conflicted interface')

print('ALL X86 ABI CHECKS PASSED (not a live multiplayer or Windows rendering test)')

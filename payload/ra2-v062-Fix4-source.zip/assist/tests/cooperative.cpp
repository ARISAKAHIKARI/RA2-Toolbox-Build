#include "../source/cooperative_plan.h"
#include "../source/additional_settings.h"
#include <cassert>
#include <map>
#include <iostream>
using namespace assist::cooperative;
Input make(int n,int targets,int mode=AirFirst){Input w;w.mode=mode;w.clicked=100;for(int i=0;i<n;++i)w.units.push_back({{uint32_t(i+1),7},1,0,0,1});for(int i=0;i<targets;++i)w.targets.push_back({uint32_t(100+i),2,i*256,0,3,0,{1,2,0}});w.compatible.assign(n*targets,1);return w;}
std::map<uint32_t,int> counts(const std::vector<Assignment>&a){std::map<uint32_t,int> out;for(auto&o:a)++out[o.target];return out;}
int main(){auto w=make(7,3);auto a=allocate(w);auto n=counts(a);assert(a.size()==7&&n[100]==3&&n[101]==2&&n[102]==2);w.mode=AirSecond;w.units.resize(6);w.compatible.resize(18);n=counts(allocate(w));assert(n[100]==2&&n[101]==2&&n[102]==2);
 w=make(10,3);w.targets[0].quota={2,3,2};w.targets[1].quota={1,2,1};w.targets[2].quota={0,0,0};n=counts(allocate(w));assert(n[100]==2&&n[101]==1&&n[102]==7);for(auto&t:w.targets)t.quota.maximum=1;assert(allocate(w).size()==3);
 w=make(2,2);w.compatible={1,1,1,0};n=counts(allocate(w));assert(n[100]==1&&n[101]==1);
 w=make(3,2,Enter);w.units[0].slots=3;w.units[1].slots=w.units[2].slots=2;w.targets[0].free=4;w.targets[1].free=3;a=allocate(w);assert(a.size()==3);std::map<uint32_t,int> slots;for(auto&o:a)slots[o.target]+=w.units[o.id-1].slots;assert(slots[100]<=4&&slots[101]<=3);
 w.compatible.pop_back();assert(allocate(w).empty());Request r{};r.serial=r.match=1;r.mode=Enter;r.count=MaxSources+1;assert(!valid(r));r.count=1;r.viewWidth=1920;r.viewHeight=1080;assert(valid(r));
 assist::AdditionalSettings defaults;assert(defaults.enterKey==18&&defaults.airKey1==17&&!defaults.airKey2&&defaults.defaults.first==1&&defaults.defaults.second==2&&!defaults.defaults.maximum);
 std::cout<<"PASS: both aircraft priorities, per-target caps/unlimited, AA/AG scarcity, garrison size best-fit, malformed request/viewport guards and defaults\n";
}

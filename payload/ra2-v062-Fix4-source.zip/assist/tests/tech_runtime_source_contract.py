from pathlib import Path
r=Path(__file__).resolve().parents[1]/'source'
s=(r/'main.cpp').read_text(encoding='utf-8')
assert 'techDirectProduce=value(L"Tech",L"DirectProduce",0)!=0;' in s
assert 'if(!techDirectProduce)notify(' in s
assert 'externalReader.lastOpenError' in s
assert 'externalReader.lastReadError' in s
assert 'externalReader.lastRegionState' in s
reader=(r/'../../external_reader/source/process_reader.h').read_text(encoding='utf-8')
assert 'VirtualQueryEx(' in reader
assert 'PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ' in reader
assert 'WriteProcessMemory(' not in reader
print('PASS: runtime DirectProduce setting, read-only LBW error diagnostics')

"""Original game + compiled DLL ABI checks. Not live Windows/LBW/multiplayer."""
from pathlib import Path
exec(compile(Path(__file__).with_name('engine_abi.py').read_text(),str(Path(__file__).with_name('engine_abi.py')),'exec'))
u.hook_del(ui_query_guards[0x73fd50]);w(SH+Shared.stop.offset,1);hook()
for site,n in ((0x646e90,5),(0x731bf0,6),(0x6ffe00,5)):
 u.mem_write(site,game.get_data(site-0x400000,n));u.ctl_remove_cache(site,site+n)
u.mem_map(0x23000000,0x1000000);cursor=0x23000000
it=alloc(0x2000);bt=alloc(0x2000);pt=alloc(0x2000);tt=alloc(0x2000);dt=alloc(0x2000)
for typ in (it,bt,pt,tt,dt):
 w(typ+0xa0,100);w(typ+0x634,1);w(typ+0x6cc,1);b(typ+0x231,1);b(typ+0xd3a,1);b(typ+0xd38,1);w(typ+0x684,0xffffffff);u.mem_write(typ+0x380,struct.pack('<d',1));u.mem_write(typ+0x388,struct.pack('<d',3))
b(it+0xeb4,1);b(bt+0x157b,1);w(bt+0x1580,2);u.mem_write(dt+0x24,b'DISK\0')
for owner,index in ((house,0),(enemy,1)):
 country=alloc();w(owner+0x30,index);w(owner+0x34,country)
 for off in (0x1f5,0x1f6,0x1f8):b(owner+off,0)
w(house+0x5788,1)
for off in (0x53bc,0x53b4,0x53b8,0x53ac):w(house+off,0)
vector(house+0x254,[]);vector(0xa80228,[house,enemy]);w(0xa83d4c,house);b(0xa8e9a0,1);w(0xa8ed84,500)
ps=[obj(0x7eb058,it,house,10001+i,selected=True) for i in range(3)];bs=[obj(0x7e3ebc,bt,house,10101+i) for i in range(2)]
plane=obj(0x7e22a4,pt,house,10201,selected=True);foe=obj(0x7f5c70,tt,enemy,10301);disk=obj(0x7f5c70,dt,house,10401,selected=True);eb=obj(0x7e3ebc,bt,enemy,10501)
world=ps+bs+[plane,foe,disk,eb]
for i,p in enumerate(world):u.mem_write(p+0x9c,struct.pack('<iii',10240+i*64,10240,0))
vector(0xa8ec78,world);vector(0xa8ecb8,ps);vector(0xa83de8,ps);vector(0xa8eb40,bs+[eb]);vector(0xa83ce0,[pt]);vector(0xa8b218,[tt,dt]);vector(0xa8e348,[it]);vector(0xa83c68,[bt])
weapon2=make_weapon(1024);w(pt+0x898,weapon2);w(dt+0x898,weapon2)
s=Shared();s.magic=0x41533130;s.version=30;s.pid=123;s.heartbeat=clock;s.foreground=1;s.scanMs=8;s.flags=1048576;s.enterKey=18;s.airKey1=17;s.loadRadius=30
u.mem_write(SH,bytes(s));s=hook();assert s.clickHookStatus==1
for a,n in ((0x4d74e0,6),(0x692610,8),(0x4ab9b0,6)):u.ctl_remove_cache(a,a+n)
mouse_actions=[]
def continuation(uc,a,size,_):
 if a==0x4d74e6:u.reg_write(UC_X86_REG_ESP,u.reg_read(UC_X86_REG_ESP)+0xf8);ret(0,3)
 elif a==0x692618:u.reg_write(UC_X86_REG_ESP,u.reg_read(UC_X86_REG_ESP)+0x10);ret(42,3)
 else:
  sp=u.reg_read(UC_X86_REG_ESP)+0x88;mouse_actions.append(r(sp+16));u.reg_write(UC_X86_REG_ESP,sp);ret(0,5)
for a in (0x4d74e6,0x692618,0x4ab9b6):u.hook_add(UC_HOOK_CODE,continuation,begin=a,end=a)
def shared():return Shared.from_buffer_copy(u.mem_read(SH,C.sizeof(Shared)))
def save(s):u.mem_write(SH,bytes(s))
def frame():w(0xa8ed84,r(0xa8ed84)+1);return pulse(110)
def click(p,t,action=3):run(0x4d74e0,(action,t,1),p);return shared()
def submit(rows):
 s=shared();s.cooperativeSerial=s.cooperativeRequest.serial;s.cooperativeTick=clock;s.cooperativeMode=s.cooperativeRequest.mode;s.cooperativeCount=len(rows)
 for i,(p,t,token) in enumerate(rows):s.cooperativeOrders[i]=CooperativeAssignment(r(p+0x10),token,r(t+0x10),r(t+(0x520 if r(t)==0x7e3ebc else 0x6c4)))
 s.cooperativePlan+=1;save(s);return frame()
held_keys.add(18);w(bs[0]+0x694,2);run(0x692610,(0,bs[0],0),0x87f7e8);assert u.reg_read(UC_X86_REG_EAX)==3
s=click(ps[0],bs[0]);serial=s.cooperativeRequest.serial;s=click(ps[1],bs[0]);assert s.cooperativeRequest.serial==serial and s.cooperativeRequest.count==2 and s.cooperativeRequest.viewWidth>0
sources=list(s.cooperativeRequest.sources[:2]);w(0xa802c8,0);w(0xa802d0,0);s=submit([(ps[i],bs[1],sources[i].token) for i in range(2)]);assert s.cooperativeAccepted==2
for i in range(2):ev=bytes(u.mem_read(0xa802d4+i*111,111));assert ev[12]==7 and ev[14:19]==bytes(5) and ev[19:24]==struct.pack('<IB',10102,0x34)
s=click(ps[2],bs[0]);s=submit([(ps[2],bs[1],s.cooperativeRequest.sources[0].token)]);assert s.cooperativeRejected==1
vector(0xa8ecb8,ps*172);s=click(ps[0],bs[0]);assert s.cooperativeRequest.count==513;vector(0xa8ecb8,ps);assert click(ps[0],bs[0]).cooperativeRequest.count==1
print('PASS: compiled Alt full-building capture, immutable group, native Enter, in-flight capacity, oversize native fallback and same-frame recovery')
held_keys.clear();held_keys.add(17);s=shared();s.flags=2097152;save(s);frame();vector(0xa8ecb8,[plane]);before=shared().cooperativeRequest.serial
for t in (ps[0],0):assert click(plane,t,5).cooperativeRequest.serial==before
w(house+0x5788,3);assert click(plane,foe,5).cooperativeRequest.serial==before;w(house+0x5788,1)
s=click(plane,foe,5);u.mem_write(foe+0x9c,struct.pack('<iii',40000,40000,0));w(0xa802c8,0);w(0xa802d0,0);s=submit([(plane,foe,s.cooperativeRequest.sources[0].token)]);assert s.cooperativeAccepted==1
print('PASS: aircraft own/allied/ground passthrough and original Attack beyond current weapon range')
cells2=alloc(512*512*4);w(0x87f7e8+316,cells2);w(0x87f7e8+320,512*512);cell2=alloc();x=r(eb+0x9c)//256;y=r(eb+0xa0)//256;w(cells2+(y*512+x)*4,cell2)
s=shared();s.flags=4194304|2097152;save(s);frame();w(0xa802c8,0);w(0xa802d0,0);click(disk,eb,5);ev=last_mission();assert ev[12]==1 and ev[14:19]==struct.pack('<IB',y*1000+x,11)
print('PASS: Ctrl disk primary route emits an original ground-cell Attack without weapon/rule changes')
w(0x87f7e8+0x11b1,1);w(bs[0]+0x1d0,disk)
def sell(t,flags):
 s=shared();s.flags=flags;save(s);frame();u.ctl_remove_cache(0x4ab9b0,0x4ab9b6);w(0xa802c8,0);w(0xa802d0,0);run(0x4ab9b0,(0,0,t,14,0),0x87f7e8);return r(0xa802c8)
assert sell(bs[0],8388608)==1 and mouse_actions[-1]==14
vx=r(foe+0x9c)//256;vy=r(foe+0xa0)//256;vc=alloc();w(cells2+(vy*512+vx)*4,vc);assert sell(foe,16777216)==0;w(vc+0xe4,bs[1]);assert sell(foe,16777216)==1 and last_mission()[2]==1 and last_mission()[7:12]==struct.pack('<IB',10301,0x34)
assert sell(eb,33554432)==1;w(eb+0x1d0,disk);assert sell(eb,33554432)==0;assert sell(eb,33554432|8388608)==1
held_keys.clear();assert sell(eb,33554432|8388608)==0;held_keys.add(17)
print('PASS: independent Ctrl-sell switches, overlapping gates, native owner/target serialization, bare-ground rejection and original mouse cleanup')
# Receiver fixture: object resolution/replay and teardown are environment stubs;
# ownership and original CellClass/GetBuilding/native sale dispatch execute.
refunds=[];steps=[];queued=[]
def sale_fixture(uc,a,size,_):
 sp=u.reg_read(UC_X86_REG_ESP);arg=lambda i:r(sp+4+i*4);self=u.reg_read(UC_X86_REG_ECX)
 if a==0x6e6f20:ret(next((p for p in world if r(p+0x10)==r(self)),0),0)
 elif a in (0x6386e0,0x50b6f0):ret(0,0)
 elif a==0x70ada0:ret(500,0)
 elif a==0x4f9950:refunds.append((self,arg(0)));ret(0,1)
 elif a in (0x4d5660,0x7440b0,0x4de5d0):steps.append((self,a));ret(0,0)
 elif a==0x5b35e0:queued.append((self,arg(0)));ret(1,2)
 else:ret(1,0)
hooks=[u.hook_add(UC_HOOK_CODE,sale_fixture,begin=a,end=a) for a in (0x6e6f20,0x6386e0,0x50b6f0,0x70ada0,0x4f9950,0x4d5660,0x7440b0,0x4de5d0,0x5b35e0,0x5b3570)]
def receive(t,owner):e=alloc(128);run(0x4c65e0,(owner,0x16,r(t+0x10),0x34),e);run(0x4c6cb0,(),e)
w(vc+0xe4,0);receive(foe,1);assert not refunds;w(vc+0xe4,bs[1]);receive(foe,0);assert not refunds;receive(foe,1);assert refunds==[(enemy,500)] and len(steps)==3 and all(p==foe for p,a in steps)
b(eb+0x6e9,1);receive(eb,1);assert queued==[(eb,19)]
for h in hooks:u.hook_del(h)
print('PASS: original Sell receiver enforces cell/owner checks, refunds vehicle owner and sells the vehicle rather than overlapping building; enemy building uses native Selling')
print('ALL NEW FEATURE X86 ABI CHECKS PASSED (not live multiplayer, LBW or Windows rendering)')
# Normal weapon identity separates gunner variants, including elite objects.
s=shared();s.flags=0;save(s);frame();w(0x87f7e8+0x11b1,0);held_keys.clear();vt=alloc(0x2000);b(vt+0x805,1);w(vt+0x80c,2);w(vt+0xa0,100);w(vt+0x898,weapon2);w(vt+0x898+28,unload_weapon)
variants=[obj(0x7f5c70,vt,house,10601+i,selected=i==0) for i in range(3)]
for p in variants:u.mem_write(p+0x9c,struct.pack('<iii',2000,2000,0))
w(variants[0]+0x138,0);w(variants[1]+0x138,0);w(variants[2]+0x138,1);u.mem_write(variants[1]+0x150,struct.pack('<f',2));w(vt+0xa94,unload_weapon)
vector(0xa8ec78,variants);vector(0xa8ecb8,[variants[0]]);calls.clear();s=command(19);assert {p for a,p,args in calls if a==0x6fbfa0}==set(variants[:2])
print('PASS: weapon variant selection distinguishes current ordinary weapons, retaining elite units with the same ordinary weapon')

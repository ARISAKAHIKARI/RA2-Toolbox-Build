#include "../../external_reader/source/cooperative_reader.h"
#include <cassert>
#include <vector>
#include <cstring>
#include <iostream>
struct Memory{std::vector<unsigned char> bytes=std::vector<unsigned char>(0xC00000);uint32_t reads=0;template<class T>void put(uint32_t p,T x){memcpy(bytes.data()+p,&x,sizeof x);}void vec(uint32_t p,uint32_t a,std::initializer_list<uint32_t> items){put(p+4,a);put<int>(p+8,items.size());put<int>(p+16,items.size());for(auto x:items){put(a,x);a+=4;}}bool read(uint32_t a,void*out,size_t n){++reads;if(a<0x10000||uint64_t(a)+n>bytes.size())return false;memcpy(out,bytes.data()+a,n);return true;}};
struct Read{Memory*m;bool operator()(uint32_t a,void*out,size_t n)const{return m->read(a,out,n);}};
int main(){using namespace assist;Memory m;Read read{&m};constexpr uint32_t house=0x400000,tactical=0x450000,type=0x300000,unit=0x200000,temporal=0x500000;
 m.put<uint8_t>(0xA8E9A0,1);m.put<int>(0xA8ED84,100);m.put(0xA83D4C,house);m.put(0x887324,tactical);m.put<int>(0xA8EB84,1920);m.put<int>(0xA8EB88,1080);m.put<int>(tactical+0xB0,-320);m.put<int>(tactical+0xB4,800);m.put<double>(0xB0CD48,.0866025403784);m.vec(0xA80228,0x110000,{house});m.vec(0xA8EC78,0x110100,{unit});m.vec(0xA8B218,0x110200,{type});m.vec(0xA8ECB8,0x110300,{unit});
 m.put<int>(type+0x634,1);m.put<uint32_t>(type+0x6CC,1);m.put<int>(type+0x5E0,5);m.put(unit,uint32_t(0x7F5C70));m.put<uint32_t>(unit+0x10,1);m.put(unit+0x6C4,type);m.put(unit+0x21C,house);m.put<int>(unit+0x6C,100);for(int off:{0x74,0x90,0x83})m.put<uint8_t>(unit+off,1);m.put<int>(unit+0x9C,10240);m.put<int>(unit+0xA0,10240);m.put<int>(unit+0x18C,50);m.put<int>(unit+0x194,150);m.put<uint8_t>(house+22265,80);m.put<uint8_t>(house+22266,180);m.put<uint8_t>(house+22267,240);
 m.put(unit+0x278,temporal);m.put(temporal+0x28,unit);m.put<int>(temporal+0x48,1000);m.put<int>(temporal+0x4C,20);m.put(temporal+0x44,temporal);
 external::TacticalSampler<Read> sampler(read);auto s=sampler.sample(100,Capacity|Iron|Frozen);assert(s.status==1&&s.typeCount==1&&s.labels==1&&s.label[0].ownerColor==0xFF50B4F0&&s.label[0].ironFrames==100&&s.label[0].frozenFrames==50);
 m.reads=0;sampler.sample(101,Capacity|Iron|Frozen);auto cached=m.reads;m.reads=0;m.put<int>(0xA8ED84,101);sampler.sample(102,Capacity|Iron|Frozen);assert(m.reads>cached);
 m.put<int>(tactical+0xB0,-300);sampler.refreshCamera(108);assert(sampler.sample(133,Capacity|Iron|Frozen).label[0].x==300);
 int x,y;external::Projection projection;projection.width=1920;projection.height=1080;assert(!external::project(projection,INT32_MIN,0,0,x,y));
 std::cout<<"PASS: actual-layout external snapshot, owner colors, iron/frozen timers with cycle guard, unchanged-frame cache, camera shift and invalid coordinates\n";
}

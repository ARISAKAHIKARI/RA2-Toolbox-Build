// Linux host fake Win32 ABI smoke test: validates our API access mask and
// fallback control flow. This does not replace a Windows x86 compile/test.
#include "../external_reader/source/process_reader.h"
#include "../external_reader/source/process_discovery.h"
#include <cassert>
#include <cstring>
static bool failSnapshot=false, queryDenied=false, omitWindows=false;
static DWORD maskRead=0,maskQuery=0;
static int regionCalls=0;
extern "C" {
HANDLE OpenProcess(DWORD mask,BOOL,DWORD){
 if(mask&PROCESS_VM_READ){maskRead=mask;return reinterpret_cast<HANDLE>(0x20);}
 if(mask&PROCESS_QUERY_INFORMATION){maskQuery=mask;return queryDenied?nullptr:reinterpret_cast<HANDLE>(0x30);}
 return reinterpret_cast<HANDLE>(0x40);
}
BOOL CloseHandle(HANDLE){return TRUE;}
DWORD GetLastError(){return ERROR_ACCESS_DENIED;}
BOOL GetExitCodeProcess(HANDLE,DWORD*code){*code=STILL_ACTIVE;return TRUE;}
BOOL ReadProcessMemory(HANDLE,LPCVOID a,void*out,SIZE_T n,SIZE_T*got){
 auto addr=reinterpret_cast<uintptr_t>(a);
 *got=0;
 if(n==4096||addr==0x12000)return FALSE;
 std::memset(out,0xCD,n);*got=n;return TRUE;
}
SIZE_T VirtualQueryEx(HANDLE,LPCVOID,MEMORY_BASIC_INFORMATION*info,SIZE_T n){
 ++regionCalls;info->State=0x1000;info->Protect=4;return n;
}
DWORD GetCurrentProcessId(){return 1;}
BOOL EnumWindows(BOOL(*fn)(HWND,LPARAM),LPARAM p){if(!omitWindows)fn(reinterpret_cast<HWND>(0x100),p);return TRUE;}
BOOL GetClientRect(HWND,RECT*r){*r={0,0,640,480};return TRUE;}
DWORD GetWindowThreadProcessId(HWND,DWORD*pid){*pid=42;return 12;}
BOOL IsWindowVisible(HWND){return FALSE;}
HWND GetWindow(HWND,unsigned){return nullptr;}
HANDLE CreateToolhelp32Snapshot(DWORD,DWORD){return failSnapshot?INVALID_HANDLE_VALUE:reinterpret_cast<HANDLE>(0x50);}
BOOL Process32FirstW(HANDLE,PROCESSENTRY32W*p){p->th32ProcessID=42;std::wcscpy(p->szExeFile,L"gamemd-spawn.exe");return TRUE;}
BOOL Process32NextW(HANDLE,PROCESSENTRY32W*){return FALSE;}
BOOL QueryFullProcessImageNameW(HANDLE,DWORD,wchar_t*path,DWORD*n){
 constexpr wchar_t filename[]=L"C:\\YR\\gamemd-spawn.exe";
 std::wcscpy(path,filename);*n=sizeof(filename)/sizeof(wchar_t)-1;return TRUE;
}
}
int main(){
 using namespace external;
 auto normal=discovery::scan();assert(normal.best.pid==42&&normal.windowCount==1);
 assert(normal.best.window&&normal.processCount==1);
 omitWindows=true;
 auto passive=discovery::scan();assert(passive.best.pid==42&&!passive.best.window&&passive.uniqueWindowless);
 omitWindows=false;
 failSnapshot=true;
 auto fallback=discovery::scan();assert(fallback.best.pid==42&&fallback.processCount==1);
 ProcessReader reader;assert(reader.open(42));
 assert(maskRead==(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_VM_READ));
 assert(maskQuery==0); // No extra rights requested before reading
 reader.begin();unsigned value=0;
 assert(reader.read(0x11000,&value,4));assert(maskQuery==0);
 assert(!reader.read(0x12000,&value,4));
 assert(maskQuery==PROCESS_QUERY_INFORMATION&&regionCalls==1);
 assert(reader.lastRegionQueried);
 reader.close();queryDenied=true;maskQuery=0;regionCalls=0;
 assert(reader.open(42));reader.begin();
 assert(!reader.read(0x12000,&value,4));
 assert(!reader.lastRegionQueried&&reader.lastRegionQueryError==ERROR_ACCESS_DENIED);
 assert(reader.read(0x11000,&value,4)); // Query failure cannot block actual read.
}

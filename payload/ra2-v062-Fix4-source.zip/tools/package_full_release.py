#!/usr/bin/env python3
"""Package verified RA2 Toolbox 0.6.2 Win32 files + FULL resources.
Never packages legacy binaries or substitutes missing build artifacts.
"""
from pathlib import Path
import hashlib
import json
import sys
import zipfile
sys.path.insert(0, str(Path(__file__).resolve().parent))
from verify_windows_outputs import verify

BASE = Path(__file__).resolve().parent.parent
EXE_DLL = ('RA2Toolbox.exe', 'AssistBridge.dll', 'UnitMonitorBridge.dll', 'CursorHideBridge.dll')
REQUIRED_FOLDERS = ('assets', 'profiles', 'runtime', 'engine', 'licenses', 'third-party')
SOURCE_FOLDERS = ('assist', 'cursor', 'unit_monitor', 'suite', 'external_reader', 'tests', 'tools', 'docs')
OPTIONAL_TOP = ('Assist.ini', 'Assist.example.ini', 'Assist-HighLevel-Experimental.ini',
                'Toolbox.ini', 'Start-Message.cmd', 'Start-Frame.cmd',
                'TacticalAssist-README.txt', 'THIRD-PARTY-NOTICES.txt',
                'LICENSE', 'WINDOWS_BUILD_ARTIFACTS.json',
                'BUILD-VERIFIED-v062.tag', 'BUILD_STATUS_AND_USAGE.txt', 'README.txt',
                'README_FIRST_完整包说明.txt', 'README_v0.6.2_读取算法入口分层与原版构造器.md',
                'BUILD_SOURCE_MANIFEST.json', 'FULL_RESOURCES_MANIFEST.json',
                'BUILD-AND-PACK-FULL.cmd', 'BUILD-0.6.2-ON-WINDOWS.cmd', 'BUILD_WINDOWS.cmd',
                'BUILD_ZIG.cmd', 'build-zig.sh', 'validate-logic.py',
                'CHECK_REPORT_v0.6.2_BuildFix4.md', 'RELEASE_VALIDATION.json',
                'validation-v062-full.log', 'abi-v062-full.log', 'build-v062-full.log',
                'CURRENT_SOURCE_SHA256.json')


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for piece in iter(lambda: f.read(2 * 1024 * 1024), b''):
            h.update(piece)
    return h.hexdigest()


def run():
    _, errors = verify(BASE)
    if errors:
        raise RuntimeError('Current binaries failed validation: ' + '; '.join(errors))
    manifest = BASE / 'WINDOWS_BUILD_ARTIFACTS.json'
    if not manifest.is_file() or not (BASE / 'BUILD-VERIFIED-v062.tag').is_file():
        raise RuntimeError('No verified PE32 build metadata. Run BUILD-0.6.2-ON-WINDOWS.cmd first.')
    meta = json.loads(manifest.read_text(encoding='utf-8'))
    recorded = meta.get('verified', {})
    missing = [name for name in EXE_DLL if not (BASE/name).is_file()]
    if missing:
        raise RuntimeError('Missing freshly built Win32 outputs: ' + ', '.join(missing))
    for name in EXE_DLL:
        actual = sha(BASE / name)
        if recorded.get(name, {}).get('sha256') != actual:
            raise RuntimeError('PE32 hash mismatch: ' + name)
        if recorded[name].get('machine') != 'PE32 x86':
            raise RuntimeError('Incorrect target: ' + name)
    for directory in REQUIRED_FOLDERS:
        if not (BASE / directory).is_dir():
            raise RuntimeError('Missing FULL resource directory: ' + directory)
    resources = json.loads((BASE / 'FULL_RESOURCES_MANIFEST.json').read_text('utf-8'))
    for name, record in resources['files'].items():
        p = BASE / name
        if not p.is_file() or p.stat().st_size != record['bytes'] or sha(p) != record['sha256']:
            raise RuntimeError('Missing or changed Full resource: ' + name)
    files = [BASE / x for x in EXE_DLL]
    files.extend(BASE / x for x in OPTIONAL_TOP if (BASE / x).is_file())
    for directory in REQUIRED_FOLDERS + SOURCE_FOLDERS:
        for p in (BASE / directory).rglob('*'):
            if not p.is_file() or '__pycache__' in p.parts:
                continue
            if directory in SOURCE_FOLDERS and p.suffix.lower() in ('.o', '.obj', '.res', '.pdb', '.exe', '.dll', '.pyc'):
                continue
            files.append(p)
    release = BASE / 'RA2-Toolbox-v0.6.2-Full-Win32-BuildFix4.zip'
    header = 'RA2-Toolbox-v0.6.2-Full'
    # Include current editable source, never historical binaries or build objects.
    with zipfile.ZipFile(release, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6,
                         allowZip64=True) as z:
        for p in sorted(set(files), key=lambda p: str(p).lower()):
            z.write(p, f'{header}/{p.relative_to(BASE).as_posix()}')
        z.writestr(f'{header}/COMPILED_BUILD_METADATA.json', json.dumps({
            'version': '0.6.2', 'build_revision': 'BuildFix4', 'file_version': '0.6.2.4',
            'type': 'Win32 x86 compiled + Full assets/runtime + current source',
            'full_resource_files': len(resources['files']),
            'runtime_tested': False, 'multiplayer_tested': False,
            'module_sha256': {name: sha(BASE / name) for name in EXE_DLL},
        }, ensure_ascii=False, indent=2))
    print('CREATED:', release)
    print('SIZE_MB:', round(release.stat().st_size / 1048576, 2))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(run())
    except Exception as exc:
        print('FULL PACKAGE BLOCKED:', exc, file=sys.stderr)
        sys.exit(1)

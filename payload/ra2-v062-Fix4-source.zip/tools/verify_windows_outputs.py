#!/usr/bin/env python3
"""Verify PE32 architecture, ABI exports, dependency closure and release version."""
from pathlib import Path
import hashlib
import json
import struct
import sys
# Windows embedded Python uses python312._pth and omits the script directory.
sys.path.insert(0, str(Path(__file__).resolve().parent))
from pe32_image import Image

ROOT = Path(__file__).resolve().parent.parent
NAMES = ('RA2Toolbox.exe', 'AssistBridge.dll', 'UnitMonitorBridge.dll', 'CursorHideBridge.dll')
HOOKS = {'AssistBridge.dll': ('AssistHook', 'AssistProtocolInfo', 'AssistMappingPrefix'),
         'UnitMonitorBridge.dll': ('UnitMonitorHook',),
         'CursorHideBridge.dll': ('CursorHook', 'CursorPostHook')}
SYSTEM = {'kernel32.dll', 'user32.dll', 'gdi32.dll', 'winmm.dll', 'gdiplus.dll',
          'comctl32.dll', 'shell32.dll', 'ole32.dll', 'comdlg32.dll', 'advapi32.dll',
          'msvcrt.dll', 'ucrtbase.dll', 'ntdll.dll', 'version.dll', 'ws2_32.dll',
          'shlwapi.dll', 'oleaut32.dll', 'imm32.dll'}


def verify(root):
    legacy = json.loads((root / 'BUILD_SOURCE_MANIFEST.json').read_text('utf-8'))['legacy_binary_sha256']
    recs, images, errors = {}, {}, []
    for name in NAMES:
        try:
            buf = (root / name).read_bytes()
            pe = Image(buf)
            if bool(pe.characteristics & 0x2000) != name.endswith('.dll'):
                raise ValueError('unexpected EXE/DLL type')
            digest = hashlib.sha256(buf).hexdigest()
            if digest == legacy.get(name):
                raise ValueError('unchanged v0.4.1 binary')
            exports = pe.exports()
            required = HOOKS.get(name, ('AssistHostProtocolInfo',))
            if any(symbol not in exports for symbol in required):
                raise ValueError('required export missing: ' + ', '.join(required))
            imports = pe.imports()
            unknown = [x for x in imports if x.lower() not in SYSTEM
                       and not x.lower().startswith(('api-ms-win-', 'ext-ms-win-'))]
            if unknown:
                raise ValueError('unbundled non-system dependency: ' + ', '.join(unknown))
            images[name] = pe
            recs[name] = {'bytes': len(buf), 'sha256': digest, 'machine': 'PE32 x86',
                          'sections': pe.section_count, 'entry_rva': hex(pe.entry),
                          'exports': list(exports), 'import_dlls': list(imports),
                          'imports': imports}
        except Exception as ex:
            errors.append(f'{name}: {ex}')
    if not errors:
        try:
            host, bridge = images['RA2Toolbox.exe'], images['AssistBridge.dll']
            a = host.at_rva(host.exports()['AssistHostProtocolInfo'], 8)
            b = bridge.at_rva(bridge.exports()['AssistProtocolInfo'], 8)
            protocol, shared_bytes = struct.unpack('<II', a)
            if a != b or protocol != 30 or not shared_bytes:
                raise ValueError('host/bridge protocol or Shared structure size mismatch')
            marker = 'Local\\RA2Assist_v037_\0'.encode('utf-16le')
            if bridge.at_rva(bridge.exports()['AssistMappingPrefix'], len(marker)) != marker:
                raise ValueError('incorrect exported mapping namespace')
            resource = host.resource_bytes()
            if '0.6.2.4'.encode('utf-16le') not in resource:
                raise ValueError('EXE version resource mismatch')
            for text in (b'requireAdministrator', b'PerMonitorV2', b'0.6.2.4'):
                if text not in resource:
                    raise ValueError('EXE manifest missing: ' + text.decode())
            for rec in recs.values():
                rec['assist_protocol'] = protocol
                rec['assist_shared_bytes'] = shared_bytes
        except Exception as ex:
            errors.append(str(ex))
    return recs, errors


def main():
    for name in ('BUILD-VERIFIED-v062.tag', 'WINDOWS_BUILD_ARTIFACTS.json'):
        (ROOT / name).unlink(missing_ok=True)
    recs, errors = verify(ROOT)
    if errors:
        print('BUILD NOT VERIFIED:\n' + '\n'.join(errors))
        return 1
    (ROOT / 'BUILD-VERIFIED-v062.tag').write_text(
        'v0.6.2 Full BuildFix4: PE32/ABI/import/version checks passed\n'
        'Game runtime and multiplayer not tested\n', encoding='utf-8')
    (ROOT / 'WINDOWS_BUILD_ARTIFACTS.json').write_text(json.dumps({
        'label': '0.6.2 Full BuildFix4', 'file_version': '0.6.2.4',
        'verified': recs, 'runtime_tested': False, 'multiplayer_tested': False,
        'dependency_check': 'four project binaries import Windows system DLLs only',
    }, ensure_ascii=False, indent=2), encoding='utf-8')
    print('PASS: 4 current PE32 x86 outputs; hooks exported; ABI/Shared size match; version 0.6.2.4')
    print('PASS: no unbundled third-party or compiler-runtime DLL dependencies')
    print('NOTE: static validation does not execute the Windows loader or the game')
    return 0


if __name__ == '__main__':
    sys.exit(main())

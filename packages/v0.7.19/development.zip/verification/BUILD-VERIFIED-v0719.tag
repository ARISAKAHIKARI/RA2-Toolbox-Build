v0.7.19.0 SingleRuntime: PE32/ABI/import/version checks passed
Game runtime and multiplayer not tested

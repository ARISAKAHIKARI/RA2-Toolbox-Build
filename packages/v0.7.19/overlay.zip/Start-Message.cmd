@echo off
setlocal
cd /d "%~dp0"
for %%F in (RA2Toolbox.exe GameRuntime.dll) do if not exist "%%F" (echo Missing %%F & pause & exit /b 1)
set "RA2_TOOLBOX_DRIVER=message"
start "" "%~dp0RA2Toolbox.exe"

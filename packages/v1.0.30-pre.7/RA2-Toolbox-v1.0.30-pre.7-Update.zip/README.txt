﻿RA2 Toolbox v1.0.30-pre.7
文件版本 1.0.30.6 / Assist 58 / Runtime 4 / Manager 3

高刷范围移到高刷光标普通页面：仅光标 / 光标＋拖屏 / 全部，附画面目标刷新率。
单位统计集中显示敌方提示、载具容量、铁幕/力场/冷冻时间、蜘蛛与火力/防御/速度强化入口。
预定面板去掉常驻操作说明与普通增删文字提示，采用暗蓝卡片、悬停描边、队列序号和容量点。
沿用旧配置，修改即时生效并自动保存。

已有完整安装：退出游戏与工具箱，将 RA2Toolbox.exe 和 GameRuntime.dll 成套覆盖原文件，保留资源、配置及 cache。
首次安装：下载 Windows 完整包。Update 包仅含两个运行文件与此说明。

已完成编译、设置路由及面板模型回归，实际 Windows 游戏界面仍待复测。
源码与验证说明：https://github.com/ARISAKAHIKARI/RA2-Toolbox-Build

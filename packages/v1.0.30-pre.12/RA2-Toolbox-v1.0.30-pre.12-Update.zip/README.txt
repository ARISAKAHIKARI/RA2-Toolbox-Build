﻿RA2 Toolbox v1.0.30-pre.12 / 文件版本 1.0.30.11

删除自动刷弹、按住键刷弹和类型清单入口，旧设置不再生效。
步兵进入与 C4（实验性）：默认 Alt+C＋中键点击建筑。
普通步兵执行 C4，工程师占领、间谍潜入。保持功能开启直到安放。
原版负责安放、计时和到期伤害；补丁冲突时状态区显示冲突。

退出游戏和工具箱后，成套替换 RA2Toolbox.exe 与 GameRuntime.dll。
已有完整安装可用 Update；首次安装请选择 Windows 完整包。
两份样本各396项受控 x86 回归及16项适配器 ABI 检查通过。
设置、UI布局、PE/ABI和发布包校验通过；完整游戏/Windows/双机仍待实测。
C4补丁改变本机模拟判定，单方启用仍可能导致不同步；保留实验性标注。

https://github.com/ARISAKAHIKARI/RA2-Toolbox-Build/releases/tag/v1.0.30-pre.12

﻿RA2 Toolbox v1.0.30-pre.6
文件版本 1.0.30.5 / Assist 58 / Runtime 4 / Manager 3

更新：蜘蛛寄生图标 14x14，单位位置，随寄生者所属方变色；火力/防御/速度图标各 7x7，位于单位稍下方并限制在本格。尺寸为游戏像素，地面格为 60x30 菱形。
显示页两个开关默认开启并独立保存；图标不跟随状态文字缩放。
普通三星加成不会显示成箱子强化；MOD 复用独立倍率字段时也会显示。

已有完整安装：退出游戏与工具箱，将 RA2Toolbox.exe 和 GameRuntime.dll 成套覆盖原文件，保留资源、配置及 cache。
首次安装：下载 Windows 完整包。Update 包仅含两个运行文件与此说明。

已做字段、布局、设置、编译与受控入口验证；实际游戏画面及双机联机仍待复测。
源码与验证说明：https://github.com/ARISAKAHIKARI/RA2-Toolbox-Build

﻿RA2 Toolbox v1.0.30-pre.8 / 文件版本 1.0.30.7

高刷范围统一使用光标页的目标刷新率，最高 500 FPS；自动跟随显示器。
名称改为载员自动逃生、敌方索敌显示；风险/测试及地图渲染标注统一为实验性。
简化按钮括号说明，保留悬停帮助。

退出游戏和工具箱后，成套替换 RA2Toolbox.exe 与 GameRuntime.dll。
更新包需要已有完整安装；首次安装请下载 Windows 完整包。
500 FPS 为目标；实际绘制受游戏、渲染器与硬件限制。
设置和 DLL 调度回归已通过，Windows 画面及双机联机仍待实测。

https://github.com/ARISAKAHIKARI/RA2-Toolbox-Build/releases/tag/v1.0.30-pre.8

﻿RA2 Toolbox v1.0.30-pre.9 / 文件版本 1.0.30.8

步兵 C4 改为步兵强制进建筑（实验性）。默认 Alt+C＋中键，保留原配置。
普通步兵不获得占领、潜入或 C4 能力；到达后可能消失，需实机验证。
修正高级移动攻击旧停步状态，增强命令加入原版单位应答语音。
预定支持建筑就绪及无可用单位快捷键切页；整合地图、飞机路径点与每功能清单。
控制台和页面随 DPI 缩放；操作说明使用悬停提示；修正滚动重绘。

退出游戏和工具箱后，成套替换 RA2Toolbox.exe 与 GameRuntime.dll。
已有完整安装可用 Update；首次安装请选择 Windows 完整包。
两份样本各 223 项受控 x86 回归通过，完整游戏、实际音频、Windows 画面及联机仍待实测。

https://github.com/ARISAKAHIKARI/RA2-Toolbox-Build/releases/tag/v1.0.30-pre.9

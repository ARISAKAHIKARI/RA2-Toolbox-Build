#!/usr/bin/env python3
from pathlib import Path
import json,html,hashlib
R=Path(__file__).resolve().parents[1];VERSION='1.0'
(R/'docs').mkdir(exist_ok=True)
old=json.loads(((R/'FEATURE_CATALOG.json') if (R/'FEATURE_CATALOG.json').is_file() else R.parent/'verification/FEATURE_CATALOG.json').read_text())['features']
changes={
'F27':('满载返矿与到场优先', '矿车/矿场支持独立自定义 ID 清单；不勾选自动识别，勾选后仅使用清单，空清单排除全部。矿车须有储矿容量，目标须在该矿车原有 Dock 清单内。设置即时生效与自动保存，提交前重新检查。满载己方矿车由外部 Planner 选择兼容矿场并排队。2格内已到场车可优先于4格外预约车：经统一 OreYield 原生 Move 让位，观察原版 Move 和预约释放后再 Enter。每矿场一轮一车、每载货任务最多被插一次，被插车保留下一轮优先。最多3次让位重试，未释放180帧退出；本轮360帧上限。不打断到场/卸货或手动接管，安全格不足时保留原排队。Runtime 复核原版状态后统一入单机 DoList / 联机 OutList，不直接写 radio。150ms/6帧及对局/手动版本检查保留。', 'assist/source/external_planner.h; ore_queue.h; external_orders_bridge.h; main.cpp'),
'F10':('一键维修和自动维修','仅维修己方受损且未处于维修/待确认状态的建筑。默认检查 YRpp ClickRepairable (+0x157A)；勾选“允许维修不可维修的建筑”后可放宽此类型限制。收集与提交前均检查，关掉许可会跳过未提交的非标准建筑请求；已入原版队列的事件不撤回。不改原版类型数据或归属，仍通过统一 Repair 事件入口。','assist/source/bridge.cpp; assist/source/auto_settings_ui.h'),
'F51':('图标持久缓存与绘制缓存','外部后台线程将实际读取到的图标/色盘保存到 cache/unit-icons，按游戏路径和资源指纹隔离；小资源校验内容，大型 MIX 等资源以大小与更新时间识别。规则、地图、资源或程序变化时换用新的缓存。记录按类型 ID、图标文件名和类别匹配，校验版本、长度、条数与校验和，损坏缓存忽略；临时文件写完后原子替换。新对局可复用磁盘图标，实时图标可读后校正；首次从未读取过的图标仍需等游戏载入。GDI 位图保留，图标或色盘变化才重建。','unit_monitor/source/icon_cache.h; sampler.h; main.cpp'),
'F04':('单一 GameRuntime 与游戏线程管理','EXE 通过统一 host_game_input 订阅消息入口；只有 GameRuntime.dll 进入游戏。游戏线程租约与忙碌拒绝保留，忙碌不伪造回执。','shared/source/host_game_input.h; shared/source/game_entry_manager.cpp'),
'F05':('禁止游戏代码补丁','管理器的 Patch 操作直接返回 PatchDenied；没有 VirtualProtect、跳板分配、原版函数入口或调用点改写。旧补丁登记地址仅作为历史资料。','shared/source/game_entry_manager.cpp; assist/source/input_patch.h'),
'F06':('统一消息与外部输入调度','每个游戏仅有管理器 WH_GETMESSAGE / WH_CALLWNDPROCRET 两个 Windows 消息订阅。宿主按 4 ms 目标轮询增强鼠标输入并保存捕获时对局、边沿、按下时修饰键与取消代次；上下文超过 150 ms 未续期则停采并清除，切局/菜单/失焦重新播种按键状态；战术控制目标间隔 16 ms。实际延迟取决于系统调度和游戏消息泵。','shared/source/host_game_input.h; assist/source/pointer_host.h'),
'F07':('统一请求、接续和事件提交','命令、选兵、外部规划、协同与增强输入使用同一 Shared 协议和同一游戏线程调度。观察到与点击目标格相符的原版 Move 状态后才追加 CS；不修改原版任务、事件字节或接收函数。请求没有独立 Hook。队列满保留未提交部分，已接收前缀不重发。','assist/source/pointer_intent.h; assist/source/pointer_bridge.h; assist/source/bridge.cpp'),
'F16':('信标清理与实验性地图揭示','地图全开默认未许可，须勾选“启用地图全开（实验性）”；宿主与 Runtime 均检查许可，关闭清除待处理请求，不回退已揭示地图。经统一管理器调用原版本地 UI 接口。恢复单机及多人地图揭示，仅作用于当前玩家；仍检查有效对局与地图数组，菜单/加载/观战不执行。它是本地显示调用，不构造模拟事件。','assist/source/bridge.cpp'),
'F15':('组合选兵与双按范围','多个兵种可配置同一个快捷键，注册时去重。单按合并选中屏幕内这些类型的己方单位，双按选全图；本局缺失类型跳过。宿主生成绑定本局的类型掩码，唯一 GameRuntime 在同一选兵请求里筛选全部对象，只清空一次再合并选区；无网络事件或新增 Hook。解绑某个兵种保留组内其他兵种。原有按普通武器选变体功能及其独立快捷键保留。普通功能快捷键仍拒绝冲突。','assist/source/type_hotkey.h; assist/source/type_bindings_ui.h; assist/source/type_select_bridge.h; assist/source/main.cpp'),
'F21':('逃生助手','仅跟踪选中的己方载具，取消选中且载具仍存活时停止跟踪。载具被毁后，对已观察到的存活乘员继续跟进。可部署乘员保留原版散开移动，散开跟踪窗口为 180 帧；每名乘员只要原版 CanDeploy 允许就在当前调度提交 Deploy，不等待同格其他乘员，也没有固定停稳两帧延迟。条件不满足时不发 Sleep 阻止散开。显式停止、取消、正常下车、归属变化或超时结束跟进；不创造幸存者。仅保留一个逃生开关。','assist/source/native_orders_bridge.h; assist/source/unload_policy.h'),
'F22':('自动 CS：原版移动后接续','保留右键原版移动。宿主捕获右键释放时的输入意图，Runtime 等待己方选中单位的 Move 与相同目的格可观察后，再经 nativeMission 追加一次 AttackMove。检查单位类型白名单、武器、对局、对象身份和新输入代次。没有改写原版 QueueMegaMission；不改鼠标谓词。','assist/source/pointer_host.h; assist/source/pointer_bridge.h; assist/source/auto_cs_bridge.h'),
'F23':('按键 CS','按住配置键配合独立配置的 CS 鼠标键（默认中键），留空则仅鼠标。配置为右键时接续原版 Move；直接攻击移动使用另一独立按钮（默认侧键 1）。Shift 右键规划不接续；聊天、菜单、失去前台或过期时拒绝。原版光标不再被强制改成 CS 光标。','assist/source/pointer_host.h; assist/source/pointer_bridge.h'),
'F24':('高级移动攻击','按住配置键配合本功能鼠标键（默认中键，均可配置）；右键模式确认原版 Move 后追加初始 AttackMove，再登记外部规划任务。后续目标选择仍在 EXE，回到统一管理器验证并提交。','assist/source/native_orders_bridge.h; assist/source/external_planner.h; assist/source/pointer_bridge.h'),
'F25':('磁电轮换攻击','配合独立磁电鼠标键（默认中键）；配置为右键时：确认原版 Move 后仅登记任务，不再替换原版移动。中键方式先发普通 Move 再登记。外部 Planner 读取出手/重装填证据轮换目标，每次攻击通过统一原版事件通道。没有武器选择或射击函数 Hook。','assist/source/native_orders_bridge.h; assist/source/external_planner.h; assist/source/magnetron_cycle.h'),
'F26':('新输入取消与手动优先','宿主观察右键按下以及 S/D/X 边沿，取消旧的未提交增强批次；有效取消请求按捕获的己方选区撤销工具任务。普通事件仍由游戏处理。状态观测继续识别原版任务变化。输入队列上限 16，超时不补发；短于轮询间隔的点击可能漏采，不会补造点击。','shared/source/host_game_input.h; assist/source/pointer_bridge.h; assist/source/object_index.h'),
'F30':('高级进驻建筑与载具','按住进驻配置键（默认 Alt）并按本功能鼠标键（默认中键）指向目标，捕获最多 512 个源对象，向现有外部协同分配器提交。按同类目标容量分配，Runtime 复核原版进入合法性后发送 Enter/Capture。超限拒绝增强请求，普通左右键仍原样运行。','assist/source/pointer_bridge.h; assist/source/cooperative_bridge.h; assist/source/extra_settings_io.h'),
'F31':('飞机高级攻击','按住对应攻击配置键并按本模式鼠标键（默认中键）指向敌方目标。目标分配、受击上限仍由外部协同规划器完成，GameRuntime 复核对象与武器兼容并构造 Attack 事件。不再拦截 FootClickedAction。','assist/source/cooperative_bridge.h; assist/source/extra_settings_io.h'),
'F33':('飞碟主武器','开启后 配置键（默认 Ctrl，可留空）+本功能鼠标键（默认中键）指向建筑，识别飞碟/吸取副武器类型并提交原版对地强制攻击事件。原版正常点击与武器选择保持原样；不直接修改武器、任务或目标。','assist/source/cooperative_bridge.h'),
'F34':('变卖受吸取的己方建筑','开启后 配置键（默认 Ctrl，可留空）+本功能鼠标键（默认侧键 2）指向己方受吸取建筑，经统一对象事件构造器提交 Sell。目标必须仍存活、归自己所有。无变卖模式/光标 Hook。','assist/source/cooperative_bridge.h; assist/source/pointer_bridge.h'),
'F35':('变卖己方载具','开启后 配置键（默认 Ctrl，可留空）+本功能鼠标键（默认侧键 2）指向载具。保留原版接收端条件：目标归发送玩家、载具格子中存在建筑。构造 Sell 对象事件，目标标签为 0x34。不会伪造其他玩家身份、改变格子链表或直接调用出售执行函数。模型执行了用户 EXE 的 Sell 接收分支，最终出售/经济效果仍待游戏实测。','assist/source/cooperative_bridge.h; assist/source/pointer_bridge.h'),
'F36':('变卖敌方建筑：停用','不再伪造敌方 House 发出 Sell。配置加载强制关闭、界面禁用、Runtime 再检查己方归属。','assist/source/extra_settings_io.h; assist/source/extra_controls.h; assist/source/cooperative_bridge.h'),
'F37':('随处建造：停用','该能力需要绕过原版放置合法性判断，普通移动/生产事件无法等价实现。删除 0x464AC0 拦截，旧配置不能恢复，Runtime 返回不支持。','assist/source/placement_bridge.h'),
'F39':('科技全开：生产连续性待修复','补图实验不能防止原版 Abandon/AbandonAll 取消生产，已撤出。删除两个原版侧栏 CanBuild 调用点改写，不补造无资格图标，不绕过前置科技。类型目录和条件解析保留。界面禁用科技全开，旧配置不能恢复。','assist/source/sidebar.h; assist/source/main.cpp'),
'F40':('合法生产与生产观测','外部生产仅限单机，提交前调用正常 CanBuild（limitOnly=false）并检查工厂；原生侧栏不被改写。生产完成/暂停观测以及本地图标闪烁保留。','assist/source/bridge.cpp; assist/source/sidebar.h'),
'F52':('Tab 显示与快捷键','删除单位统计自己的 WH_KEYBOARD_LL。改为现有 UI 时钟轮询 Tab，不吞原版 Tab，游戏原来的 Tab 行为会同时保留。Ctrl+Alt+H 和显示按钮可独立显隐；勾选常驻显示可完全不使用 Tab。失焦/菜单/读取无效仍隐藏，面板与日志说明原因。','unit_monitor/source/main.cpp'),
'F55':('原版光标隐藏/恢复','通过统一 GameRuntime 在绑定游戏线程调用原版鼠标对象 Hide/Show，跟踪配对引用次数，失败不写回陌生对象；Windows 光标也由同一管理器资源路径处理。这里改变本地显示，不改游戏代码或仿真任务。','cursor/source/hide.cpp'),
'F57':('游戏内光标刷新','外部宿主经唯一 host_game_input 校验窗口与前台后发送 WM_SETCURSOR；等待有界且不持调度锁。游戏线程上的光标资源发布仍由 GameRuntime 消费。','shared/source/host_game_input.h; cursor/source/hide.cpp'),
'F63':('Shift5','删除光标模块自己的 WH_MOUSE_LL。通过现有宿主循环观察物理左键边沿，检查 Shift、区域及 Ares 原生支持；额外点击仍由唯一 host_game_input::clickPair 发送且配平抬起。轮询可能漏掉极短点击，不拦截原版点击。','cursor/source/main.cpp; shared/source/host_game_input.h'),
'F67':('一页控制台与当前状态','快捷键字段读取当前 HKM_GETHOTKEY 自绘，保留原生输入/通知；首绘和失焦也显示值。光标主页及高级设置改用公共按钮、开关与配色，固定展开宽度。沿用即时保存与一页滚动，旧帧入口只显示统一消息模式。','assist/source/main.cpp; assist/source/extra_controls.h; shared/source/modern_ui.h')}
features=[]
for f in old:
 ident=f['id'];name,impl,source=changes.get(ident,(f['name'],f['implementation'],f['source']))
 if ident in ('F36','F37','F39'):route='停用：不提供原版规则/身份绕过'
 elif ident in ('F22','F23','F24','F25'):route='宿主输入意图 → 原版 Move 观察（右键）/主动命令（中键）→ 统一事件入口'
 elif ident in ('F30','F31','F32','F33','F34','F35'):route='中键/侧键意图 → GameRuntime 查询/复核 → 原有规划或统一事件入口'
 elif ident in ('F01','F02','F03','F38','F42','F43','F44','F45','F46','F47','F48','F49','F50','F51','F53','F54','F56','F58','F59','F60','F61','F62','F64','F65','F66','F67'):route='读取/外部展示/配置资源；无游戏函数拦截'
 else:route='统一管理器原版调用或事件入口；无功能级 Hook'
 features.append({'id':ident,'name':name,'implementation':impl,'source':source,'route':route,'review':'源码路径审查；局部行为测试见报告，未做全部功能游戏实机验收'})
filters={
 'F10':'可通过功能单位清单限制可维修建筑类型，原有不可维修建筑许可独立生效。',
 'F17':'装车乘员和载具可分别配置类型清单，仍要求原版进入合法性、容量与体积允许。',
 'F18':'重试前复核当前类型清单；清单撤销不会撤回已经进入原版队列的 Enter。',
 'F19':'可配置允许卸载的载具类型；乘员清单控制后续自动任务，不改变原版整车卸载行为。',
 'F20':'可配置允许执行下车后续任务的乘员类型。',
 'F21':'载具与乘员类型分别可配置。仍然只登记当前选中的己方载具；撤销类型后停止后续跟踪。',
 'F24':'高级移动攻击源单位类型可独立配置；捕获与提交旧计划前均复核清单。',
 'F25':'磁电源单位类型可配置；仍要求原版磁力武器和 Locomotor 弹头，清单不赋予新武器。',
 'F30':'源乘员和目标建筑/载具均可配置类型；同类目标分配、容量和原版进入判断保留。',
 'F31':'飞机源单位类型可配置；仍须是原版飞机或符合原有空中状态的载具，并具备兼容武器。',
 'F33':'飞碟源单位类型可配置；保留飞碟 ID 或原版吸取副武器识别，不赋予普通载具新能力。',
 'F35':'可配置允许出售的己方载具类型；仍须满足原版所在格有建筑等出售条件。'}
for f in features:
 if f['id'] in filters and filters[f['id']] not in f['implementation']:f['implementation']+=' '+filters[f['id']]
features=[f for f in features if f['id']!='F68']
features.append({'id':'F68','name':'各功能单位类型清单','implementation':'统一配置 14 项独立类型清单：飞机、飞碟、磁电、高级移动、装车乘员/载具、进驻乘员/目标、卸载载具/乘员后续任务、逃生载具/乘员、变卖战车、维修建筑。面板选择功能后编辑 ID 列表；每项自定义开关独立。未勾选保留原有识别；勾选且清单为空不处理任何类型。最多 512 项、每项 23 个 ASCII 字符，支持大小写归一、去重与中文分隔符。离线编辑、即时生效、自动保存；配置半写或损坏拒绝发令。只筛选类型，不写原版规则，不绕过所有权/武器/容量/进入合法性。矿车、矿场、自动 CS 与组合选兵沿用各自配置。','source':'assist/source/feature_type_config.h; feature_type_bridge.h; auto_settings_ui.h; type_bindings_ui.h; extra_settings_io.h','route':'EXE 配置 → Shared 版本化快照 → 唯一 GameRuntime 在捕获与提交前复核','review':'便携解析/实际 UI 处理器及 x86 DLL 模型；未做游戏实机全功能验收'})
assert len(features)==68 and len({f['id'] for f in features})==68
(R/'FEATURE_CATALOG.json').write_text(json.dumps({'version':VERSION,'architecture':'No feature detours; sole manager Windows message entry','features':features},ensure_ascii=False,indent=2)+'\n')
removed=[
('0x646E90','原版 QueueMegaMission','自动 CS / 高级移动 / 磁电移动的事件改写','删除；右键原版任务生效后再追加，或中键主动发令'),
('0x731BF0','原版 CS 按键/光标谓词','强制显示 CS 光标与转换判断','删除；原版光标保留'),
('0x6FFE00','原版 ClickedEvent','手动命令取消观察','删除；宿主轮询输入和只读状态观察'),
('0x4D74E0','原版 FootClickedAction','高级进驻 / 飞机 / 飞碟点击转换','删除；中键显式请求'),
('0x692610','原版 DecideAction','进驻/变卖光标覆盖','删除；不覆盖原版光标'),
('0x4AB9B0','原版 MouseUp','变卖事件插入与原版分支改写','删除；Ctrl+侧键 2提交合法己方 Sell'),
('0x464AC0','放置合法性','随处建造','删除；功能停用'),
('0x6A97D2、0x6AA781','侧栏 CanBuild 调用点','科技全开','删除；功能停用'),
('0x55D360；0x48CE8A、0x608206、0x60D407、0x62314E、0x623D72、0x624271','帧入口及六个候选调用点','实验帧调度','全部删除；只用管理器消息入口'),
('0x64CC61、0x64C5AF','CRC/过期事件诊断','0.7.12 的诊断拦截','0.7.13 已撤回；本版继续不安装'),
('WH_MOUSE_LL','宿主鼠标低级 Hook','Shift5 观察','删除；宿主轮询'),
('WH_KEYBOARD_LL','宿主键盘低级 Hook','Tab 显示并吞键','删除；轮询且不吞原版 Tab')]
(R/'INTERCEPTION_INVENTORY.json').write_text(json.dumps({'version':VERSION,'removed':removed,'remaining_hooks':[{'owner':'shared/source/host_game_input.h','type':'WH_GETMESSAGE / WH_CALLWNDPROCRET','purpose':'single GameRuntime delivery on the verified game GUI thread; CallNextHookEx preserves message chain'}],'remaining_non_hook_effects':['native EventClass construction and SP DoList / MP OutList enqueue','local selection/camera/superweapon targeting UI native calls','local sidebar redraw/flash presentation fields','paired native cursor Hide/Show, Windows cursor resources','host SendInput for optional Shift5','offline transparent SHA install/restore','Experimental opt-in RevealMap native local-house call in supported gameplay sessions; selected-order display timer native call'],'no_real_netplay_certification':True},ensure_ascii=False,indent=2)+'\n')
css='body{max-width:1120px;margin:36px auto;padding:0 24px;font:16px/1.75 system-ui,sans-serif;color:#233044;background:#f6f8fb}h1,h2{color:#123a60}h2{margin-top:32px}table{width:100%;border-collapse:collapse;background:white}td,th{border:1px solid #cbd5e1;padding:10px;text-align:left;vertical-align:top}th{background:#eaf0f7}code{overflow-wrap:anywhere}article{border-bottom:1px solid #d5dce6;padding:12px 0}.note{padding:16px;background:#e8f2fb;border-left:4px solid #2877b6}a{color:#1464ad}'
def page(title,body):return '<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>'+title+'</title><style>'+css+'</style><body><h1>'+title+'</h1>'+body+'</body></html>'
intro='''<p class="note">本版遵循：不拦截或改写原版任务。原版任务照常执行，工具仅经唯一 GameRuntime 管理器读取状态、提交额外原版事件。停止使用所有功能级游戏代码 Hook。</p>
<p><a href="INTERCEPTION-INVENTORY.html">原版拦截清单</a> · <a href="TEST-REPORT.html">测试与边界</a></p>
<h2>1.0 可配置单位类型</h2><p>战术面板的“功能单位清单”统一编辑飞机、飞碟、磁电等 14 项功能的独立列表。选择功能，填写单位 ID，并按需勾选“仅处理自定义清单中的类型”。未勾选沿用原有自动识别，勾选后只处理清单内且具备原版合法能力的单位，勾选且留空则不处理。设置即时生效并自动保存，支持离线修改，见 F68。旧版 INI 缺少这些项时行为保持一致。</p><h2>图标缓存与自动化配置</h2><p>图标/色盘后台落盘，按游戏与资源指纹隔离，绘制位图复用；矿车与矿场独立类型清单，默认自动识别；维修不可维修建筑须主动勾选许可，默认关闭。详见 F10、F27、F51。</p><h2>继承 0.7.19 的实验性地图全开与独立覆盖层显隐</h2><p>地图全开标为实验性，新增“启用地图全开（实验性）”复选框，默认未勾选，设置即时生效并自动保存。勾选是许可，本身不发送揭图命令；按钮、快捷键、旧 AutoRevealNewMatch 自动请求和游戏侧最终执行均检查许可。取消勾选清除宿主待处理请求，游戏侧拒绝未获许可的请求；已揭示的地图不会回退。保存位置为 Assist.ini 的 [Experimental] RevealMap。</p><p>单位统计并不依赖 Tab 拦截；原有实现轮询 Tab，原版菜单可能同时响应。本版修复 Ctrl+Alt+H 在按住/短按长按模式下不能独立显示的问题，并增加“显示 / 隐藏覆盖层”按钮。“常驻显示（不依赖 Tab）”勾选后正常战场中直接显示，不必按 Tab，保留原 settings.ini tabEnabled 的兼容。菜单、失焦、无有效数据时继续隐藏，不用可读单位数据代替菜单验证。面板及 UnitMonitor.log 记录隐藏原因和菜单状态字段。未加入平台专用 Hook 或绕过保护；尚无 LBW 实机验证。</p><h2>继承 0.7.18：独立鼠标绑定与即时逃生部署</h2><p>高级移动、磁电轮换、按键 CS、高级进驻、飞机模式 1/2、飞碟主武器、直接攻击移动、变卖吸取目标、变卖战车共十项，各自选择停用/中键/侧键 1/侧键 2/右键，即时生效并自动保存。鼠标配置集中列在战术面板中；修改一项不互换或覆盖其他项。缺少新配置时继承旧 EnhancedButton/AttackMoveButton/SellButton；显式停用值 0 保留。未提供自定义优先级。</p><p>原有匹配规则保留：只考虑本鼠标键上已开启、组合键满足的增强项，再考虑直接攻击移动，最后变卖。地面功能非空且按住的键优先于空键；多个候选按原有磁电→高级移动→CS规则，每对象最多一个初始指令。对象目标沿用原有进驻、飞碟、飞机处理顺序。这里没有按目标失败后跨操作类别重新仲裁；如将不同类别绑定到同一组合，前一类可能遮住后一类，可设置不同按钮或组合键。飞机同按钮双空时用模式 1，不同按钮分别触发对应模式。</p><p>每个增强请求只携带本次按钮匹配的功能授权；进驻或飞碟按钮点地面不会顺带发移动或自动 CS，变卖战车与变卖吸取建筑分别校验授权。全局自动 CS 仍跟随普通右键并检查白名单。配置为右键的增强功能保留原版点击，至少下一帧追加；地面接续仍等待观察对应原版 Move。不新增 Hook，不增加私有入口，Assist 协议为 41，必须整包更新。</p><p>逃生仍只登记选中的己方载具。可部署幸存乘员独立查询原版 CanDeploy，允许就立即提交，不等待同格其他人的在途 Deploy，也不统一等待停稳两帧。当前不允许部署就保留原版散开，不发 Sleep；每个乘员独立保留在途状态，避免重复部署。散开观察窗口仍为 180 帧，取消、手动停止、正常下车及归属变化仍停止跟踪。成功入队不等于游戏中已完成部署。</p><h2>继承 0.7.17 的组合选兵与统一字体</h2><p>多个兵种使用同一快捷键即可组合选兵，单按屏幕、双按全图；一次合并选区，解绑只移除当前兵种。三面板正文/按钮 14 像素，标题 20 像素，嵌入式高刷光标与其他面板一致，独立窗口保留 DPI 缩放。鼠标按住键可留空并显示“仅鼠标”；飞碟和变卖仍默认 Ctrl。空键仅在未按 Ctrl/Alt/Shift 时匹配。飞机模式 2 的旧零值表示仅鼠标，不代表停用。</p><h2>继承 0.7.16 显示修复</h2><p>用户反馈 0.7.15 实际联机已不掉线。本版保留其下令/帧号/输入边界。快捷键框直接读取 HKM_GETHOTKEY 完整重绘，保留原生键盘处理和变更通知；初始、失焦、重新赋值及禁用时都显示当前值。高刷光标主页面与高级设置采用公共按钮/开关/配色，展开宽度固定，设置继续即时生效。</p><p>地图揭示恢复多人本地玩家调用；地图未就绪/菜单/观战仍拦住执行。选中单位合法命令成功入队后，经唯一管理器调用 0x70D150 启动原版 25 帧提示线显示计时器，由原版随后绘制。不修改单位任务/目标，不追加网络事件；未选中、被拒绝和重复轮询不启动计时器。完整函数字节签名不符时只跳过视觉反馈。原版显示选项和当前实际目标仍决定绘制内容，排队回执不表示任务已执行。</p><h2>继承 0.7.15 入局修复</h2><p>加载/菜单/对话框、负帧号、观战及未验证会话不消费游戏命令。有效首帧 0 立即可用，无固定延时或必须先走帧的要求。输入按捕获时的对局绑定，不能在出队时改贴当前对局编号。统一事件入口在构造前和普通入队前复核现场上下文；SP 保持当前帧+1，MP 保持原版构造器帧号，发送计时仍取原版时钟。</p>
<h2>与自动装车的启动差异</h2><p>装车在明确请求时才分配乘员并构造 Enter；CS/磁电/飞机/飞碟/卖车仅开启开关时，不应自动发令，需有效输入或已登记任务。倒矿与维修是条件自动任务，可能在入局时发现实际工作。全开开关且无工作/输入的模型场景应为零事件；有受损建筑则允许维修事件，随后装车载荷与单独装车一致。原版代码、单位任务、类型和 House 数据在这些发送端用例中未发生写入。不是所有功能开关都需要安装 Hook。</p>
<h2>刚进入对局时各功能做什么</h2><table><tr><th>功能</th><th>仅开启时</th><th>真正产生事件的条件</th></tr><tr><td>自动装车</td><td>空任务账本不发令</td><td>明确装车请求后查询己方乘员/载具，构造 Enter</td></tr><tr><td>自动维修</td><td>按节拍发现受损己方建筑</td><td>需要维修且无重复待确认记录，构造 Repair</td></tr><tr><td>自动倒矿</td><td>发布只读世界给外部规划器</td><td>外部计划返回，身份/时效/占用复核通过后发正常任务</td></tr><tr><td>自动/按键 CS</td><td>更新可用状态，不安装 Hook、不构造任务</td><td>本局有效输入，原版 Move 已可观察；或明确侧键攻击移动</td></tr><tr><td>高级移动/磁电</td><td>检查普通构造器签名字节，更新可用状态</td><td>本局有效输入登记任务，外部计划经统一入口提交</td></tr><tr><td>飞机/飞碟/卖车/高级进驻</td><td>更新可用状态，不发令</td><td>本局明确中键/侧键请求及目标合法性通过</td></tr></table><p>所有路径共用 GameRuntime 的现场检查与每帧总额度。输入和外部计划不拥有单独 Hook。仅开启后即断线，应先看日志中的 queued/newQueued、待处理命令和输入是否为零；零发单时还需排查加载器、其它插件、读取/光标路径和平台现场，不能直接归罪于事件内容。</p><h2>执行与读取</h2><p>三大宿主模块使用统一 ReadSession，连接登记有短锁，独立任务采样不持整批串行锁。宿主规划与输入邮箱交给唯一 GameRuntime.dll；管理器在游戏 GUI 线程发放执行租约，忙碌保持未确认请求。修复后的接口禁止 Patch 操作。游戏内只保留管理器的 Windows 消息入口，不创建功能自己的输入或帧入口。</p>
<p>事件由统一适配器调用原版 EventClass 构造器，再提交单机 DoList 或多人 OutList。可选原版高层发令后端仍经同一入口且检查真实入队结果，不在失败后盲目补发。接收端函数与游戏对象 mission/target/locomotor 不被工具写入。选兵、光标、侧栏闪烁等本地 UI 不冒充网络事件。</p>
<p>实际仍留在 Runtime 内的业务：自动装车候选分配、维修发现/节拍、卸载/逃生的部分选择。它们已使用同一事件入口且无私有 Hook；本版不宣称所有规划计算都已迁出 DLL。统一读取接口也不意味着跨功能共享一个完全原子的世界快照。</p>
<h2>本版操作（以下鼠标键为默认，可配置）</h2><table><tr><th>功能</th><th>操作与行为</th></tr><tr><td>自动 CS</td><td>开启并配置类型后，照常右键移动；观察到原版 Move 后仅追加一次 AttackMove。</td></tr><tr><td>按键 CS / 高级移动 / 磁电</td><td>按住各自配置键后右键移动；或按住配置键加中键主动提交。磁电接续只登记原版 Move，不重复发初始 Move。</td></tr><tr><td>普通增强移动</td><td>中键点地面；侧键 1直接攻击移动。</td></tr><tr><td>高级进驻 / 飞机高级攻击</td><td>按住对应配置键（进驻默认 Alt、飞机第一模式默认 Ctrl）加中键指向目标。</td></tr><tr><td>飞碟主武器</td><td>开启后配置键（默认 Ctrl，可留空）+中键点建筑，原版对地攻击事件。</td></tr><tr><td>变卖</td><td>开启对应选项后配置键（默认 Ctrl，可留空）+侧键 2。仅己方；载具需要所在格子存在建筑。</td></tr></table>
<h2>时效、取消与冲突</h2><p>增强输入首次接收上限 150 ms / 8 帧；明确目标后，等待原版任务或处理剩余批次最多 1500 ms / 90 帧。原始输入时间不会续期。新的输入代次使旧的未提交部分失效。绑定选区对象指针+ID，核对对局、所属玩家、菜单/聊天、视口与相机，目标 ID 改变即拒绝。右键 Shift 规划保留原版，不接续。</p>
<p>每帧事件总预算仍为 24，增强输入在有其它规划/自动化任务时最多先使用 12。最多 512 源对象，接受前缀不会重放；过期或未接受的部分需要重新操作。外部协同计划继续使用原有来源时效与合法性检查。输入轮询和系统调度不是实时保证，极短按键可能漏采。没有新的引擎 Hook 来补救漏采。</p>
<h2>停用与限制</h2><p>科技全开的补图实验因原版自动取消生产而未发布，本版沿用停用状态，生产连续性尚未解决；随处建造保持停用；变卖敌方建筑不再提供。地图揭示恢复单机及多人；外部直接生产只限单机；直接生产检查正常 CanBuild。生产观测、类型目录、读数显示继续保留。Tab 显示不再吞游戏 Tab。没有 Windows 桌面与平台双人游戏实测，不能承诺已经消除全部断线。</p><h2>68 项功能审查</h2>'''
body=intro
for f in features:body+='<article><h3>'+html.escape(f['id']+' · '+f['name'])+'</h3><p>'+html.escape(f['implementation'])+'</p><p><b>路径：</b>'+html.escape(f['route'])+'</p><p><small>源码：'+html.escape(f['source'])+'</small></p></article>'
(R/'docs/FULL-1.0-Architecture-and-Features.html').write_text(page('RA2 Toolbox 1.0 Full — 架构与全部功能',body))
rows=''.join('<tr>'+''.join('<td>'+html.escape(x)+'</td>' for x in row)+'</tr>' for row in removed)
body='<p class="note">“由管理器安装 Hook”仍然是 Hook。本版进一步删除功能级拦截，并使管理器 Patch 请求直接失败。唯一保留的两项 Windows 消息订阅由管理器持有，负责同一个 GameRuntime 的线程入口，不改写 EXE 的代码。</p><table><tr><th>旧位置</th><th>原版入口</th><th>旧用途</th><th>本版处理</th></tr>'+rows+'</table><h2>不是 Hook，但确实改变状态的操作</h2><p>正常事件入队、本地选兵与镜头、超武瞄准 UI、图标闪烁、原版光标 Hide/Show、Shift5 的额外 SendInput、离线 SHA 资源安装/恢复均列入审查。无 Hook 不是联机正确性的证明；事件必须仍通过所有权和原版接收条件。地图揭示恢复原版本地玩家调用，提示线恢复原版显示计时器调用；两者均经唯一管理器，不增加模拟事件或 Hook。</p><h2>卖车原版接收端依据</h2><p>用户 EXE 的 EventClass 接收入口 0x4C6CB0 中，Sell 分支检查事件 House 与目标 owner（0x4C6F3B–0x4C6F48）；载具路径经坐标与格子建筑查询（0x4C6F76–0x4C6F96），满足后才调用原版出售虚函数。测试执行了该接收分支；对象解析、地图查询和最后出售动作使用桩，未模拟经济与平台网络。</p><h2>依据</h2><p>YRpp DisplayClass::ProcessClickCoords 正常查询入口 0x692300；六个指针参数的 thiscall ABI。MO OrderUtil 的鼠标格子查询也采用原版坐标查询及视口边界检查。本版不复制 MO 的输入/武器 Hook。项目参考资料见 verification/UPSTREAM_REFERENCES.json。</p>'
(R/'docs/INTERCEPTION-INVENTORY.html').write_text(page('1.0 原版拦截与状态修改清单',body))
(R/'README-1.0.txt').write_text('RA2 Toolbox 1.0 Full\n文件版本：1.0.0.0；Assist 协议：41。基于 0.7.20。\n\n1.0 新增：\n战术助手“功能单位清单”可分别设置飞机、飞碟、磁电、高级移动、装车乘员/载具、进驻乘员/目标、卸载载具/乘员、逃生载具/乘员、变卖战车、维修建筑，共 14 项。\n选择功能，填写逗号分隔的单位 ID。未勾选自定义时沿用原有自动识别；勾选且留空时不处理。每项独立，支持离线修改、即时生效和自动保存。\n捕获和发令前均复核最新清单，重连/新局清除旧配置缓存；列表不会赋予单位新能力，也不修改原版规则或归属。\n\n完整功能范围：\n高刷光标：原生隐藏/恢复、外置高刷、游戏内刷新、缩放/热点修正、补帧、离线预处理、图案与缓存、Shift5、透明 SHA 安装/恢复、状态诊断。\n单位统计：玩家/单位数量、生产队列和进度、图标/色盘持久缓存、Tab/常驻/快捷键显隐、菜单与失焦隐藏、重新连接。\n战术助手：维修、战斗/受损/空载/空闲筛选、组合选兵、超武快捷键、信标清理、自动装车、智能卸载、仅选中载具逃生、自动/按键 CS、高级移动攻击、磁电轮换、自动倒矿与到场优先、进驻建筑/载具、飞机分配和目标配额、飞碟主武器、合法己方变卖、生产观测和提示。\n覆盖层：载员/容量、铁幕/力场/冻结倒计时、心灵探测和攻击指向、箱子位置/预览、文字提示与刷新率。\n\n矿车和矿场使用独立自定义类型清单。矿车仍须有储矿容量，矿场仍须在原有 Dock 清单中。自动 CS 与组合选兵继续使用原有逐类型配置。\n“允许维修不可维修的建筑”默认关闭；开启只放宽类型条件，仍须己方受损且未在维修/待确认。矿车/维修等已入原版队列的事件不会因修改清单被撤回。\n单位图标与色盘后台保存到 cache/unit-icons，按游戏路径和资源指纹隔离；实时数据可读后校正，损坏缓存忽略，GDI 位图复用。首次从未读到的图标仍须等待游戏加载。\n\n安装与操作：\n先退出游戏和旧工具箱，再整体解压，运行 RA2Toolbox.exe 或 Start-Message.cmd。EXE 与 GameRuntime.dll 必须同版。可迁移 Assist.ini、settings.ini 和 cache/unit-icons。\n十项增强鼠标键可分别选择停用、中键、侧键 1/2 或右键。按住键留空即仅鼠标；右键保留原版点击后接续，不新增自定义优先级。\n单位统计支持常驻、Ctrl+Alt+H 与显隐按钮。设置即时生效并自动保存，不需要另按保存。\n\n架构和限制：\n只注入一个 GameRuntime.dll；功能共用管理器的 Windows 消息入口和原版事件提交，无功能级 Hook 或游戏代码补丁。\n科技全开、随处建造、敌方建筑变卖继续停用。地图全开为默认关闭、需主动勾选许可的实验性功能。箱子结果功能已删除。\n1.0 完成便携和实际 x86 DLL 模型测试；尚未完成 Windows 游戏实机、LBW、平台联机、屏幕捕获及真实延迟/帧率验收，发布为预发布版本。\n\n完整 68 项特性、操作/实现和停用状态：GitHub 仓库 docs/FEATURES.md、docs/FULL-1.0-Architecture-and-Features.html；测试报告 docs/TEST-REPORT.html。\n源码和开发文档单独保存在仓库 source/ 与 packages/v1.0/development.zip，不作为上传的 Release 附件。engine/runtime 下 Python 文件是必要运行依赖，请勿删除。\nhttps://github.com/ARISAKAHIKARI/RA2-Toolbox-Build\n')
print('Updated 68-feature catalogue, architecture, interception inventory and release README')

"""Run source/build-zig-x64.sh's pinned commands without requiring Bash.

Production sources are unchanged. The three self-contained MSVC SEH wrappers
add -nostdlib/-nostdinc to avoid probing for an unused Windows SDK. Target ABI,
optimization and production link commands match the checked-in Bash script.
Each command and its output are retained separately.
"""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
import json
import hashlib
import os
import shutil
import subprocess
import time
import re

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def source_hashes(source, include_tests=True):
    excluded = {'.git', 'node_modules', 'dist', '__pycache__', 'projection-bin', '.deps', 'research'}
    result = {}
    for current, directories, files in os.walk(source):
        directories[:] = sorted(name for name in directories if name not in excluded and (include_tests or name != 'tests'))
        for name in sorted(files):
            path = Path(current) / name
            if path.suffix.lower() not in {'.pyc', '.pyo'}:
                result[path.relative_to(source).as_posix()] = sha(path)
    return result

HERE = Path(__file__).resolve().parent
TOOLCHAIN = Path(os.environ['RA2_TOOLCHAIN'])
SOURCE = HERE.parent / 'source'
OUT = HERE / 'render-fixes' / 'build'
LOGS = HERE / 'render-fixes' / 'logs'
CACHE = HERE / 'render-fixes' / 'toolchain-cache'
ZIG = TOOLCHAIN / 'zig-windows-x86_64-0.13.0' / 'zig.exe'
RUNTIME = OUT / 'obj' / 'runtime-x86'
HOST = OUT / 'obj' / 'host-x64'
SDK = TOOLCHAIN / 'webview2' / '1.0.4314.35'
GENERATED = OUT / 'generated'
ENV = dict(os.environ)
ENV.update(ZIG_GLOBAL_CACHE_DIR=str(TOOLCHAIN / 'cache-global'),
           ZIG_LOCAL_CACHE_DIR=str(CACHE / 'local'),
           PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1')
ENV.update(TEMP=str(CACHE / 'tmp'), TMP=str(CACHE / 'tmp'))
for folder in (OUT, LOGS, RUNTIME, HOST, GENERATED, CACHE / 'tmp'):
    folder.mkdir(parents=True, exist_ok=True)
assert subprocess.check_output([str(ZIG), 'version'], env=ENV, text=True).strip() == '0.13.0'

source_before=source_hashes(SOURCE,include_tests=False)
PYTHON=TOOLCHAIN/'python/python.exe'
FRONTEND=SOURCE/'suite/frontend'
REACT=(FRONTEND/'package-lock.json').is_file()
NODE=Path(ENV.get('RA2_NODE') or shutil.which('node') or '')
if REACT:
    assert NODE.is_file(), 'Node >=22.12 is required; set RA2_NODE to its full path'
    ENV['RA2_NODE']=str(NODE.resolve())
(OUT/'Console').mkdir(exist_ok=True)
subprocess.run([str(PYTHON),str(SOURCE/'tools/prepare_console_sdk.py'),'--output',str(SDK),'--offline'],env=ENV,check=True)
bundle_command=[str(PYTHON),str(SOURCE/'tools/bundle_console.py'),'--output',str(OUT/'Console/index.html'),'--header',str(GENERATED/'web_console_assets.h')]
if REACT:
    bundle_command.extend(['--node',str(NODE.resolve())])
subprocess.run(bundle_command,cwd=SOURCE,env=ENV,check=True)
preparations=dict(console_frontend='react' if REACT else 'static',console_html_sha256=sha(OUT/'Console/index.html'),console_header_sha256=sha(GENERATED/'web_console_assets.h'))
if REACT:
    preparations.update(node=str(NODE.resolve()),node_version=subprocess.check_output([str(NODE),'--version'],text=True).strip(),console_package_lock_sha256=sha(FRONTEND/'package-lock.json'))
(LOGS/'preparations.json').write_text(json.dumps(preparations,indent=2)+'\n',encoding='utf-8')
(LOGS/'source-before.json').write_text(json.dumps(source_before,indent=2),encoding='utf-8')
commands = []
def run(name, args):
    command = [str(ZIG), *map(str, args)]
    print(f'BUILD {name}', flush=True)
    start = time.monotonic()
    with (LOGS / (name + '.log')).open('wb') as log:
        result = subprocess.run(command, cwd=SOURCE, env=ENV, stdout=log, stderr=subprocess.STDOUT)
    commands.append(dict(name=name, args=command, cwd=str(SOURCE), exit_code=result.returncode,
                         seconds=round(time.monotonic()-start, 2)))
    (LOGS / 'commands.json').write_text(json.dumps(commands, indent=2), encoding='utf-8')
    if result.returncode:
        print((LOGS / (name + '.log')).read_text(encoding='utf-8', errors='replace')[-14000:], flush=True)
        raise SystemExit(result.returncode)
    print(f'PASS {name} ({commands[-1]["seconds"]} s)', flush=True)

def rc(name, out, *args):
    run(name, ['rc', '/fo', out, *args])

def cpp(name, target, args):
    if target.endswith('-msvc'):
        args = ['-nostdlib', '-nostdinc', *args]
    run(name, ['c++', '-target', target, *args])

X86 = 'x86-windows-gnu'
X64 = 'x86_64-windows-gnu'
OPT = ['-std=c++17', '-O2']
NATIVE = OPT + ['-fms-extensions', '-fasm-blocks', '-fno-stack-protector', '-fno-builtin', '-fno-exceptions', '-fno-rtti']

# Read the final merged source rather than carrying old release/protocol values.
release_header = (SOURCE/'shared/source/release_version.h').read_text(encoding='utf-8-sig')
file_version = re.search(r'^#define\s+RA2_RELEASE_VERSION\s+"([^"]+)"', release_header, re.M).group(1)
version = re.search(r'^#define\s+RA2_RELEASE_VERSION_W\s+L"([^"]+)"', release_header, re.M).group(1)
parts = tuple(int(part.strip()) for part in re.search(r'^#define\s+RA2_RELEASE_VERSION_PARTS\s+([^\r\n]+)', release_header, re.M).group(1).split(','))
assert tuple(map(int, file_version.split('.'))) == parts, 'Release version macros disagree'
cursor_header = (SOURCE/'cursor/source/bridge.h').read_text(encoding='utf-8-sig')
cursor_protocol = int(re.search(r'RA2CursorBridge_v(\d+)_', cursor_header).group(1))
abi_source = GENERATED/'protocol_inventory.cpp'
abi_source.write_text('''#include <cstdio>
#include "assist/source/protocol.h"
#include "cursor/source/bridge.h"
#include "shared/source/runtime_protocol.h"
int main() {
  std::printf("{\\"assist_protocol\\":%u,\\"assist_shared_bytes\\":%zu,\\"cursor_shared_bytes\\":%zu,\\"runtime_protocol\\":%u,\\"runtime_control_bytes\\":%zu}\\n",
    assist::Version, sizeof(assist::Shared), sizeof(Shared), runtime::Version, sizeof(runtime::Control));
}
''', encoding='utf-8')
inventories = {}
for architecture, target in [('x86', X86), ('x64', X64)]:
    executable = GENERATED/('protocol_inventory_'+architecture+'.exe')
    cpp('protocol-inventory-'+architecture, target, OPT+['-I'+str(SOURCE), str(abi_source), '-o', executable, '-luser32'])
    inventories[architecture] = json.loads(subprocess.check_output([str(executable)], env=ENV, text=True, encoding='utf-8'))
assert inventories['x86'] == inventories['x64'], ('Cross-architecture protocol ABI differs', inventories)
metadata = dict(inventories['x64'], version=version, file_version=file_version, cursor_protocol=cursor_protocol)
(LOGS/'protocol_inventory.json').write_text(json.dumps(inventories,indent=2)+'\n',encoding='utf-8')

rc('runtime-resources', RUNTIME/'dll_version.res', 'shared/source/dll_version.rc')
cpp('game-entry-manager', X86, OPT+['-fno-exceptions', '-fno-rtti', '-c', 'shared/source/game_entry_manager.cpp', '-o', RUNTIME/'game_entry_manager.o'])
cpp('native-guard', 'x86-windows-msvc', ['-O2', '-fms-extensions', '-fno-stack-protector', '-c', 'assist/source/guard.cpp', '-o', RUNTIME/'guard.o'])
cpp('assist-bridge', X86, NATIVE+['-c', 'assist/source/bridge.cpp', '-o', RUNTIME/'bridge.o'])
cpp('resource-guard', 'x86-windows-msvc', ['-O2', '-fms-extensions', '-fno-stack-protector', '-c', 'cursor/source/resource_guard.cpp', '-o', RUNTIME/'resource_guard.o'])
cpp('cursor-hide', X86, ['-O2', '-DUNICODE', '-D_UNICODE', '-fms-extensions', '-fasm-blocks', '-fno-stack-protector', '-fno-builtin', '-fno-exceptions', '-fno-rtti', '-c', 'cursor/source/hide.cpp', '-o', RUNTIME/'hide.o'])
cpp('runtime', X86, NATIVE+['-c', 'game_runtime/source/runtime.cpp', '-o', RUNTIME/'runtime.o'])
cpp('runtime-link', X86, ['-shared', RUNTIME/'runtime.o', RUNTIME/'game_entry_manager.o', RUNTIME/'bridge.o', RUNTIME/'guard.o', RUNTIME/'hide.o', RUNTIME/'resource_guard.o', 'game_runtime/source/runtime.def', RUNTIME/'dll_version.res', '-o', OUT/'GameRuntime.dll', '-lkernel32', '-luser32', '-lgdi32', '-lwinmm'])
rc('broker-resources', RUNTIME/'broker.res', 'runtime_broker/source/app.rc')
cpp('broker', X86, OPT+['-municode', 'runtime_broker/source/main.cpp', RUNTIME/'broker.res', '-o', OUT/'GameRuntimeHost32.exe', '-Wl,--subsystem,windows', '-lkernel32', '-luser32'])
rc('host-resources', HOST/'app.res', '/d', 'RA2_HOST_X64=1', 'suite/source/app.rc')
cpp('web-console', X64, OPT+['-fms-extensions','-DRA2_CONSOLE_WEBVIEW2','-I'+str(SDK/'include'),'-I'+str(GENERATED),'-c','suite/source/web_console.cpp','-o',HOST/'web_console.o'])
cpp('gpu-fault-guard', 'x86_64-windows-msvc', ['-O2', '-fms-extensions', '-fno-stack-protector', '-DRA2_GPU_FAULT_GUARD', '-c', 'shared/source/gpu_fault_guard.cpp', '-o', HOST/'gpu_fault_guard.o'])
cpp('xbrz', X64, OPT+['-fno-exceptions', '-fno-rtti', '-c', 'third_party/xbrz/xbrz.cpp', '-o', HOST/'xbrz.o'])
for entry, module in [('Cursor','cursor'), ('Monitor','unit_monitor'), ('Tactical','assist')]:
    cpp('host-'+module, X64, OPT+['-DRA2_UNIFIED', '-DRA2_CONSOLE_WEBVIEW2', '-DRA2_GPU_FAULT_GUARD', '-DwWinMain='+entry+'Entry', '-Isuite/source', '-c', module+'/source/main.cpp', '-o', HOST/(module+'.o')])
cpp('host-link', X64, OPT+['-municode', '-DRA2_CONSOLE_WEBVIEW2', 'suite/source/main.cpp', HOST/'web_console.o', HOST/'cursor.o', HOST/'unit_monitor.o', HOST/'assist.o', HOST/'xbrz.o', HOST/'gpu_fault_guard.o', HOST/'app.res', '-o', OUT/'RA2Toolbox.exe', '-Wl,--subsystem,windows', '-lgdiplus', '-lcomctl32', '-luser32', '-lgdi32', '-lwinmm', '-lshell32', '-lole32', '-lcomdlg32'])
shutil.copy2(SOURCE/'BUILD_SOURCE_MANIFEST.json', OUT/'BUILD_SOURCE_MANIFEST.json')
shutil.copy2(SDK/'bin/WebView2Loader.dll',OUT/'WebView2Loader.dll')
(OUT/'licenses/WebView2').mkdir(parents=True,exist_ok=True)
for name in ('LICENSE.txt','NOTICE.txt'):shutil.copy2(SDK/'licenses'/name,OUT/'licenses/WebView2'/name)
if (FRONTEND/'licenses').is_dir():
    (OUT/'licenses/Console').mkdir(parents=True,exist_ok=True)
    for notice in sorted((FRONTEND/'licenses').iterdir()):
        if notice.is_file():shutil.copy2(notice,OUT/'licenses/Console'/notice.name)
target=dict(host='x64', runtime='x86', broker='x86', **metadata, console_ui='webview2',console_frontend='react' if REACT else 'static',console_bundle='Console/index.html',webview2_sdk='1.0.4314.35',webview2_loader='WebView2Loader.dll',webview2_runtime='Microsoft Edge WebView2 Evergreen Runtime', game_tested=False)
if (FRONTEND/'licenses').is_dir():
    target['console_licenses']='licenses/Console'
(OUT/'BUILD_TARGET.json').write_text(json.dumps(target,indent=2)+'\n', encoding='utf-8')
assert source_before==source_hashes(SOURCE,include_tests=False), 'Source changed during build; rebuild final snapshot'
print('PASS: production x64 host, x86 runtime and broker linked; source snapshot unchanged', flush=True)

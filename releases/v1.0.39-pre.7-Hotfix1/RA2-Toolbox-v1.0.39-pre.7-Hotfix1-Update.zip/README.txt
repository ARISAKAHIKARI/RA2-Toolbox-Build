﻿RA2 Toolbox 1.0.39-pre.7 Hotfix1 更新包（本地构建，CI未验收）

关闭游戏和工具箱，将三个文件一起替换到原工具箱目录，保留原有INI：
RA2Toolbox.exe：64位主程序。
GameRuntime.dll：32位游戏端组件。
GameRuntimeHost32.exe：32位Hook辅助进程。

本次修复：
pre.7 Hotfix1：
- 补齐19个单位类型清单的依赖：关闭各自“仅处理清单中的类型”时禁止编辑，保留原列表，重新开启后恢复。
- 队形双击缓存会在失焦、聊天、暂停、断连、关闭预览、改配置及重新注册快捷键时清除，避免把上次操作的第一击带到新上下文。
- 模块窗口销毁时清除旧注册和页面快照；设置、类别及退出消息只投递给仍注册的窗口，关闭确认所依赖的模块提前退出也能继续退出。

17项本地针对性检查通过，x86/x64页面fixture链接及宿主对象交叉编译4项通过；这些不等于真实Windows界面或游戏实测。包内Build-info记录完整构建和代码身份。

本地x64主程序及x86游戏端/辅助进程编译、PE校验通过。CI没有验收当前提交，不声称Windows界面实测、游戏/联机、画质帧率或NVIDIA模型实机验收。DWM不可用时仅有异步隐藏回退。

本包不包含RA2NeuralRenderer.exe。已有Render Fix4神经助手及neural-runtime目录请保留；没有助手时先关闭DLSS5，普通渲染可独立使用。原Neural协议1保持不变。

本地编译提交：9fcc585dbbfa3247fe89b1682ba54367f3d0902f
GitHub产品提交：d785acd0c21b2443261d2cde326eadefc16c701c
PE版本仍为1.0.39.7，请用Hotfix1文件名和Build-info.json区分本次修复。
